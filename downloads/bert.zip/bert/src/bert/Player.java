/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package bert;

/**
 *
 * @author Daniel
 */
public class Player {
    
	public String name;
	public boolean alive;
	public boolean isAI;
	public Player(String name, boolean alive, boolean isAI){
		this.name=name;
		this.alive=alive;
		this.isAI=isAI;
	}

}
