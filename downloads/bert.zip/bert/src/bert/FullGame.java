/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package bert;
import java.util.ArrayList;
import java.util.Arrays;
/**
 *
 * @author Daniel
 */
public class FullGame {
    Territory[] allTerritories;
	public FullGame() {
            Territory andrast = new Territory(0, "Andrast", "Gondor", false);
            Territory anfalas = new Territory(0, "Anfalas", "Gondor", false);
            Territory angmar = new Territory(0, "Angmar", "Arnor", false);
            Territory arnor = new Territory(0, "Arnor", "Arnor", false);
            Territory belfalas = new Territory(0, "Belfalas", "Gondor", false);
            Territory blackgate = new Territory(0, "Black Gate", "Mordor", true);
            Territory brownlands = new Territory(0, "Brown Lands", "Rhovanion", true);
            Territory cardolan = new Territory(0, "Cardolan", "Arnor", false);
            Territory carndum = new Territory(0, "Carn Dum", "Arnor", false);
            Territory carrock = new Territory(0, "Carrock", "Rhovanion", false);
            Territory deadmarshes = new Territory(0, "Dead Marshes", "Rohan", true);
            Territory druwaithiaur = new Territory(0, "Druwaith Iaur", "Gondor", true);
            Territory dunland = new Territory(0, "Dunland", "Rohan", false);
            Territory eastemnet = new Territory(0, "East Emnet", "Rohan", false);
            Territory eastmordor = new Territory(0, "East Mordor", "Mordor", false);
            Territory emynmuil = new Territory(0, "Emyn Muil", "Rohan", false);
            Territory enedwaith = new Territory(0, "Enedwaith", "Rohan", false);
            Territory eredluin = new Territory(0, "Ered Luin", "Arnor", false);
            Territory eregion = new Territory(0, "Eregion", "Arnor", false);
            Territory esgaroth = new Territory(0, "Esgaroth", "Rhovanion", false);
            Territory fangorn = new Territory(0, "Fangorn", "Rohan", false);
            Territory forlindon = new Territory(0, "Forlindon", "Arnor", false);
            Territory forodwaith = new Territory(0, "Forodwaith", "Arnor", true);
            Territory framsburg = new Territory(0, "Framsburg", "Rhovanion", false);
            Territory gapofrohan = new Territory(0, "Gap of Rohan", "Rohan", true);
            Territory greyhavens = new Territory(0, "Grey Havens", "Arnor", false);
            Territory harad = new Territory(0, "Harad", "Mordor", false);
            Territory harlindon = new Territory(0, "Harlindon", "Arnor", false);
            Territory ironhills = new Territory(0, "Iron hills", "Rhovanion", true);
            Territory ithilien = new Territory(0, "Ithilien", "Gondor", true);
            Territory lamedon = new Territory(0, "Lamedon", "Gondor", true);
            Territory lorien = new Territory(0, "Lorien", "Rhovanion", false);
            Territory minhiriath = new Territory(0, "Minhiriath", "Arnor", true);
            Territory mirkwood = new Territory(0, "Mirkwood", "Rhovanion", false);
            Territory northrhun = new Territory(0, "North Rhun", "Rhun", false);
            Territory nurn = new Territory(0, "Nurn", "Mordor", false);
            Territory pinnathgelin = new Territory(0, "Pinnath Gelin", "Gondor", false);
            Territory rhudaur = new Territory(0, "Rhudaur", "Arnor", false);
            Territory rhunhills = new Territory(0, "Rhun Hills", "Rhun", false);
            Territory seaofrhun = new Territory(0, "Sea of Rhun", "Rhun", true);
            Territory southgondor = new Territory(0, "South Gondor", "Mordor", true);
            Territory southrhun = new Territory(0, "South Rhun", "Rhun", false);
            Territory theshire = new Territory(0, "The Shire", "Arnor", false);
            Territory witheredheath = new Territory(0, "Withered Heath", "Rhovanion", true);
	
		Territory[] tempTerritories = {anfalas, andrast, angmar, arnor, belfalas, blackgate, brownlands,
                    cardolan, carndum, carrock, deadmarshes, druwaithiaur, dunland, eastemnet, eastmordor,
                    emynmuil,enedwaith, eredluin, eregion, esgaroth, fangorn, forlindon,forodwaith, 
                    framsburg, gapofrohan, greyhavens, harad, harlindon,
                    ironhills, ithilien,lamedon, lorien, minhiriath, mirkwood, northrhun, nurn,
                    pinnathgelin, rhudaur, rhunhills, seaofrhun,southgondor, southrhun, theshire, witheredheath};
		
		allTerritories = tempTerritories;

		// Eriador
		ArrayList<Territory> temp = new ArrayList<Territory>(Arrays.asList(arnor, greyhavens, minhiriath, cardolan));
		theshire.border = temp;
		temp = new ArrayList<Territory>(Arrays.asList(forlindon, greyhavens, arnor));
		eredluin.border = temp;
		temp = new ArrayList<Territory>(Arrays.asList(greyhavens, eredluin));
		forlindon.border = temp;
		temp = new ArrayList<Territory>(Arrays.asList(forlindon, eredluin, arnor, theshire, forodwaith, minhiriath));
		greyhavens.border = temp;
		temp = new ArrayList<Territory>(
				Arrays.asList(theshire, cardolan, greyhavens, angmar, forodwaith, eredluin, rhudaur));
		arnor.border = temp;
		temp = new ArrayList<Territory>(Arrays.asList(greyhavens, arnor, carndum, ironhills, witheredheath));
		forodwaith.border = temp;
		temp = new ArrayList<Territory>(Arrays.asList(forodwaith, angmar));
		carndum.border = temp;
		temp = new ArrayList<Territory>(Arrays.asList(carndum, arnor, rhudaur));
		angmar.border = temp;
		temp = new ArrayList<Territory>(Arrays.asList(arnor, angmar, eregion, cardolan));
		rhudaur.border = temp;
		temp = new ArrayList<Territory>(
				Arrays.asList(arnor, rhudaur, eregion, dunland, enedwaith, minhiriath, theshire));
		cardolan.border = temp;
		temp = new ArrayList<Territory>(Arrays.asList(dunland, cardolan, rhudaur));
		eregion.border = temp;
		temp = new ArrayList<Territory>(Arrays.asList(enedwaith, cardolan, theshire, greyhavens, lamedon, harlindon));
		minhiriath.border = temp;
		temp = new ArrayList<Territory>(Arrays.asList(greyhavens, minhiriath));
		harlindon.border = temp;
		// Rohan
		temp = new ArrayList<Territory>(Arrays.asList(minhiriath, cardolan, dunland, gapofrohan, druwaithiaur));
		enedwaith.border = temp;
		temp = new ArrayList<Territory>(Arrays.asList(enedwaith, eregion, cardolan, gapofrohan));
		dunland.border = temp;
		temp = new ArrayList<Territory>(Arrays.asList(enedwaith, dunland, fangorn, eastemnet, druwaithiaur));
		gapofrohan.border = temp;
		temp = new ArrayList<Territory>(Arrays.asList(gapofrohan, eastemnet, emynmuil, brownlands, lorien));
		fangorn.border = temp;
		temp = new ArrayList<Territory>(Arrays.asList(gapofrohan, fangorn, emynmuil, deadmarshes, ithilien));
		eastemnet.border = temp;
		temp = new ArrayList<Territory>(Arrays.asList(brownlands, deadmarshes, eastemnet, fangorn));
		emynmuil.border = temp;
		temp = new ArrayList<Territory>(Arrays.asList(eastemnet, emynmuil, blackgate, ithilien));
		deadmarshes.border = temp;
		// Gondor
		temp = new ArrayList<Territory>(Arrays.asList(enedwaith, gapofrohan, anfalas, pinnathgelin));
		druwaithiaur.border = temp;
		temp = new ArrayList<Territory>(Arrays.asList(andrast, druwaithiaur, pinnathgelin));
		anfalas.border = temp;
		temp = new ArrayList<Territory>(Arrays.asList(anfalas));
		andrast.border = temp;
		temp = new ArrayList<Territory>(Arrays.asList(anfalas, druwaithiaur, lamedon, belfalas));
		pinnathgelin.border = temp;
		temp = new ArrayList<Territory>(Arrays.asList(pinnathgelin, lamedon));
		belfalas.border = temp;
		temp = new ArrayList<Territory>(Arrays.asList(belfalas, pinnathgelin, ithilien, southgondor, minhiriath));
		lamedon.border = temp;
		temp = new ArrayList<Territory>(Arrays.asList(eastemnet, deadmarshes, lamedon, southgondor));
		ithilien.border = temp;
		// mordor
		temp = new ArrayList<Territory>(Arrays.asList(ithilien, lamedon, harad));
		southgondor.border = temp;
		temp = new ArrayList<Territory>(Arrays.asList(southgondor, nurn, eastmordor));
		harad.border = temp;
		temp = new ArrayList<Territory>(Arrays.asList(nurn, harad));
		eastmordor.border = temp;
		temp = new ArrayList<Territory>(Arrays.asList(eastmordor, harad, blackgate));
		nurn.border = temp;
		temp = new ArrayList<Territory>(Arrays.asList(nurn, deadmarshes));
		blackgate.border = temp;
		// Rhovanion
		temp = new ArrayList<Territory>(
				Arrays.asList(emynmuil, fangorn, lorien, mirkwood, esgaroth, seaofrhun));
		brownlands.border = temp;
		temp = new ArrayList<Territory>(Arrays.asList(fangorn, carrock, mirkwood, brownlands));
		lorien.border = temp;
		temp = new ArrayList<Territory>(Arrays.asList(lorien, mirkwood, framsburg));
		carrock.border = temp;
		temp = new ArrayList<Territory>(Arrays.asList(carrock, mirkwood, esgaroth));
		framsburg.border = temp;
		temp = new ArrayList<Territory>(Arrays.asList(lorien, carrock, framsburg, esgaroth, brownlands));
		mirkwood.border = temp;
		temp = new ArrayList<Territory>(
				Arrays.asList(brownlands, mirkwood, framsburg, witheredheath, northrhun, seaofrhun));
		esgaroth.border = temp;
		temp = new ArrayList<Territory>(Arrays.asList(esgaroth, forodwaith, ironhills));
		witheredheath.border = temp;
		temp = new ArrayList<Territory>(Arrays.asList(forodwaith, northrhun, witheredheath));
		ironhills.border = temp;
		// Rhun
		temp = new ArrayList<Territory>(Arrays.asList(ironhills, esgaroth, seaofrhun, southrhun));
		northrhun.border = temp;
		temp = new ArrayList<Territory>(Arrays.asList(seaofrhun, northrhun));
		southrhun.border = temp;
		temp = new ArrayList<Territory>(Arrays.asList(brownlands, esgaroth, rhunhills, southrhun, northrhun));
		seaofrhun.border = temp;
		temp = new ArrayList<Territory>(Arrays.asList(seaofrhun));
		rhunhills.border = temp;
	
}
}