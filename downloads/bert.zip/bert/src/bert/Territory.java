/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package bert;
import bert.*;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Random;

/**
 *
 * @author Daniel
 */
public class Territory {
   
	public int units;
	public String name;
	public String region;
	public boolean hasLeader;
	public boolean hasRing;
	public boolean isKeyTerritory;
	public boolean isRed;
	public boolean isBlack;
	public boolean isYellow;
	public boolean isGreen;
	public ArrayList<Territory> border = new ArrayList<>();

	public Territory(int units, String name, String region, boolean isKeyTerritory) { // konstruktor, kan skicka med parameter till skapade objekt
		this.name = name;
		this.units = units;
		this.region = region;
		this.isKeyTerritory = isKeyTerritory;
		this.hasLeader = false;
		this.hasRing = false;
		this.isRed = false;
		this.isBlack = false;
		this.isYellow = false;
		this.isGreen = false;
	}

 
}
