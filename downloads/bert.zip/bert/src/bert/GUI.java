/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bert;

import com.sun.org.apache.xalan.internal.xsltc.runtime.BasisLibrary;
import java.awt.Dimension;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Random;

/**
 *
 * @author Daniel
 */
public class GUI extends javax.swing.JFrame {

    FullGame territories = new FullGame();

    Player red = new Player(null, true, false);
    Player black = new Player(null, true, false);
    Player yellow = new Player(null, true, false);
    Player green = new Player(null, true, false);
    public boolean redTurn = false;
    public boolean blackTurn = false;
    public boolean yellowTurn = false;
    public boolean greenTurn = false;
    public boolean playerTurn = false;
    public boolean menuUnits = false;
    public boolean menuAttacking = false;
    public boolean menuLeader = false;
    public boolean menuRing = false;
    public boolean menuMove = false;
    public boolean mainMenu = false;
    public boolean choosingTerritory = false;
    public boolean redWon;
    public boolean blackWon;
    public boolean yellowWon;
    public boolean greenWon;
    public boolean playerWon;
    public String selectedTerritory;
    public int units = 0;
    public int numbersOfAttackings = 0;
    public int attackingUnits = 0;
    public int unitsAfterFight = 0;
    public Territory attacker;
    public Territory defender;

    /**
     * Creates new form GUI
     */
    public GUI() {
        red.name = "Nameless";
        black.name = "Nameless";
        yellow.name = "Nameless";
        green.name = "Nameless";
        initComponents();
        setAI();
    }

    public void setAI() {
        explorer.setText("AI Starter");
        events.setText("Select colors to be controlled by AI technology.");
        button1.setVisible(false);
        button2.setVisible(false);
        button3.setVisible(false);
        button4.setVisible(false);
        button5.setVisible(false);
        button6.setVisible(false);
        button7.setVisible(false);
        button8.setVisible(false);
        buttonOkUnitsAdd.setVisible(false);
        buttonOkUnitsAfterFight.setVisible(false);
        buttonMenu.setVisible(false);
        buttonAdd.setVisible(false);
        buttonStart.setVisible(false);
        comboBox.setVisible(true);
        buttonOkYellow.setVisible(false);
        buttonOkGreen.setVisible(false);
        buttonOkBlack.setVisible(false);
        buttonOkRed.setVisible(false);
        presentation.setVisible(false);
        textField.setVisible(false);
        comboBox.setVisible(false);
        jPanel1.setVisible(false);
        textArea.setLineWrap(true);
        textArea.setWrapStyleWord(true);
    }

    public void initialStartRed() {
        buttonAdd.setVisible(true);
        buttonStart.setVisible(false);
        redTurn = true;
        if (black.isAI) {
            buttonOkRed.setVisible(true);
        } else if (yellow.isAI) {
            buttonOkBlack.setVisible(true);
        } else if (green.isAI) {
            buttonOkYellow.setVisible(true);
        } else {
            buttonOkGreen.setVisible(true);
        }
        red(red);
        updateTerritoryList();
        events.setText("What territories do " + red.name + " start with?");
    }

    public void initialStartBlack() {
        buttonAdd.setVisible(true);
        buttonStart.setVisible(false);
        buttonOkRed.setVisible(false);
        redTurn = false;
        blackTurn = true;
        if (yellow.isAI) {
            buttonOkBlack.setVisible(true);
        } else if (green.isAI) {
            buttonOkYellow.setVisible(true);
        } else {
            buttonOkGreen.setVisible(true);
        }
        black(black);
        updateTerritoryList();
        events.setText("What territories do " + black.name + " start with?");
    }

    public void initialStartYellow() {
        buttonAdd.setVisible(true);
        buttonStart.setVisible(false);
        buttonOkRed.setVisible(false);
        buttonOkBlack.setVisible(false);
        redTurn = false;
        blackTurn = false;
        yellowTurn = true;
        if (green.isAI) {
            buttonOkYellow.setVisible(true);
        } else {
            buttonOkGreen.setVisible(true);
        }
        yellow(yellow);
        updateTerritoryList();
        events.setText("What territories do " + yellow.name + " start with?");
    }

    public void initialStartGreen() {
        buttonAdd.setVisible(true);
        buttonStart.setVisible(false);
        buttonOkRed.setVisible(false);
        buttonOkBlack.setVisible(false);
        buttonOkYellow.setVisible(false);
        redTurn = false;
        blackTurn = false;
        yellowTurn = false;
        greenTurn = true;
        buttonOkGreen.setVisible(true);
        green(green);
        updateTerritoryList();
        events.setText("What territories do " + green.name + " start with?");
    }

    public void menu() {
        if (black.alive == false && red.alive == false && yellow.alive == false && green.alive == false) {
            Runtime.getRuntime().exit(0);
        }
        button5.setVisible(false);
        button6.setVisible(false);
        button7.setVisible(true);
        button8.setVisible(true);
        buttonOkGreen.setVisible(false);
        buttonAdd.setVisible(false);
        comboBox.setVisible(false);
        buttonMenu.setVisible(false);
        redTurn = false;
        blackTurn = false;
        yellowTurn = false;
        greenTurn = false;
        playerTurn = false;
        button1.setText("Red");
        button2.setText("Black");
        button3.setText("Yellow");
        button4.setText("Green");
        button5.setText("Attack");
        button6.setText("Ring");
        button7.setText("Attack");
        button8.setText("Ring");
        explorer.setText("Main menu");
        buttonOkGreen.setVisible(false);
        buttonAdd.setVisible(false);
        buttonStart.setVisible((false));
        comboBox.setVisible(false);
        buttonMenu.setVisible(false);
        jPanel1.setVisible(false);
        if (red.alive && red.isAI) {
            button1.setVisible(true);
        } else {
            button1.setVisible(false);
        }
        if (black.alive && black.isAI) {
            button2.setVisible(true);
        } else {
            button2.setVisible(false);
        }
        if (yellow.alive && yellow.isAI) {
            button3.setVisible(true);
        } else {
            button3.setVisible(false);
        }
        if (green.alive && green.isAI) {
            button4.setVisible(true);
        } else {
            button4.setVisible(false);
        }
        events.setText("Choose whose turn it is.");
    }

    public void menuRed() {
        button1.setVisible(true);
        button2.setVisible(true);
        button3.setVisible(true);
        button4.setVisible(false);
        button5.setVisible(true);
        button6.setVisible(true);
        button7.setVisible(true);
        button8.setVisible(false);
        isRed.setVisible(false);
        isBlack.setVisible(false);
        isYellow.setVisible(false);
        isGreen.setVisible(false);
        buttonMenu.setVisible(true);
        buttonOkUnitsAdd.setVisible(false);
        buttonOkUnitsAfterFight.setVisible(false);
        textField.setVisible(false);
        button1.setText("Units");
        button2.setText("Attack");
        button3.setText("Leader");
        button5.setText("Move");
        button6.setText("Ring");
        button7.setText("Choose");
        explorer.setText(red.name + "'s menu.");
        updateTerritoryList();
        redWon = false;
        blackWon = false;
        yellowWon = false;
        greenWon = false;
        mainMenu = true;
        redTurn = true;
        playerTurn = false;
        menuLeader = false;
        menuAttacking = false;
        menuRing = false;
        menuUnits = false;
        events.setText("Choose what " + red.name + " should do.");
    }

    public void menuBlack() {
        button1.setVisible(true);
        button2.setVisible(true);
        button3.setVisible(true);
        button4.setVisible(false);
        button5.setVisible(true);
        button6.setVisible(true);
        button7.setVisible(true);
        button8.setVisible(false);
        isRed.setVisible(false);
        isBlack.setVisible(false);
        isYellow.setVisible(false);
        isGreen.setVisible(false);
        buttonMenu.setVisible(true);
        buttonOkUnitsAdd.setVisible(false);
        buttonOkUnitsAfterFight.setVisible(false);
        textField.setVisible(false);
        button1.setText("Units");
        button2.setText("Attack");
        button3.setText("Leader");
        button5.setText("Move");
        button6.setText("Ring");
        button7.setText("Choose");
        explorer.setText(black.name + "'s menu.");
        updateTerritoryList();
        redWon = false;
        blackWon = false;
        yellowWon = false;
        greenWon = false;
        mainMenu = true;
        blackTurn = true;
        playerTurn = false;
        menuLeader = false;
        menuAttacking = false;
        menuRing = false;
        menuUnits = false;
        events.setText("Choose what " + black.name + " should do.");
    }

    public void menuYellow() {
        button1.setVisible(true);
        button2.setVisible(true);
        button3.setVisible(true);
        button4.setVisible(false);
        button5.setVisible(true);
        button6.setVisible(true);
        button7.setVisible(true);
        button8.setVisible(false);
        isRed.setVisible(false);
        isBlack.setVisible(false);
        isYellow.setVisible(false);
        isGreen.setVisible(false);
        buttonMenu.setVisible(true);
        buttonOkUnitsAdd.setVisible(false);
        buttonOkUnitsAfterFight.setVisible(false);
        textField.setVisible(false);
        button1.setText("Units");
        button2.setText("Attack");
        button3.setText("Leader");
        button5.setText("Move");
        button6.setText("Ring");
        button7.setText("Choose");
        explorer.setText(yellow.name + "'s menu.");
        updateTerritoryList();
        redWon = false;
        blackWon = false;
        yellowWon = false;
        greenWon = false;
        mainMenu = true;
        yellowTurn = true;
        playerTurn = false;
        menuLeader = false;
        menuAttacking = false;
        menuRing = false;
        menuUnits = false;
        events.setText("Choose what " + yellow.name + " should do.");
    }

    public void menuGreen() {
        button1.setVisible(true);
        button2.setVisible(true);
        button3.setVisible(true);
        button4.setVisible(false);
        button5.setVisible(true);
        button6.setVisible(true);
        button7.setVisible(true);
        button8.setVisible(false);
        isRed.setVisible(false);
        isBlack.setVisible(false);
        isYellow.setVisible(false);
        isGreen.setVisible(false);
        buttonMenu.setVisible(true);
        buttonOkUnitsAdd.setVisible(false);
        buttonOkUnitsAfterFight.setVisible(false);
        textField.setVisible(false);
        button1.setText("Units");
        button2.setText("Attack");
        button3.setText("Leader");
        button5.setText("Move");
        button6.setText("Ring");
        button7.setText("Choose");
        explorer.setText(green.name + "'s menu.");
        updateTerritoryList();
        redWon = false;
        blackWon = false;
        yellowWon = false;
        greenWon = false;
        mainMenu = true;
        greenTurn = true;
        playerTurn = false;
        menuLeader = false;
        menuAttacking = false;
        menuRing = false;
        menuUnits = false;
        events.setText("Choose what " + green.name + " should do.");
    }

    public void isGameEndedRed() {
        ArrayList<Territory> temp = new ArrayList<>();
        for (int i = 0; i < territories.allTerritories.length; i++) {
            if (territories.allTerritories[i].isRed) {
                temp.add(territories.allTerritories[i]);
            }
        }
        if (temp.size() == 0) {
            red.alive = false;
            red.isAI = false;
            menu();
        } else if (temp.size() == 44) {
            events.setText(red.name + " won!");
        }
    }

    public void isGameEndedBlack() {
        ArrayList<Territory> temp = new ArrayList<>();
        for (int i = 0; i < territories.allTerritories.length; i++) {
            if (territories.allTerritories[i].isBlack) {
                temp.add(territories.allTerritories[i]);
            }
        }
        if (temp.size() == 0) {
            black.alive = false;
            black.isAI = false;
            menu();
        } else if (temp.size() == 44) {
            events.setText(black.name + " won!");
        }
    }

    public void isGameEndedYellow() {
        ArrayList<Territory> temp = new ArrayList<>();
        for (int i = 0; i < territories.allTerritories.length; i++) {
            if (territories.allTerritories[i].isYellow) {
                temp.add(territories.allTerritories[i]);
            }
        }
        if (temp.size() == 0) {
            yellow.alive = false;
            yellow.isAI = false;
            menu();
        } else if (temp.size() == 44) {
            events.setText(yellow.name + " won!");
        }
    }

    public void isGameEndedGreen() {
        ArrayList<Territory> temp = new ArrayList<>();
        for (int i = 0; i < territories.allTerritories.length; i++) {
            if (territories.allTerritories[i].isGreen) {
                temp.add(territories.allTerritories[i]);
            }
        }
        if (temp.size() == 0) {
            green.alive = false;
            green.isAI = false;
            menu();
        } else if (temp.size() == 44) {
            events.setText(green.name + " won!");
        }
    }

    public void updateTerritoryList() {
        comboBox.removeAllItems();
        for (int i = 0; i < territories.allTerritories.length; i++) {
            if (territories.allTerritories[i].units == 0) {
                comboBox.addItem(territories.allTerritories[i].name);
            }
        }

    }

    public void updateTerritoryListPlayer() {
        comboBox.removeAllItems();
        for (int i = 0; i < territories.allTerritories.length; i++) {
            if (territories.allTerritories[i].isRed || territories.allTerritories[i].isBlack || territories.allTerritories[i].isYellow || territories.allTerritories[i].isGreen) {
                comboBox.addItem(territories.allTerritories[i].name);
            }
        }
    }

    public void updateTerritoryListRing() {
        comboBox.removeAllItems();
        for (int i = 0; i < territories.allTerritories.length; i++) {
            if (!territories.allTerritories[i].hasRing) {
                comboBox.addItem(territories.allTerritories[i].name);
            }
        }
    }

    public void setTerritories() {
        presentation.setVisible(true);
        presentation.setText("");
        isRed.setVisible(false);
        isBlack.setVisible(false);
        isYellow.setVisible(false);
        isGreen.setVisible(false);
        choosingTerritory = true;
        comboBox.setVisible(true);
        if (red.isAI) {
            initialStartRed();
        } else if (black.isAI) {
            initialStartBlack();
        } else if (yellow.isAI) {
            initialStartYellow();
        } else {
            initialStartGreen();
        }
    }

    public void attackRed() {
        jPanel1.setVisible(false);
        button4.setVisible(true);
        isGreen.setVisible(true);
        button4.setText("Won");
        isGreen.setText("Loose");
        String leaderPhrase = "";
        System.out.println(numbersOfAttackings);
        attacker = attackerRed();
        if (attacker == null) {
            menuRed();
        }
        defender = defenderRed();
        attackingUnits = attackingUnits(attacker);
        attacker.units -= attackingUnits;
        if (attacker.hasLeader) {
            leaderPhrase = leaderPhrase();
        }
        String phrase = attackingPhraseRed(attacker.name, defender.name, attackingUnits, leaderPhrase);
        String answer = didIWinQuestion();
        events.setText(answer);
        presentation.setText(phrase);
    }

    public void attackBlack() {
        jPanel1.setVisible(false);
        button4.setVisible(true);
        isGreen.setVisible(true);
        button4.setText("Won");
        isGreen.setText("Loose");
        String leaderPhrase = "";
        System.out.println(numbersOfAttackings);
        attacker = attackerBlack();
        if (attacker == null) {
            menuBlack();
        }
        defender = defenderBlack();
        attackingUnits = attackingUnits(attacker);
        attacker.units -= attackingUnits;
        if (attacker.hasLeader) {
            leaderPhrase = leaderPhrase();
        }
        String phrase = attackingPhraseBlack(attacker.name, defender.name, attackingUnits, leaderPhrase);
        String answer = didIWinQuestion();
        events.setText(answer);
        presentation.setText(phrase);
    }

    public void attackYellow() {
        jPanel1.setVisible(false);
        button4.setVisible(true);
        isGreen.setVisible(true);
        button4.setText("Won");
        isGreen.setText("Loose");
        String leaderPhrase = "";
        System.out.println(numbersOfAttackings);
        attacker = attackerYellow();
        if (attacker == null) {
            menuRed();
        }
        defender = defenderYellow();
        attackingUnits = attackingUnits(attacker);
        attacker.units -= attackingUnits;
        if (attacker.hasLeader) {
            leaderPhrase = leaderPhrase();
        }
        String phrase = attackingPhraseYellow(attacker.name, defender.name, attackingUnits, leaderPhrase);
        String answer = didIWinQuestion();
        events.setText(answer);
        presentation.setText(phrase);
    }

    public void attackGreen() {
        jPanel1.setVisible(false);
        button4.setVisible(true);
        isGreen.setVisible(true);
        button4.setText("Won");
        isGreen.setText("Loose");
        String leaderPhrase = "";
        System.out.println(numbersOfAttackings);
        attacker = attackerGreen();
        if (attacker == null) {
            menuRed();
        }
        defender = defenderGreen();
        attackingUnits = attackingUnits(attacker);
        attacker.units -= attackingUnits;
        if (attacker.hasLeader) {
            leaderPhrase = leaderPhrase();
        }
        String phrase = attackingPhraseGreen(attacker.name, defender.name, attackingUnits, leaderPhrase);
        String answer = didIWinQuestion();
        events.setText(answer);
        presentation.setText(phrase);
    }

    public void attackPlayer() {
        button1.setVisible(false);
        button2.setVisible(false);
        button3.setVisible(false);
        button4.setVisible(false);
        button5.setVisible(false);
        button6.setVisible(false);
        button7.setVisible(false);
        button8.setVisible(false);
        comboBox.setVisible(true);
        buttonAdd.setVisible(true);
        buttonAdd.setText("OK");
        events.setText("What territory did you attack?");
        updateTerritoryListPlayer();
    }

    public void wonOrLostPlayer() {
        button1.setVisible(false);
        button2.setVisible(false);
        button3.setVisible(false);
        button4.setVisible(true);
        button5.setVisible(false);
        button6.setVisible(false);
        button7.setVisible(false);
        button8.setVisible(false);
        comboBox.setVisible(false);
        buttonAdd.setVisible(false);
        isGreen.setVisible(true);
        button4.setText("Win");
        isGreen.setText("Loose");
        buttonAdd.setText("OK");
        events.setText("Did you win or loose?");
    }

    public void attackPlayerWon() {
        defender.hasLeader = false;
        defender.isRed = false;
        defender.isBlack = false;
        defender.isYellow = false;
        defender.isGreen = false;
        defender.units = unitsAfterFight;
        presentation.setText(defender.name + " is now under player controll with " + unitsAfterFight + " units on it.");
        menu();
    }

    public void attackPlayerLost() {
        defender.units = unitsAfterFight;
        presentation.setText(defender.name + " now has " + unitsAfterFight + " units.");
        menu();
    }

    public void moveRingPlayer() {
        button1.setVisible(false);
        button2.setVisible(false);
        button3.setVisible(false);
        button4.setVisible(false);
        button5.setVisible(false);
        button6.setVisible(false);
        button7.setVisible(false);
        button8.setVisible(false);
        comboBox.setVisible(false);
        buttonAdd.setVisible(false);
        isGreen.setVisible(false);
        buttonStart.setVisible(true);
        buttonStart.setText("OK");
        comboBox.setVisible(true);
        events.setText("Where is the Ring?");
        updateTerritoryListRing();
    }

    public void attackRedWin() {
        String leaderPhrase = "";
        String reaction = "";
        if (attackingUnits > 0) {
            System.out.println("attackerar från" + attacker.name + " mot " + defender.name + " med " + attackingUnits);
            defender.isRed = true;
            defender.isBlack = false;
            defender.isYellow = false;
            defender.isGreen = false;
            int numbersAfterFight = unitsAfterFight; //numbersAfterFight(defender.name);
            if (numbersAfterFight > attackingUnits) {
                numbersAfterFight = attackingUnits;
                presentation.setText("Invalid number. Modified to " + attackingUnits
                        + " units.");
            }
            defender.units = numbersAfterFight;
            if (attacker.hasLeader) {
                leaderIsBorn(defender);
                leaderIsKilled(attacker);
            }
            reaction = reaction(true);
            if (defender.units > 1) {
                numbersOfAttackings++;
            }
        }
        events.setText(reaction);
        numbersOfAttackings--;
        doesRedContuineAttack();
    }

    public void attackBlackWin() {
        String leaderPhrase = "";
        String reaction = "";
        if (attackingUnits > 0) {
            System.out.println("attackerar från" + attacker.name + " mot " + defender.name + " med " + attackingUnits);
            defender.isRed = true;
            defender.isBlack = false;
            defender.isYellow = false;
            defender.isGreen = false;
            int numbersAfterFight = unitsAfterFight; //numbersAfterFight(defender.name);
            if (numbersAfterFight > attackingUnits) {
                numbersAfterFight = attackingUnits;
                presentation.setText("Invalid number. Modified to " + attackingUnits
                        + " units.");
            }
            defender.units = numbersAfterFight;
            if (attacker.hasLeader) {
                leaderIsBorn(defender);
                leaderIsKilled(attacker);
            }
            reaction = reaction(true);
            if (defender.units > 1) {
                numbersOfAttackings++;
            }
        }
        events.setText(reaction);
        numbersOfAttackings--;
        doesBlackContuineAttack();
    }

    public void attackYellowWin() {
        String leaderPhrase = "";
        String reaction = "";
        if (attackingUnits > 0) {
            System.out.println("attackerar från" + attacker.name + " mot " + defender.name + " med " + attackingUnits);
            defender.isRed = true;
            defender.isBlack = false;
            defender.isYellow = false;
            defender.isGreen = false;
            int numbersAfterFight = unitsAfterFight; //numbersAfterFight(defender.name);
            if (numbersAfterFight > attackingUnits) {
                numbersAfterFight = attackingUnits;
                presentation.setText("Invalid number. Modified to " + attackingUnits
                        + " units.");
            }
            defender.units = numbersAfterFight;
            if (attacker.hasLeader) {
                leaderIsBorn(defender);
                leaderIsKilled(attacker);
            }
            reaction = reaction(true);
            if (defender.units > 1) {
                numbersOfAttackings++;
            }
        }
        events.setText(reaction);
        numbersOfAttackings--;
        doesYellowContuineAttack();
    }

    public void attackGreenWin() {
        String leaderPhrase = "";
        String reaction = "";
        if (attackingUnits > 0) {
            System.out.println("attackerar från" + attacker.name + " mot " + defender.name + " med " + attackingUnits);
            defender.isRed = true;
            defender.isBlack = false;
            defender.isYellow = false;
            defender.isGreen = false;
            int numbersAfterFight = unitsAfterFight; //numbersAfterFight(defender.name);
            if (numbersAfterFight > attackingUnits) {
                numbersAfterFight = attackingUnits;
                presentation.setText("Invalid number. Modified to " + attackingUnits
                        + " units.");
            }
            defender.units = numbersAfterFight;
            if (attacker.hasLeader) {
                leaderIsBorn(defender);
                leaderIsKilled(attacker);
            }
            reaction = reaction(true);
            if (defender.units > 1) {
                numbersOfAttackings++;
            }
        }
        events.setText(reaction);
        numbersOfAttackings--;
        doesGreenContuineAttack();
    }

    public void attackRedLost() {
        String leaderPhrase = "";
        String reaction = "";
        if (attackingUnits > 0) {
            System.out.println("attackerar från" + attacker.name + " mot " + defender.name + " med " + attackingUnits);
            int numbersAfterFight = unitsAfterFight; //numbersAfterFight(defender.name);
            defender.units = numbersAfterFight;
            reaction = reaction(false);
        }
        events.setText(reaction);
        numbersOfAttackings--;
        doesRedContuineAttack();
    }

    public void attackBlackLost() {
        String leaderPhrase = "";
        String reaction = "";
        if (attackingUnits > 0) {
            System.out.println("attackerar från" + attacker.name + " mot " + defender.name + " med " + attackingUnits);
            int numbersAfterFight = unitsAfterFight; //numbersAfterFight(defender.name);
            defender.units = numbersAfterFight;
            reaction = reaction(false);
        }
        events.setText(reaction);
        numbersOfAttackings--;
        doesBlackContuineAttack();
    }

    public void attackYellowLost() {
        String leaderPhrase = "";
        String reaction = "";
        if (attackingUnits > 0) {
            System.out.println("attackerar från" + attacker.name + " mot " + defender.name + " med " + attackingUnits);
            int numbersAfterFight = unitsAfterFight; //numbersAfterFight(defender.name);
            defender.units = numbersAfterFight;
            reaction = reaction(false);
        }
        events.setText(reaction);
        numbersOfAttackings--;
        doesYellowContuineAttack();
    }

    public void attackGreenLost() {
        String leaderPhrase = "";
        String reaction = "";
        if (attackingUnits > 0) {
            System.out.println("attackerar från" + attacker.name + " mot " + defender.name + " med " + attackingUnits);
            int numbersAfterFight = unitsAfterFight; //numbersAfterFight(defender.name);
            defender.units = numbersAfterFight;
            reaction = reaction(false);
        }
        events.setText(reaction);
        numbersOfAttackings--;
        doesGreenContuineAttack();
    }

    public void doesRedContuineAttack() {
        if (numbersOfAttackings > 0) {
            button8.setVisible(true);
            button8.setText("Next");
        } else {
            jPanel1.setVisible(true);
            textArea.setText("");
            showTerritoriesRed();
            menuRed();
        }
    }

    public void doesBlackContuineAttack() {
        if (numbersOfAttackings > 0) {
            button8.setVisible(true);
            button8.setText("Next");
        } else {
            jPanel1.setVisible(true);
            textArea.setText("");
            showTerritoriesBlack();
            menuBlack();
        }
    }

    public void doesYellowContuineAttack() {
        if (numbersOfAttackings > 0) {
            button8.setVisible(true);
            button8.setText("Next");
        } else {
            jPanel1.setVisible(true);
            textArea.setText("");
            showTerritoriesYellow();
            menuYellow();
        }
    }

    public void doesGreenContuineAttack() {
        if (numbersOfAttackings > 0) {
            button8.setVisible(true);
            button8.setText("Next");
        } else {
            jPanel1.setVisible(true);
            textArea.setText("");
            showTerritoriesGreen();
            menuGreen();
        }
    }

    public Territory defenderRed() {
        System.out.println(attacker.name);
        ArrayList<Territory> borders = attacker.border;
        ArrayList<Territory> possibleAttacks = new ArrayList<>();
        for (int i = 0; i < borders.size(); i++) {
            if (borders.get(i).isRed == false && attacker.region.equals(borders.get(i).region)
                    && borders.get(i).units < attacker.units && borders.get(i).units != 0
                    && borders.get(i).isKeyTerritory) {
                possibleAttacks.add(borders.get(i));
            }
        }
        for (int i = 0; i < borders.size(); i++) {
            if (borders.get(i).isRed == false && borders.get(i).isKeyTerritory
                    && attacker.region.equals(borders.get(i).region)) {
                possibleAttacks.add(borders.get(i));
            }
        }
        for (int i = 0; i < borders.size(); i++) {
            if (borders.get(i).isRed == false && borders.get(i).isKeyTerritory && borders.get(i).units < attacker.units
                    && borders.get(i).units != 0) {
                possibleAttacks.add(borders.get(i));
            }
        }
        for (int i = 0; i < borders.size(); i++) {
            if (borders.get(i).isRed == false && attacker.region.equals(borders.get(i).region)
                    && borders.get(i).units < attacker.units && borders.get(i).units != 0) {
                possibleAttacks.add(borders.get(i));
            }
        }
        for (int i = 0; i < borders.size(); i++) {
            if (borders.get(i).isRed == false && borders.get(i).isKeyTerritory) {
                possibleAttacks.add(borders.get(i));
            }
        }
        for (int i = 0; i < borders.size(); i++) {
            if (borders.get(i).isRed == false && attacker.region.equals(borders.get(i).region)) {
                possibleAttacks.add(borders.get(i));
            }
        }
        for (int i = 0; i < borders.size(); i++) {
            if (borders.get(i).isRed == false && borders.get(i).units < attacker.units && borders.get(i).units != 0) {
                possibleAttacks.add(borders.get(i));
            }
        }
        for (int i = 0; i < borders.size(); i++) {
            if (borders.get(i).isRed == false) {
                possibleAttacks.add(borders.get(i));
            }
        }
        Random rand = new Random();
        if (possibleAttacks.size() < 0) {
            possibleAttacks.add(borders.get(1));
        }
        int randomTerritory = rand.nextInt((possibleAttacks.size()));
        defender = possibleAttacks.get(randomTerritory);
        return defender;
    }

    public Territory defenderBlack() {
        System.out.println(attacker.name);
        ArrayList<Territory> borders = attacker.border;
        ArrayList<Territory> possibleAttacks = new ArrayList<>();
        for (int i = 0; i < borders.size(); i++) {
            if (borders.get(i).isBlack == false && attacker.region.equals(borders.get(i).region)
                    && borders.get(i).units < attacker.units && borders.get(i).units != 0
                    && borders.get(i).isKeyTerritory) {
                possibleAttacks.add(borders.get(i));
            }
        }
        for (int i = 0; i < borders.size(); i++) {
            if (borders.get(i).isBlack == false && borders.get(i).isKeyTerritory
                    && attacker.region.equals(borders.get(i).region)) {
                possibleAttacks.add(borders.get(i));
            }
        }
        for (int i = 0; i < borders.size(); i++) {
            if (borders.get(i).isBlack == false && borders.get(i).isKeyTerritory && borders.get(i).units < attacker.units
                    && borders.get(i).units != 0) {
                possibleAttacks.add(borders.get(i));
            }
        }
        for (int i = 0; i < borders.size(); i++) {
            if (borders.get(i).isBlack == false && attacker.region.equals(borders.get(i).region)
                    && borders.get(i).units < attacker.units && borders.get(i).units != 0) {
                possibleAttacks.add(borders.get(i));
            }
        }
        for (int i = 0; i < borders.size(); i++) {
            if (borders.get(i).isBlack == false && borders.get(i).isKeyTerritory) {
                possibleAttacks.add(borders.get(i));
            }
        }
        for (int i = 0; i < borders.size(); i++) {
            if (borders.get(i).isBlack == false && attacker.region.equals(borders.get(i).region)) {
                possibleAttacks.add(borders.get(i));
            }
        }
        for (int i = 0; i < borders.size(); i++) {
            if (borders.get(i).isBlack == false && borders.get(i).units < attacker.units && borders.get(i).units != 0) {
                possibleAttacks.add(borders.get(i));
            }
        }
        for (int i = 0; i < borders.size(); i++) {
            if (borders.get(i).isBlack == false) {
                possibleAttacks.add(borders.get(i));
            }
        }
        Random rand = new Random();
        if (possibleAttacks.size() < 0) {
            possibleAttacks.add(borders.get(1));
        }
        int randomTerritory = rand.nextInt((possibleAttacks.size()));
        defender = possibleAttacks.get(randomTerritory);
        return defender;
    }

    public Territory defenderYellow() {
        System.out.println(attacker.name);
        ArrayList<Territory> borders = attacker.border;
        ArrayList<Territory> possibleAttacks = new ArrayList<>();
        for (int i = 0; i < borders.size(); i++) {
            if (borders.get(i).isYellow == false && attacker.region.equals(borders.get(i).region)
                    && borders.get(i).units < attacker.units && borders.get(i).units != 0
                    && borders.get(i).isKeyTerritory) {
                possibleAttacks.add(borders.get(i));
            }
        }
        for (int i = 0; i < borders.size(); i++) {
            if (borders.get(i).isYellow == false && borders.get(i).isKeyTerritory
                    && attacker.region.equals(borders.get(i).region)) {
                possibleAttacks.add(borders.get(i));
            }
        }
        for (int i = 0; i < borders.size(); i++) {
            if (borders.get(i).isYellow == false && borders.get(i).isKeyTerritory && borders.get(i).units < attacker.units
                    && borders.get(i).units != 0) {
                possibleAttacks.add(borders.get(i));
            }
        }
        for (int i = 0; i < borders.size(); i++) {
            if (borders.get(i).isYellow == false && attacker.region.equals(borders.get(i).region)
                    && borders.get(i).units < attacker.units && borders.get(i).units != 0) {
                possibleAttacks.add(borders.get(i));
            }
        }
        for (int i = 0; i < borders.size(); i++) {
            if (borders.get(i).isYellow == false && borders.get(i).isKeyTerritory) {
                possibleAttacks.add(borders.get(i));
            }
        }
        for (int i = 0; i < borders.size(); i++) {
            if (borders.get(i).isYellow == false && attacker.region.equals(borders.get(i).region)) {
                possibleAttacks.add(borders.get(i));
            }
        }
        for (int i = 0; i < borders.size(); i++) {
            if (borders.get(i).isYellow == false && borders.get(i).units < attacker.units && borders.get(i).units != 0) {
                possibleAttacks.add(borders.get(i));
            }
        }
        for (int i = 0; i < borders.size(); i++) {
            if (borders.get(i).isYellow == false) {
                possibleAttacks.add(borders.get(i));
            }
        }
        Random rand = new Random();
        if (possibleAttacks.size() < 0) {
            possibleAttacks.add(borders.get(1));
        }
        int randomTerritory = rand.nextInt((possibleAttacks.size()));
        defender = possibleAttacks.get(randomTerritory);
        return defender;
    }

    public Territory defenderGreen() {
        System.out.println(attacker.name);
        ArrayList<Territory> borders = attacker.border;
        ArrayList<Territory> possibleAttacks = new ArrayList<>();
        for (int i = 0; i < borders.size(); i++) {
            if (borders.get(i).isGreen == false && attacker.region.equals(borders.get(i).region)
                    && borders.get(i).units < attacker.units && borders.get(i).units != 0
                    && borders.get(i).isKeyTerritory) {
                possibleAttacks.add(borders.get(i));
            }
        }
        for (int i = 0; i < borders.size(); i++) {
            if (borders.get(i).isGreen == false && borders.get(i).isKeyTerritory
                    && attacker.region.equals(borders.get(i).region)) {
                possibleAttacks.add(borders.get(i));
            }
        }
        for (int i = 0; i < borders.size(); i++) {
            if (borders.get(i).isGreen == false && borders.get(i).isKeyTerritory && borders.get(i).units < attacker.units
                    && borders.get(i).units != 0) {
                possibleAttacks.add(borders.get(i));
            }
        }
        for (int i = 0; i < borders.size(); i++) {
            if (borders.get(i).isGreen == false && attacker.region.equals(borders.get(i).region)
                    && borders.get(i).units < attacker.units && borders.get(i).units != 0) {
                possibleAttacks.add(borders.get(i));
            }
        }
        for (int i = 0; i < borders.size(); i++) {
            if (borders.get(i).isGreen == false && borders.get(i).isKeyTerritory) {
                possibleAttacks.add(borders.get(i));
            }
        }
        for (int i = 0; i < borders.size(); i++) {
            if (borders.get(i).isGreen == false && attacker.region.equals(borders.get(i).region)) {
                possibleAttacks.add(borders.get(i));
            }
        }
        for (int i = 0; i < borders.size(); i++) {
            if (borders.get(i).isGreen == false && borders.get(i).units < attacker.units && borders.get(i).units != 0) {
                possibleAttacks.add(borders.get(i));
            }
        }
        for (int i = 0; i < borders.size(); i++) {
            if (borders.get(i).isGreen == false) {
                possibleAttacks.add(borders.get(i));
            }
        }
        Random rand = new Random();
        if (possibleAttacks.size() < 0) {
            possibleAttacks.add(borders.get(1));
        }
        int randomTerritory = rand.nextInt((possibleAttacks.size()));
        defender = possibleAttacks.get(randomTerritory);
        return defender;
    }

    public int numbersOfAttacksRed() {
        int randomTemp;
        Random rand = new Random();
        ArrayList<Territory> temp = new ArrayList<>();
        for (int i = 0; i < territories.allTerritories.length; i++) {
            if (territories.allTerritories[i].isRed) {
                temp.add(territories.allTerritories[i]);
            }
        }
        int randomNumber = rand.nextInt((temp.size()));
        int numberOfAttackings = rand.nextInt((randomNumber) + 1);
        if (numberOfAttackings < randomNumber / 3 && randomNumber > 1) {
            randomTemp = rand.nextInt(10);
            if (randomTemp > 2) {
                numberOfAttackings = numberOfAttackings * 3;
            }
        }
        if (numberOfAttackings == 0 && temp.size() > 0) {
            randomTemp = rand.nextInt(10);
            if (randomTemp > 3) {
                numberOfAttackings++;
            } else {
                jPanel1.setVisible(true);
                String reason = notAttacking(red);
                presentation.setText(reason);
            }
        }
        return numberOfAttackings;
    }

    public int numbersOfAttacksBlack() {
        int randomTemp;
        Random rand = new Random();
        ArrayList<Territory> temp = new ArrayList<>();
        for (int i = 0; i < territories.allTerritories.length; i++) {
            if (territories.allTerritories[i].isBlack) {
                temp.add(territories.allTerritories[i]);
            }
        }
        int randomNumber = rand.nextInt((temp.size()));
        int numberOfAttackings = rand.nextInt((randomNumber) + 1);
        if (numberOfAttackings < randomNumber / 3 && randomNumber > 1) {
            randomTemp = rand.nextInt(10);
            if (randomTemp > 2) {
                numberOfAttackings = numberOfAttackings * 3;
            }
        }
        if (numberOfAttackings == 0 && temp.size() > 0) {
            randomTemp = rand.nextInt(10);
            if (randomTemp > 3) {
                numberOfAttackings++;
            } else {
                jPanel1.setVisible(true);
                String reason = notAttacking(black);
                presentation.setText(reason);
            }
        }
        return numberOfAttackings;
    }

    public int numbersOfAttacksYellow() {
        int randomTemp;
        Random rand = new Random();
        ArrayList<Territory> temp = new ArrayList<>();
        for (int i = 0; i < territories.allTerritories.length; i++) {
            if (territories.allTerritories[i].isYellow) {
                temp.add(territories.allTerritories[i]);
            }
        }
        int randomNumber = rand.nextInt((temp.size()));
        int numberOfAttackings = rand.nextInt((randomNumber) + 1);
        if (numberOfAttackings < randomNumber / 3 && randomNumber > 1) {
            randomTemp = rand.nextInt(10);
            if (randomTemp > 2) {
                numberOfAttackings = numberOfAttackings * 3;
            }
        }
        if (numberOfAttackings == 0 && temp.size() > 0) {
            randomTemp = rand.nextInt(10);
            if (randomTemp > 3) {
                numberOfAttackings++;
            } else {
                jPanel1.setVisible(true);
                String reason = notAttacking(yellow);
                presentation.setText(reason);
            }
        }
        return numberOfAttackings;
    }

    public int numbersOfAttacksGreen() {
        int randomTemp;
        Random rand = new Random();
        ArrayList<Territory> temp = new ArrayList<>();
        for (int i = 0; i < territories.allTerritories.length; i++) {
            if (territories.allTerritories[i].isGreen) {
                temp.add(territories.allTerritories[i]);
            }
        }
        int randomNumber = rand.nextInt((temp.size()));
        int numberOfAttackings = rand.nextInt((randomNumber) + 1);
        if (numberOfAttackings < randomNumber / 3 && randomNumber > 1) {
            randomTemp = rand.nextInt(10);
            if (randomTemp > 2) {
                numberOfAttackings = numberOfAttackings * 3;
            }
        }
        if (numberOfAttackings == 0 && temp.size() > 0) {
            randomTemp = rand.nextInt(10);
            if (randomTemp > 3) {
                numberOfAttackings++;
            } else {
                jPanel1.setVisible(true);
                String reason = notAttacking(green);
                presentation.setText(reason);
            }
        }
        return numberOfAttackings;
    }

    public Territory attackerRed() {
        Random rand = new Random();
        int numbersOfTerritories = 0;
        ArrayList<Territory> temp = new ArrayList<>();
        for (int i = 0; i < territories.allTerritories.length; i++) {
            for (int j = 0; j < territories.allTerritories[i].border.size(); j++) {
                if (territories.allTerritories[i].isRed && checkIfEnemyBordersRed(territories.allTerritories[i])
                        && territories.allTerritories[i].units > 1) {
                    temp.add(territories.allTerritories[i]);
                    j = territories.allTerritories[i].border.size();
                }
            }
        }
        for (int i = 0; i < territories.allTerritories.length; i++) {
            for (int j = 0; j < territories.allTerritories[i].border.size(); j++) {
                if (territories.allTerritories[i].isRed && checkIfEnemyBordersRed(territories.allTerritories[i])
                        && territories.allTerritories[i].units > 1 && territories.allTerritories[i].hasLeader) {
                    j = territories.allTerritories[i].border.size();
                }
            }
        }
        for (int i = 0; i < territories.allTerritories.length; i++) {
            for (int j = 0; j < territories.allTerritories[i].border.size(); j++) {
                if (territories.allTerritories[i].isRed && checkIfEnemyBordersRed(territories.allTerritories[i])
                        && territories.allTerritories[i].units > 1
                        && territories.allTerritories[i].border.get(j).isKeyTerritory
                        && territories.allTerritories[i].border.get(j).isRed == false) {
                    j = territories.allTerritories[i].border.size();
                }
            }
        }
        for (int i = 0; i < territories.allTerritories.length; i++) {
            for (int j = 0; j < territories.allTerritories[i].border.size(); j++) {
                if (territories.allTerritories[i].isRed && checkIfEnemyBordersRed(territories.allTerritories[i])
                        && territories.allTerritories[i].units > 1
                        && territories.allTerritories[i].border.get(j).region
                        .equals(territories.allTerritories[i].region)
                        && territories.allTerritories[i].border.get(j).isRed == false) {
                    temp.add(territories.allTerritories[i]);
                    j = territories.allTerritories[i].border.size();
                }
            }
        }
        for (int i = 0; i < territories.allTerritories.length; i++) {
            for (int j = 0; j < territories.allTerritories[i].border.size(); j++) {
                if (territories.allTerritories[i].isRed && checkIfEnemyBordersRed(territories.allTerritories[i])
                        && territories.allTerritories[i].units > 1
                        && territories.allTerritories[i].border.get(j).units < territories.allTerritories[i].units
                        && territories.allTerritories[i].border.get(j).units > 0
                        && territories.allTerritories[i].border.get(j).isRed == false) {
                    temp.add(territories.allTerritories[i]);
                    j = territories.allTerritories[i].border.size();
                }
            }
        }
        for (int i = 0; i < territories.allTerritories.length; i++) {
            for (int j = 0; j < territories.allTerritories[i].border.size(); j++) {
                if (territories.allTerritories[i].isRed && checkIfEnemyBordersRed(territories.allTerritories[i])
                        && territories.allTerritories[i].units > 1
                        && territories.allTerritories[i].border.get(j).units < territories.allTerritories[i].units
                        && territories.allTerritories[i].border.get(j).units > 0
                        && territories.allTerritories[i].hasLeader
                        && territories.allTerritories[i].border.get(j).isRed == false) {
                    temp.add(territories.allTerritories[i]);
                    j = territories.allTerritories[i].border.size();
                }
            }
        }
        for (int i = 0; i < territories.allTerritories.length; i++) {
            for (int j = 0; j < territories.allTerritories[i].border.size(); j++) {
                if (territories.allTerritories[i].isRed && checkIfEnemyBordersRed(territories.allTerritories[i])
                        && territories.allTerritories[i].units > 1
                        && territories.allTerritories[i].border.get(j).units < territories.allTerritories[i].units
                        && territories.allTerritories[i].border.get(j).units > 0
                        && territories.allTerritories[i].border.get(j).isKeyTerritory
                        && territories.allTerritories[i].border.get(j).isRed == false) {
                    temp.add(territories.allTerritories[i]);
                    j = territories.allTerritories[i].border.size();
                }
            }
        }
        for (int i = 0; i < territories.allTerritories.length; i++) {
            for (int j = 0; j < territories.allTerritories[i].border.size(); j++) {
                if (territories.allTerritories[i].isRed && checkIfEnemyBordersRed(territories.allTerritories[i])
                        && territories.allTerritories[i].units > 1
                        && territories.allTerritories[i].border.get(j).units < territories.allTerritories[i].units
                        && territories.allTerritories[i].border.get(j).units > 0
                        && territories.allTerritories[i].border.get(j).region
                        .equals(territories.allTerritories[i].region)
                        && territories.allTerritories[i].border.get(j).isRed == false) {
                    temp.add(territories.allTerritories[i]);
                    j = territories.allTerritories[i].border.size();
                }
            }
        }
        for (int i = 0; i < territories.allTerritories.length; i++) {
            for (int j = 0; j < territories.allTerritories[i].border.size(); j++) {
                if (territories.allTerritories[i].isRed && checkIfEnemyBordersRed(territories.allTerritories[i])
                        && territories.allTerritories[i].units > 1
                        && territories.allTerritories[i].border.get(j).region
                        .equals(territories.allTerritories[i].region)
                        && territories.allTerritories[i].hasLeader
                        && territories.allTerritories[i].border.get(j).isRed == false) {
                    temp.add(territories.allTerritories[i]);
                    j = territories.allTerritories[i].border.size();
                }
            }
        }
        for (int i = 0; i < territories.allTerritories.length; i++) {
            for (int j = 0; j < territories.allTerritories[i].border.size(); j++) {
                if (territories.allTerritories[i].isRed && checkIfEnemyBordersRed(territories.allTerritories[i])
                        && territories.allTerritories[i].units > 1
                        && territories.allTerritories[i].border.get(j).region
                        .equals(territories.allTerritories[i].region)
                        && territories.allTerritories[i].border.get(j).isKeyTerritory
                        && territories.allTerritories[i].border.get(j).isRed == false) {
                    temp.add(territories.allTerritories[i]);
                    j = territories.allTerritories[i].border.size();
                }
            }
        }
        for (int i = 0; i < territories.allTerritories.length; i++) {
            for (int j = 0; j < territories.allTerritories[i].border.size(); j++) {
                if (territories.allTerritories[i].isRed && checkIfEnemyBordersRed(territories.allTerritories[i])
                        && territories.allTerritories[i].units > 1
                        && territories.allTerritories[i].border.get(j).isKeyTerritory
                        && territories.allTerritories[i].hasLeader
                        && territories.allTerritories[i].border.get(j).isRed == false) {
                    temp.add(territories.allTerritories[i]);
                    j = territories.allTerritories[i].border.size();
                }
            }
        }
        for (int i = 0; i < territories.allTerritories.length; i++) {
            for (int j = 0; j < territories.allTerritories[i].border.size(); j++) {
                if (territories.allTerritories[i].isRed && checkIfEnemyBordersRed(territories.allTerritories[i])
                        && territories.allTerritories[i].units > 1
                        && territories.allTerritories[i].border.get(j).units < territories.allTerritories[i].units / 2
                        && territories.allTerritories[i].border.get(j).units > 0
                        && territories.allTerritories[i].border.get(j).isRed == false) {
                    temp.add(territories.allTerritories[i]);
                    j = territories.allTerritories[i].border.size();
                }
            }
        }
        for (int i = 0; i < territories.allTerritories.length; i++) {
            for (int j = 0; j < territories.allTerritories[i].border.size(); j++) {
                if (territories.allTerritories[i].isRed && checkIfEnemyBordersRed(territories.allTerritories[i])
                        && territories.allTerritories[i].units > 1
                        && territories.allTerritories[i].border.get(j).units < territories.allTerritories[i].units / 4
                        && territories.allTerritories[i].border.get(j).units > 0
                        && territories.allTerritories[i].border.get(j).isRed == false) {
                    temp.add(territories.allTerritories[i]);
                    j = territories.allTerritories[i].border.size();
                }
            }
        }
        for (int i = 0; i < territories.allTerritories.length; i++) {
            for (int j = 0; j < territories.allTerritories[i].border.size(); j++) {
                if (territories.allTerritories[i].isRed && checkIfEnemyBordersRed(territories.allTerritories[i])
                        && territories.allTerritories[i].units > 1 && territories.allTerritories[i].isKeyTerritory
                        && territories.allTerritories[i].border.get(j).region
                        .equals(territories.allTerritories[i].region)
                        && territories.allTerritories[i].border.get(j).units < territories.allTerritories[i].units
                        && territories.allTerritories[i].border.get(j).units > 0
                        && territories.allTerritories[i].hasLeader
                        && territories.allTerritories[i].border.get(j).isRed == false) {
                    temp.add(territories.allTerritories[i]);
                    j = territories.allTerritories[i].border.size();
                }
            }
        }
        numbersOfTerritories = temp.size();
        if (temp.size() > 0) {
            int randomTerritory = rand.nextInt((numbersOfTerritories));
            return temp.get(randomTerritory);
        } else {
            jPanel1.setVisible(true);
            String phrase = notAttacking(red);
            presentation.setText(phrase);
            return null;
        }
    }

    public Territory attackerBlack() {
        Random rand = new Random();
        int numbersOfTerritories = 0;
        ArrayList<Territory> temp = new ArrayList<>();
        for (int i = 0; i < territories.allTerritories.length; i++) {
            for (int j = 0; j < territories.allTerritories[i].border.size(); j++) {
                if (territories.allTerritories[i].isBlack && checkIfEnemyBordersBlack(territories.allTerritories[i])
                        && territories.allTerritories[i].units > 1) {
                    temp.add(territories.allTerritories[i]);
                    j = territories.allTerritories[i].border.size();
                }
            }
        }
        for (int i = 0; i < territories.allTerritories.length; i++) {
            for (int j = 0; j < territories.allTerritories[i].border.size(); j++) {
                if (territories.allTerritories[i].isBlack && checkIfEnemyBordersBlack(territories.allTerritories[i])
                        && territories.allTerritories[i].units > 1 && territories.allTerritories[i].hasLeader) {
                    j = territories.allTerritories[i].border.size();
                }
            }
        }
        for (int i = 0; i < territories.allTerritories.length; i++) {
            for (int j = 0; j < territories.allTerritories[i].border.size(); j++) {
                if (territories.allTerritories[i].isBlack && checkIfEnemyBordersBlack(territories.allTerritories[i])
                        && territories.allTerritories[i].units > 1
                        && territories.allTerritories[i].border.get(j).isKeyTerritory
                        && territories.allTerritories[i].border.get(j).isBlack == false) {
                    j = territories.allTerritories[i].border.size();
                }
            }
        }
        for (int i = 0; i < territories.allTerritories.length; i++) {
            for (int j = 0; j < territories.allTerritories[i].border.size(); j++) {
                if (territories.allTerritories[i].isBlack && checkIfEnemyBordersBlack(territories.allTerritories[i])
                        && territories.allTerritories[i].units > 1
                        && territories.allTerritories[i].border.get(j).region
                        .equals(territories.allTerritories[i].region)
                        && territories.allTerritories[i].border.get(j).isBlack == false) {
                    temp.add(territories.allTerritories[i]);
                    j = territories.allTerritories[i].border.size();
                }
            }
        }
        for (int i = 0; i < territories.allTerritories.length; i++) {
            for (int j = 0; j < territories.allTerritories[i].border.size(); j++) {
                if (territories.allTerritories[i].isBlack && checkIfEnemyBordersBlack(territories.allTerritories[i])
                        && territories.allTerritories[i].units > 1
                        && territories.allTerritories[i].border.get(j).units < territories.allTerritories[i].units
                        && territories.allTerritories[i].border.get(j).units > 0
                        && territories.allTerritories[i].border.get(j).isBlack == false) {
                    temp.add(territories.allTerritories[i]);
                    j = territories.allTerritories[i].border.size();
                }
            }
        }
        for (int i = 0; i < territories.allTerritories.length; i++) {
            for (int j = 0; j < territories.allTerritories[i].border.size(); j++) {
                if (territories.allTerritories[i].isBlack && checkIfEnemyBordersBlack(territories.allTerritories[i])
                        && territories.allTerritories[i].units > 1
                        && territories.allTerritories[i].border.get(j).units < territories.allTerritories[i].units
                        && territories.allTerritories[i].border.get(j).units > 0
                        && territories.allTerritories[i].hasLeader
                        && territories.allTerritories[i].border.get(j).isBlack == false) {
                    temp.add(territories.allTerritories[i]);
                    j = territories.allTerritories[i].border.size();
                }
            }
        }
        for (int i = 0; i < territories.allTerritories.length; i++) {
            for (int j = 0; j < territories.allTerritories[i].border.size(); j++) {
                if (territories.allTerritories[i].isBlack && checkIfEnemyBordersBlack(territories.allTerritories[i])
                        && territories.allTerritories[i].units > 1
                        && territories.allTerritories[i].border.get(j).units < territories.allTerritories[i].units
                        && territories.allTerritories[i].border.get(j).units > 0
                        && territories.allTerritories[i].border.get(j).isKeyTerritory
                        && territories.allTerritories[i].border.get(j).isBlack == false) {
                    temp.add(territories.allTerritories[i]);
                    j = territories.allTerritories[i].border.size();
                }
            }
        }
        for (int i = 0; i < territories.allTerritories.length; i++) {
            for (int j = 0; j < territories.allTerritories[i].border.size(); j++) {
                if (territories.allTerritories[i].isBlack && checkIfEnemyBordersBlack(territories.allTerritories[i])
                        && territories.allTerritories[i].units > 1
                        && territories.allTerritories[i].border.get(j).units < territories.allTerritories[i].units
                        && territories.allTerritories[i].border.get(j).units > 0
                        && territories.allTerritories[i].border.get(j).region
                        .equals(territories.allTerritories[i].region)
                        && territories.allTerritories[i].border.get(j).isBlack == false) {
                    temp.add(territories.allTerritories[i]);
                    j = territories.allTerritories[i].border.size();
                }
            }
        }
        for (int i = 0; i < territories.allTerritories.length; i++) {
            for (int j = 0; j < territories.allTerritories[i].border.size(); j++) {
                if (territories.allTerritories[i].isBlack && checkIfEnemyBordersBlack(territories.allTerritories[i])
                        && territories.allTerritories[i].units > 1
                        && territories.allTerritories[i].border.get(j).region
                        .equals(territories.allTerritories[i].region)
                        && territories.allTerritories[i].hasLeader
                        && territories.allTerritories[i].border.get(j).isBlack == false) {
                    temp.add(territories.allTerritories[i]);
                    j = territories.allTerritories[i].border.size();
                }
            }
        }
        for (int i = 0; i < territories.allTerritories.length; i++) {
            for (int j = 0; j < territories.allTerritories[i].border.size(); j++) {
                if (territories.allTerritories[i].isBlack && checkIfEnemyBordersBlack(territories.allTerritories[i])
                        && territories.allTerritories[i].units > 1
                        && territories.allTerritories[i].border.get(j).region
                        .equals(territories.allTerritories[i].region)
                        && territories.allTerritories[i].border.get(j).isKeyTerritory
                        && territories.allTerritories[i].border.get(j).isBlack == false) {
                    temp.add(territories.allTerritories[i]);
                    j = territories.allTerritories[i].border.size();
                }
            }
        }
        for (int i = 0; i < territories.allTerritories.length; i++) {
            for (int j = 0; j < territories.allTerritories[i].border.size(); j++) {
                if (territories.allTerritories[i].isBlack && checkIfEnemyBordersBlack(territories.allTerritories[i])
                        && territories.allTerritories[i].units > 1
                        && territories.allTerritories[i].border.get(j).isKeyTerritory
                        && territories.allTerritories[i].hasLeader
                        && territories.allTerritories[i].border.get(j).isBlack == false) {
                    temp.add(territories.allTerritories[i]);
                    j = territories.allTerritories[i].border.size();
                }
            }
        }
        for (int i = 0; i < territories.allTerritories.length; i++) {
            for (int j = 0; j < territories.allTerritories[i].border.size(); j++) {
                if (territories.allTerritories[i].isBlack && checkIfEnemyBordersBlack(territories.allTerritories[i])
                        && territories.allTerritories[i].units > 1
                        && territories.allTerritories[i].border.get(j).units < territories.allTerritories[i].units / 2
                        && territories.allTerritories[i].border.get(j).units > 0
                        && territories.allTerritories[i].border.get(j).isBlack == false) {
                    temp.add(territories.allTerritories[i]);
                    j = territories.allTerritories[i].border.size();
                }
            }
        }
        for (int i = 0; i < territories.allTerritories.length; i++) {
            for (int j = 0; j < territories.allTerritories[i].border.size(); j++) {
                if (territories.allTerritories[i].isBlack && checkIfEnemyBordersBlack(territories.allTerritories[i])
                        && territories.allTerritories[i].units > 1
                        && territories.allTerritories[i].border.get(j).units < territories.allTerritories[i].units / 4
                        && territories.allTerritories[i].border.get(j).units > 0
                        && territories.allTerritories[i].border.get(j).isBlack == false) {
                    temp.add(territories.allTerritories[i]);
                    j = territories.allTerritories[i].border.size();
                }
            }
        }
        for (int i = 0; i < territories.allTerritories.length; i++) {
            for (int j = 0; j < territories.allTerritories[i].border.size(); j++) {
                if (territories.allTerritories[i].isBlack && checkIfEnemyBordersBlack(territories.allTerritories[i])
                        && territories.allTerritories[i].units > 1 && territories.allTerritories[i].isKeyTerritory
                        && territories.allTerritories[i].border.get(j).region
                        .equals(territories.allTerritories[i].region)
                        && territories.allTerritories[i].border.get(j).units < territories.allTerritories[i].units
                        && territories.allTerritories[i].border.get(j).units > 0
                        && territories.allTerritories[i].hasLeader
                        && territories.allTerritories[i].border.get(j).isBlack == false) {
                    temp.add(territories.allTerritories[i]);
                    j = territories.allTerritories[i].border.size();
                }
            }
        }
        numbersOfTerritories = temp.size();
        if (temp.size() > 0) {
            int randomTerritory = rand.nextInt((numbersOfTerritories));
            return temp.get(randomTerritory);
        } else {
            jPanel1.setVisible(true);
            String phrase = notAttacking(black);
            presentation.setText(phrase);
            return null;
        }
    }

    public Territory attackerYellow() {
        Random rand = new Random();
        int numbersOfTerritories = 0;
        ArrayList<Territory> temp = new ArrayList<>();
        for (int i = 0; i < territories.allTerritories.length; i++) {
            for (int j = 0; j < territories.allTerritories[i].border.size(); j++) {
                if (territories.allTerritories[i].isYellow && checkIfEnemyBordersYellow(territories.allTerritories[i])
                        && territories.allTerritories[i].units > 1) {
                    temp.add(territories.allTerritories[i]);
                    j = territories.allTerritories[i].border.size();
                }
            }
        }
        for (int i = 0; i < territories.allTerritories.length; i++) {
            for (int j = 0; j < territories.allTerritories[i].border.size(); j++) {
                if (territories.allTerritories[i].isYellow && checkIfEnemyBordersYellow(territories.allTerritories[i])
                        && territories.allTerritories[i].units > 1 && territories.allTerritories[i].hasLeader) {
                    j = territories.allTerritories[i].border.size();
                }
            }
        }
        for (int i = 0; i < territories.allTerritories.length; i++) {
            for (int j = 0; j < territories.allTerritories[i].border.size(); j++) {
                if (territories.allTerritories[i].isYellow && checkIfEnemyBordersYellow(territories.allTerritories[i])
                        && territories.allTerritories[i].units > 1
                        && territories.allTerritories[i].border.get(j).isKeyTerritory
                        && territories.allTerritories[i].border.get(j).isYellow == false) {
                    j = territories.allTerritories[i].border.size();
                }
            }
        }
        for (int i = 0; i < territories.allTerritories.length; i++) {
            for (int j = 0; j < territories.allTerritories[i].border.size(); j++) {
                if (territories.allTerritories[i].isYellow && checkIfEnemyBordersYellow(territories.allTerritories[i])
                        && territories.allTerritories[i].units > 1
                        && territories.allTerritories[i].border.get(j).region
                        .equals(territories.allTerritories[i].region)
                        && territories.allTerritories[i].border.get(j).isYellow == false) {
                    temp.add(territories.allTerritories[i]);
                    j = territories.allTerritories[i].border.size();
                }
            }
        }
        for (int i = 0; i < territories.allTerritories.length; i++) {
            for (int j = 0; j < territories.allTerritories[i].border.size(); j++) {
                if (territories.allTerritories[i].isYellow && checkIfEnemyBordersYellow(territories.allTerritories[i])
                        && territories.allTerritories[i].units > 1
                        && territories.allTerritories[i].border.get(j).units < territories.allTerritories[i].units
                        && territories.allTerritories[i].border.get(j).units > 0
                        && territories.allTerritories[i].border.get(j).isYellow == false) {
                    temp.add(territories.allTerritories[i]);
                    j = territories.allTerritories[i].border.size();
                }
            }
        }
        for (int i = 0; i < territories.allTerritories.length; i++) {
            for (int j = 0; j < territories.allTerritories[i].border.size(); j++) {
                if (territories.allTerritories[i].isYellow && checkIfEnemyBordersYellow(territories.allTerritories[i])
                        && territories.allTerritories[i].units > 1
                        && territories.allTerritories[i].border.get(j).units < territories.allTerritories[i].units
                        && territories.allTerritories[i].border.get(j).units > 0
                        && territories.allTerritories[i].hasLeader
                        && territories.allTerritories[i].border.get(j).isYellow == false) {
                    temp.add(territories.allTerritories[i]);
                    j = territories.allTerritories[i].border.size();
                }
            }
        }
        for (int i = 0; i < territories.allTerritories.length; i++) {
            for (int j = 0; j < territories.allTerritories[i].border.size(); j++) {
                if (territories.allTerritories[i].isYellow && checkIfEnemyBordersYellow(territories.allTerritories[i])
                        && territories.allTerritories[i].units > 1
                        && territories.allTerritories[i].border.get(j).units < territories.allTerritories[i].units
                        && territories.allTerritories[i].border.get(j).units > 0
                        && territories.allTerritories[i].border.get(j).isKeyTerritory
                        && territories.allTerritories[i].border.get(j).isYellow == false) {
                    temp.add(territories.allTerritories[i]);
                    j = territories.allTerritories[i].border.size();
                }
            }
        }
        for (int i = 0; i < territories.allTerritories.length; i++) {
            for (int j = 0; j < territories.allTerritories[i].border.size(); j++) {
                if (territories.allTerritories[i].isYellow && checkIfEnemyBordersYellow(territories.allTerritories[i])
                        && territories.allTerritories[i].units > 1
                        && territories.allTerritories[i].border.get(j).units < territories.allTerritories[i].units
                        && territories.allTerritories[i].border.get(j).units > 0
                        && territories.allTerritories[i].border.get(j).region
                        .equals(territories.allTerritories[i].region)
                        && territories.allTerritories[i].border.get(j).isYellow == false) {
                    temp.add(territories.allTerritories[i]);
                    j = territories.allTerritories[i].border.size();
                }
            }
        }
        for (int i = 0; i < territories.allTerritories.length; i++) {
            for (int j = 0; j < territories.allTerritories[i].border.size(); j++) {
                if (territories.allTerritories[i].isYellow && checkIfEnemyBordersYellow(territories.allTerritories[i])
                        && territories.allTerritories[i].units > 1
                        && territories.allTerritories[i].border.get(j).region
                        .equals(territories.allTerritories[i].region)
                        && territories.allTerritories[i].hasLeader
                        && territories.allTerritories[i].border.get(j).isYellow == false) {
                    temp.add(territories.allTerritories[i]);
                    j = territories.allTerritories[i].border.size();
                }
            }
        }
        for (int i = 0; i < territories.allTerritories.length; i++) {
            for (int j = 0; j < territories.allTerritories[i].border.size(); j++) {
                if (territories.allTerritories[i].isYellow && checkIfEnemyBordersYellow(territories.allTerritories[i])
                        && territories.allTerritories[i].units > 1
                        && territories.allTerritories[i].border.get(j).region
                        .equals(territories.allTerritories[i].region)
                        && territories.allTerritories[i].border.get(j).isKeyTerritory
                        && territories.allTerritories[i].border.get(j).isYellow == false) {
                    temp.add(territories.allTerritories[i]);
                    j = territories.allTerritories[i].border.size();
                }
            }
        }
        for (int i = 0; i < territories.allTerritories.length; i++) {
            for (int j = 0; j < territories.allTerritories[i].border.size(); j++) {
                if (territories.allTerritories[i].isYellow && checkIfEnemyBordersYellow(territories.allTerritories[i])
                        && territories.allTerritories[i].units > 1
                        && territories.allTerritories[i].border.get(j).isKeyTerritory
                        && territories.allTerritories[i].hasLeader
                        && territories.allTerritories[i].border.get(j).isYellow == false) {
                    temp.add(territories.allTerritories[i]);
                    j = territories.allTerritories[i].border.size();
                }
            }
        }
        for (int i = 0; i < territories.allTerritories.length; i++) {
            for (int j = 0; j < territories.allTerritories[i].border.size(); j++) {
                if (territories.allTerritories[i].isYellow && checkIfEnemyBordersYellow(territories.allTerritories[i])
                        && territories.allTerritories[i].units > 1
                        && territories.allTerritories[i].border.get(j).units < territories.allTerritories[i].units / 2
                        && territories.allTerritories[i].border.get(j).units > 0
                        && territories.allTerritories[i].border.get(j).isYellow == false) {
                    temp.add(territories.allTerritories[i]);
                    j = territories.allTerritories[i].border.size();
                }
            }
        }
        for (int i = 0; i < territories.allTerritories.length; i++) {
            for (int j = 0; j < territories.allTerritories[i].border.size(); j++) {
                if (territories.allTerritories[i].isYellow && checkIfEnemyBordersYellow(territories.allTerritories[i])
                        && territories.allTerritories[i].units > 1
                        && territories.allTerritories[i].border.get(j).units < territories.allTerritories[i].units / 4
                        && territories.allTerritories[i].border.get(j).units > 0
                        && territories.allTerritories[i].border.get(j).isYellow == false) {
                    temp.add(territories.allTerritories[i]);
                    j = territories.allTerritories[i].border.size();
                }
            }
        }
        for (int i = 0; i < territories.allTerritories.length; i++) {
            for (int j = 0; j < territories.allTerritories[i].border.size(); j++) {
                if (territories.allTerritories[i].isYellow && checkIfEnemyBordersYellow(territories.allTerritories[i])
                        && territories.allTerritories[i].units > 1 && territories.allTerritories[i].isKeyTerritory
                        && territories.allTerritories[i].border.get(j).region
                        .equals(territories.allTerritories[i].region)
                        && territories.allTerritories[i].border.get(j).units < territories.allTerritories[i].units
                        && territories.allTerritories[i].border.get(j).units > 0
                        && territories.allTerritories[i].hasLeader
                        && territories.allTerritories[i].border.get(j).isYellow == false) {
                    temp.add(territories.allTerritories[i]);
                    j = territories.allTerritories[i].border.size();
                }
            }
        }
        numbersOfTerritories = temp.size();
        if (temp.size() > 0) {
            int randomTerritory = rand.nextInt((numbersOfTerritories));
            return temp.get(randomTerritory);
        } else {
            jPanel1.setVisible(true);
            String phrase = notAttacking(yellow);
            presentation.setText(phrase);
            return null;
        }
    }

    public Territory attackerGreen() {
        Random rand = new Random();
        int numbersOfTerritories = 0;
        ArrayList<Territory> temp = new ArrayList<>();
        for (int i = 0; i < territories.allTerritories.length; i++) {
            for (int j = 0; j < territories.allTerritories[i].border.size(); j++) {
                if (territories.allTerritories[i].isGreen && checkIfEnemyBordersGreen(territories.allTerritories[i])
                        && territories.allTerritories[i].units > 1) {
                    temp.add(territories.allTerritories[i]);
                    j = territories.allTerritories[i].border.size();
                }
            }
        }
        for (int i = 0; i < territories.allTerritories.length; i++) {
            for (int j = 0; j < territories.allTerritories[i].border.size(); j++) {
                if (territories.allTerritories[i].isGreen && checkIfEnemyBordersGreen(territories.allTerritories[i])
                        && territories.allTerritories[i].units > 1 && territories.allTerritories[i].hasLeader) {
                    j = territories.allTerritories[i].border.size();
                }
            }
        }
        for (int i = 0; i < territories.allTerritories.length; i++) {
            for (int j = 0; j < territories.allTerritories[i].border.size(); j++) {
                if (territories.allTerritories[i].isGreen && checkIfEnemyBordersGreen(territories.allTerritories[i])
                        && territories.allTerritories[i].units > 1
                        && territories.allTerritories[i].border.get(j).isKeyTerritory
                        && territories.allTerritories[i].border.get(j).isGreen == false) {
                    j = territories.allTerritories[i].border.size();
                }
            }
        }
        for (int i = 0; i < territories.allTerritories.length; i++) {
            for (int j = 0; j < territories.allTerritories[i].border.size(); j++) {
                if (territories.allTerritories[i].isGreen && checkIfEnemyBordersGreen(territories.allTerritories[i])
                        && territories.allTerritories[i].units > 1
                        && territories.allTerritories[i].border.get(j).region
                        .equals(territories.allTerritories[i].region)
                        && territories.allTerritories[i].border.get(j).isGreen == false) {
                    temp.add(territories.allTerritories[i]);
                    j = territories.allTerritories[i].border.size();
                }
            }
        }
        for (int i = 0; i < territories.allTerritories.length; i++) {
            for (int j = 0; j < territories.allTerritories[i].border.size(); j++) {
                if (territories.allTerritories[i].isGreen && checkIfEnemyBordersGreen(territories.allTerritories[i])
                        && territories.allTerritories[i].units > 1
                        && territories.allTerritories[i].border.get(j).units < territories.allTerritories[i].units
                        && territories.allTerritories[i].border.get(j).units > 0
                        && territories.allTerritories[i].border.get(j).isGreen == false) {
                    temp.add(territories.allTerritories[i]);
                    j = territories.allTerritories[i].border.size();
                }
            }
        }
        for (int i = 0; i < territories.allTerritories.length; i++) {
            for (int j = 0; j < territories.allTerritories[i].border.size(); j++) {
                if (territories.allTerritories[i].isGreen && checkIfEnemyBordersGreen(territories.allTerritories[i])
                        && territories.allTerritories[i].units > 1
                        && territories.allTerritories[i].border.get(j).units < territories.allTerritories[i].units
                        && territories.allTerritories[i].border.get(j).units > 0
                        && territories.allTerritories[i].hasLeader
                        && territories.allTerritories[i].border.get(j).isGreen == false) {
                    temp.add(territories.allTerritories[i]);
                    j = territories.allTerritories[i].border.size();
                }
            }
        }
        for (int i = 0; i < territories.allTerritories.length; i++) {
            for (int j = 0; j < territories.allTerritories[i].border.size(); j++) {
                if (territories.allTerritories[i].isGreen && checkIfEnemyBordersGreen(territories.allTerritories[i])
                        && territories.allTerritories[i].units > 1
                        && territories.allTerritories[i].border.get(j).units < territories.allTerritories[i].units
                        && territories.allTerritories[i].border.get(j).units > 0
                        && territories.allTerritories[i].border.get(j).isKeyTerritory
                        && territories.allTerritories[i].border.get(j).isGreen == false) {
                    temp.add(territories.allTerritories[i]);
                    j = territories.allTerritories[i].border.size();
                }
            }
        }
        for (int i = 0; i < territories.allTerritories.length; i++) {
            for (int j = 0; j < territories.allTerritories[i].border.size(); j++) {
                if (territories.allTerritories[i].isGreen && checkIfEnemyBordersGreen(territories.allTerritories[i])
                        && territories.allTerritories[i].units > 1
                        && territories.allTerritories[i].border.get(j).units < territories.allTerritories[i].units
                        && territories.allTerritories[i].border.get(j).units > 0
                        && territories.allTerritories[i].border.get(j).region
                        .equals(territories.allTerritories[i].region)
                        && territories.allTerritories[i].border.get(j).isGreen == false) {
                    temp.add(territories.allTerritories[i]);
                    j = territories.allTerritories[i].border.size();
                }
            }
        }
        for (int i = 0; i < territories.allTerritories.length; i++) {
            for (int j = 0; j < territories.allTerritories[i].border.size(); j++) {
                if (territories.allTerritories[i].isGreen && checkIfEnemyBordersGreen(territories.allTerritories[i])
                        && territories.allTerritories[i].units > 1
                        && territories.allTerritories[i].border.get(j).region
                        .equals(territories.allTerritories[i].region)
                        && territories.allTerritories[i].hasLeader
                        && territories.allTerritories[i].border.get(j).isGreen == false) {
                    temp.add(territories.allTerritories[i]);
                    j = territories.allTerritories[i].border.size();
                }
            }
        }
        for (int i = 0; i < territories.allTerritories.length; i++) {
            for (int j = 0; j < territories.allTerritories[i].border.size(); j++) {
                if (territories.allTerritories[i].isGreen && checkIfEnemyBordersGreen(territories.allTerritories[i])
                        && territories.allTerritories[i].units > 1
                        && territories.allTerritories[i].border.get(j).region
                        .equals(territories.allTerritories[i].region)
                        && territories.allTerritories[i].border.get(j).isKeyTerritory
                        && territories.allTerritories[i].border.get(j).isGreen == false) {
                    temp.add(territories.allTerritories[i]);
                    j = territories.allTerritories[i].border.size();
                }
            }
        }
        for (int i = 0; i < territories.allTerritories.length; i++) {
            for (int j = 0; j < territories.allTerritories[i].border.size(); j++) {
                if (territories.allTerritories[i].isGreen && checkIfEnemyBordersGreen(territories.allTerritories[i])
                        && territories.allTerritories[i].units > 1
                        && territories.allTerritories[i].border.get(j).isKeyTerritory
                        && territories.allTerritories[i].hasLeader
                        && territories.allTerritories[i].border.get(j).isGreen == false) {
                    temp.add(territories.allTerritories[i]);
                    j = territories.allTerritories[i].border.size();
                }
            }
        }
        for (int i = 0; i < territories.allTerritories.length; i++) {
            for (int j = 0; j < territories.allTerritories[i].border.size(); j++) {
                if (territories.allTerritories[i].isGreen && checkIfEnemyBordersGreen(territories.allTerritories[i])
                        && territories.allTerritories[i].units > 1
                        && territories.allTerritories[i].border.get(j).units < territories.allTerritories[i].units / 2
                        && territories.allTerritories[i].border.get(j).units > 0
                        && territories.allTerritories[i].border.get(j).isGreen == false) {
                    temp.add(territories.allTerritories[i]);
                    j = territories.allTerritories[i].border.size();
                }
            }
        }
        for (int i = 0; i < territories.allTerritories.length; i++) {
            for (int j = 0; j < territories.allTerritories[i].border.size(); j++) {
                if (territories.allTerritories[i].isGreen && checkIfEnemyBordersGreen(territories.allTerritories[i])
                        && territories.allTerritories[i].units > 1
                        && territories.allTerritories[i].border.get(j).units < territories.allTerritories[i].units / 4
                        && territories.allTerritories[i].border.get(j).units > 0
                        && territories.allTerritories[i].border.get(j).isGreen == false) {
                    temp.add(territories.allTerritories[i]);
                    j = territories.allTerritories[i].border.size();
                }
            }
        }
        for (int i = 0; i < territories.allTerritories.length; i++) {
            for (int j = 0; j < territories.allTerritories[i].border.size(); j++) {
                if (territories.allTerritories[i].isGreen && checkIfEnemyBordersGreen(territories.allTerritories[i])
                        && territories.allTerritories[i].units > 1 && territories.allTerritories[i].isKeyTerritory
                        && territories.allTerritories[i].border.get(j).region
                        .equals(territories.allTerritories[i].region)
                        && territories.allTerritories[i].border.get(j).units < territories.allTerritories[i].units
                        && territories.allTerritories[i].border.get(j).units > 0
                        && territories.allTerritories[i].hasLeader
                        && territories.allTerritories[i].border.get(j).isGreen == false) {
                    temp.add(territories.allTerritories[i]);
                    j = territories.allTerritories[i].border.size();
                }
            }
        }
        numbersOfTerritories = temp.size();
        if (temp.size() > 0) {
            int randomTerritory = rand.nextInt((numbersOfTerritories));
            return temp.get(randomTerritory);
        } else {
            jPanel1.setVisible(true);
            String phrase = notAttacking(green);
            presentation.setText(phrase);
            return null;
        }
    }

    public int attackingUnits(Territory attacker) {
        Random rand = new Random();
        int numberOfUnits;
        int randomTemp;
        if (attacker.units > 0) {
            numberOfUnits = rand.nextInt((attacker.units - 1) + 1);
            if (numberOfUnits == 1 && attacker.units > 2) {
                while (true) {
                    numberOfUnits = rand.nextInt((attacker.units - 1) + 1);
                    if (numberOfUnits != 1) {
                        break;
                    }
                }
            }
            if (numberOfUnits == 0) {
                numberOfUnits = 1;
            }
        } else {
            numberOfUnits = 0;
        }
        if (numberOfUnits < attacker.units / 2) {
            randomTemp = rand.nextInt(10);
            if (randomTemp > 4) {
                numberOfUnits = attacker.units - 1;
            }
        }
        return numberOfUnits;
    }

    public boolean checkIfEnemyBordersRed(Territory attacker) {
        boolean possibleAttacks = false;
        ArrayList<Territory> borders = attacker.border;
        for (int i = 0; i < borders.size(); i++) {
            if (borders.get(i).isRed == false) {
                possibleAttacks = true;
            }
        }
        return possibleAttacks;
    }

    public boolean checkIfEnemyBordersBlack(Territory attacker) {
        boolean possibleAttacks = false;
        ArrayList<Territory> borders = attacker.border;
        for (int i = 0; i < borders.size(); i++) {
            if (borders.get(i).isBlack == false) {
                possibleAttacks = true;
            }
        }
        return possibleAttacks;
    }

    public boolean checkIfEnemyBordersYellow(Territory attacker) {
        boolean possibleAttacks = false;
        ArrayList<Territory> borders = attacker.border;
        for (int i = 0; i < borders.size(); i++) {
            if (borders.get(i).isYellow == false) {
                possibleAttacks = true;
            }
        }
        return possibleAttacks;
    }

    public boolean checkIfEnemyBordersGreen(Territory attacker) {
        boolean possibleAttacks = false;
        ArrayList<Territory> borders = attacker.border;
        for (int i = 0; i < borders.size(); i++) {
            if (borders.get(i).isGreen == false) {
                possibleAttacks = true;
            }
        }
        return possibleAttacks;
    }

    public String attackingPhraseRed(String attacker, String defender, int attackingUnits, String leaderPhrase) {
        String intro = introduction(attackingUnits);
        String preposition = preposition();
        String preposition2 = preposition2();
        String noun = noun();
        String interpunction = interpunction();
        String ending = ending(red);
        String units = "";
        if (attackingUnits > 1) {
            units = oneOrMore(2);
        } else {
            units = oneOrMore(1);
        }
        String phrase = intro + defender + preposition + attacker + preposition2 + attackingUnits + noun + units
                + interpunction + " " + ending + " " + leaderPhrase;
        return phrase;
    }

    public String attackingPhraseBlack(String attacker, String defender, int attackingUnits, String leaderPhrase) {
        String intro = introduction(attackingUnits);
        String preposition = preposition();
        String preposition2 = preposition2();
        String noun = noun();
        String interpunction = interpunction();
        String ending = ending(black);
        String units = "";
        if (attackingUnits > 1) {
            units = oneOrMore(2);
        } else {
            units = oneOrMore(1);
        }
        String phrase = intro + defender + preposition + attacker + preposition2 + attackingUnits + noun + units
                + interpunction + " " + ending + " " + leaderPhrase;
        return phrase;
    }

    public String attackingPhraseYellow(String attacker, String defender, int attackingUnits, String leaderPhrase) {
        String intro = introduction(attackingUnits);
        String preposition = preposition();
        String preposition2 = preposition2();
        String noun = noun();
        String interpunction = interpunction();
        String ending = ending(yellow);
        String units = "";
        if (attackingUnits > 1) {
            units = oneOrMore(2);
        } else {
            units = oneOrMore(1);
        }
        String phrase = intro + defender + preposition + attacker + preposition2 + attackingUnits + noun + units
                + interpunction + " " + ending + " " + leaderPhrase;
        return phrase;
    }

    public String attackingPhraseGreen(String attacker, String defender, int attackingUnits, String leaderPhrase) {
        String intro = introduction(attackingUnits);
        String preposition = preposition();
        String preposition2 = preposition2();
        String noun = noun();
        String interpunction = interpunction();
        String ending = ending(green);
        String units = "";
        if (attackingUnits > 1) {
            units = oneOrMore(2);
        } else {
            units = oneOrMore(1);
        }
        String phrase = intro + defender + preposition + attacker + preposition2 + attackingUnits + noun + units
                + interpunction + " " + ending + " " + leaderPhrase;
        return phrase;
    }

    public boolean didIWin() {
        boolean questionAnswered = false;
        boolean win = false;
        while (questionAnswered == false) {
            String answer = didIWinQuestion();
            if (answer.equals("W")) {
                questionAnswered = true;
                win = true;
            } else if (answer.equals("L")) {
                questionAnswered = true;
            }
        }
        return win;
    }

    public void leaderIsKilled(Territory attacker) {
        attacker.hasLeader = false;

    }

    public void leaderIsBorn(Territory attacker) {
        attacker.hasLeader = true;
    }

    public void unitsRed() {
        button1.setVisible(false);
        button2.setVisible(false);
        button3.setVisible(false);
        button4.setVisible(false);
        button5.setVisible(false);
        button6.setVisible(false);
        button7.setVisible(false);
        button8.setVisible(false);
        textField.setVisible(true);
        buttonOkUnitsAdd.setVisible(true);
        events.setText("How many units do I get to place?");
    }

    public void unitsBlack() {
        button1.setVisible(false);
        button2.setVisible(false);
        button3.setVisible(false);
        button4.setVisible(false);
        button5.setVisible(false);
        button6.setVisible(false);
        button7.setVisible(false);
        button8.setVisible(false);
        textField.setVisible(true);
        buttonOkUnitsAdd.setVisible(true);
        events.setText("How many units do I get to place?");
    }

    public void unitsYellow() {
        button1.setVisible(false);
        button2.setVisible(false);
        button3.setVisible(false);
        button4.setVisible(false);
        button5.setVisible(false);
        button6.setVisible(false);
        button7.setVisible(false);
        button8.setVisible(false);
        textField.setVisible(true);
        buttonOkUnitsAdd.setVisible(true);
        events.setText("How many units do I get to place?");
    }

    public void unitsGreen() {
        button1.setVisible(false);
        button2.setVisible(false);
        button3.setVisible(false);
        button4.setVisible(false);
        button5.setVisible(false);
        button6.setVisible(false);
        button7.setVisible(false);
        button8.setVisible(false);
        textField.setVisible(true);
        buttonOkUnitsAdd.setVisible(true);
        events.setText("How many units do I get to place?");
    }

    public void placeUnitsRed() {
        try {
            jPanel1.setVisible(true);
            int howMany = units;
            units = 0;
            String intro = putUnits();
            String units = "";
            ArrayList<Territory> temp = new ArrayList<>();
            for (int i = 0; i < territories.allTerritories.length; i++) {
                if (territories.allTerritories[i].isRed) {
                    temp.add(territories.allTerritories[i]);
                }
            }
            terrritorieLabel.setText(intro);
            while (howMany > 0) {
                Random rand = new Random();
                int randomTerritory = rand.nextInt((temp.size()));
                int randomUnits = rand.nextInt((howMany) + 1);
                if (randomUnits > howMany / 2 && randomUnits > 1) {
                    randomUnits = rand.nextInt((howMany / 2) + 1);
                }
                if (randomUnits > 0) {
                    if (temp.size() == 1) {
                        randomUnits = howMany;
                    }
                    temp.get(randomTerritory).units += randomUnits;
                    if (randomUnits > 1) {
                        units = oneOrMore(2);
                    } else {
                        units = oneOrMore(1);
                    }
                    String kindOfUnits = noun();
                    String territoryDescrription = territoryDescription();
                    String ending = interpunction();
                    String phrase = randomUnits + kindOfUnits + units + territoryDescrription
                            + temp.get(randomTerritory).name + ending + "\n";
                    textArea.append(phrase);
                    System.out.println(phrase);
                }
                howMany -= randomUnits;
                if (temp.size() > 1) {
                    temp.remove(randomTerritory);
                }
            }
        } catch (InputMismatchException e) {
            menuRed();
        }
        menuRed();
    }

    public void placeUnitsBlack() {
        try {
            jPanel1.setVisible(true);
            int howMany = units;
            units = 0;
            String intro = putUnits();
            String units = "";
            ArrayList<Territory> temp = new ArrayList<>();
            for (int i = 0; i < territories.allTerritories.length; i++) {
                if (territories.allTerritories[i].isBlack) {
                    temp.add(territories.allTerritories[i]);
                }
            }
            terrritorieLabel.setText(intro);
            while (howMany > 0) {
                Random rand = new Random();
                int randomTerritory = rand.nextInt((temp.size()));
                int randomUnits = rand.nextInt((howMany) + 1);
                if (randomUnits > howMany / 2 && randomUnits > 1) {
                    randomUnits = rand.nextInt((howMany / 2) + 1);
                }
                if (randomUnits > 0) {
                    if (temp.size() == 1) {
                        randomUnits = howMany;
                    }
                    temp.get(randomTerritory).units += randomUnits;
                    if (randomUnits > 1) {
                        units = oneOrMore(2);
                    } else {
                        units = oneOrMore(1);
                    }
                    String kindOfUnits = noun();
                    String territoryDescrription = territoryDescription();
                    String ending = interpunction();
                    String phrase = randomUnits + kindOfUnits + units + territoryDescrription
                            + temp.get(randomTerritory).name + ending + "\n";
                    textArea.append(phrase);
                    System.out.println(phrase);
                }
                howMany -= randomUnits;
                if (temp.size() > 1) {
                    temp.remove(randomTerritory);
                }
            }
        } catch (InputMismatchException e) {
            menuBlack();
        }
        menuBlack();
    }

    public void placeUnitsyellow() {
        try {
            jPanel1.setVisible(true);
            int howMany = units;
            units = 0;
            String intro = putUnits();
            String units = "";
            ArrayList<Territory> temp = new ArrayList<>();
            for (int i = 0; i < territories.allTerritories.length; i++) {
                if (territories.allTerritories[i].isYellow) {
                    temp.add(territories.allTerritories[i]);
                }
            }
            terrritorieLabel.setText(intro);
            while (howMany > 0) {
                Random rand = new Random();
                int randomTerritory = rand.nextInt((temp.size()));
                int randomUnits = rand.nextInt((howMany) + 1);
                if (randomUnits > howMany / 2 && randomUnits > 1) {
                    randomUnits = rand.nextInt((howMany / 2) + 1);
                }
                if (randomUnits > 0) {
                    if (temp.size() == 1) {
                        randomUnits = howMany;
                    }
                    temp.get(randomTerritory).units += randomUnits;
                    if (randomUnits > 1) {
                        units = oneOrMore(2);
                    } else {
                        units = oneOrMore(1);
                    }
                    String kindOfUnits = noun();
                    String territoryDescrription = territoryDescription();
                    String ending = interpunction();
                    String phrase = randomUnits + kindOfUnits + units + territoryDescrription
                            + temp.get(randomTerritory).name + ending + "\n";
                    textArea.append(phrase);
                    System.out.println(phrase);
                }
                howMany -= randomUnits;
                if (temp.size() > 1) {
                    temp.remove(randomTerritory);
                }
            }
        } catch (InputMismatchException e) {
            menuYellow();
        }
        menuYellow();
    }

    public void placeUnitsGreen() {
        try {
            jPanel1.setVisible(true);
            int howMany = units;
            units = 0;
            String intro = putUnits();
            String units = "";
            ArrayList<Territory> temp = new ArrayList<>();
            for (int i = 0; i < territories.allTerritories.length; i++) {
                if (territories.allTerritories[i].isGreen) {
                    temp.add(territories.allTerritories[i]);
                }
            }
            terrritorieLabel.setText(intro);
            while (howMany > 0) {
                Random rand = new Random();
                int randomTerritory = rand.nextInt((temp.size()));
                int randomUnits = rand.nextInt((howMany) + 1);
                if (randomUnits > howMany / 2 && randomUnits > 1) {
                    randomUnits = rand.nextInt((howMany / 2) + 1);
                }
                if (randomUnits > 0) {
                    if (temp.size() == 1) {
                        randomUnits = howMany;
                    }
                    temp.get(randomTerritory).units += randomUnits;
                    if (randomUnits > 1) {
                        units = oneOrMore(2);
                    } else {
                        units = oneOrMore(1);
                    }
                    String kindOfUnits = noun();
                    String territoryDescrription = territoryDescription();
                    String ending = interpunction();
                    String phrase = randomUnits + kindOfUnits + units + territoryDescrription
                            + temp.get(randomTerritory).name + ending + "\n";
                    textArea.append(phrase);
                    System.out.println(phrase);
                }
                howMany -= randomUnits;
                if (temp.size() > 1) {
                    temp.remove(randomTerritory);
                }
            }
        } catch (InputMismatchException e) {
            menuGreen();
        }
        menuGreen();
    }

    public void placeLeaderRed() {
        ArrayList<Territory> temp = new ArrayList<>();
        ArrayList<Territory> hasLeaders = new ArrayList<>();
        for (int i = 0; i < territories.allTerritories.length; i++) {
            if (territories.allTerritories[i].isRed && territories.allTerritories[i].hasLeader) {
                hasLeaders.add(territories.allTerritories[i]);
            }
        }
        for (int i = 0; i < territories.allTerritories.length; i++) {
            if (territories.allTerritories[i].isRed && territories.allTerritories[i].hasLeader == false
                    && hasLeaders.size() <= 1) {
                temp.add(territories.allTerritories[i]);
            }
            if (territories.allTerritories[i].isRed && territories.allTerritories[i].hasLeader == false
                    && hasLeaders.size() <= 1 && territories.allTerritories[i].isKeyTerritory) {
                temp.add(territories.allTerritories[i]);
            }
            if (territories.allTerritories[i].isRed && territories.allTerritories[i].hasLeader == false
                    && hasLeaders.size() <= 1 && territories.allTerritories[i].units > 5) {
                temp.add(territories.allTerritories[i]);
            }
            if (territories.allTerritories[i].isRed && territories.allTerritories[i].hasLeader == false
                    && hasLeaders.size() <= 1 && territories.allTerritories[i].units > 10) {
                temp.add(territories.allTerritories[i]);
            }
        }
        Random rand = new Random();
        if (temp.size() > 0) {
            int randomTerrytory = rand.nextInt(temp.size());
            leaderIsBorn(temp.get(randomTerrytory));
            String noun = noun();
            presentation.setText("I put one" + noun + "leader in " + temp.get(randomTerrytory).name + ".");
        } else {
            presentation.setText("I cannot place any more leaders.");
        }
    }

    public void placeLeaderBlack() {
        ArrayList<Territory> temp = new ArrayList<>();
        ArrayList<Territory> hasLeaders = new ArrayList<>();
        for (int i = 0; i < territories.allTerritories.length; i++) {
            if (territories.allTerritories[i].isBlack && territories.allTerritories[i].hasLeader) {
                hasLeaders.add(territories.allTerritories[i]);
            }
        }
        for (int i = 0; i < territories.allTerritories.length; i++) {
            if (territories.allTerritories[i].isBlack && territories.allTerritories[i].hasLeader == false
                    && hasLeaders.size() <= 1) {
                temp.add(territories.allTerritories[i]);
            }
            if (territories.allTerritories[i].isBlack && territories.allTerritories[i].hasLeader == false
                    && hasLeaders.size() <= 1 && territories.allTerritories[i].isKeyTerritory) {
                temp.add(territories.allTerritories[i]);
            }
            if (territories.allTerritories[i].isBlack && territories.allTerritories[i].hasLeader == false
                    && hasLeaders.size() <= 1 && territories.allTerritories[i].units > 5) {
                temp.add(territories.allTerritories[i]);
            }
            if (territories.allTerritories[i].isBlack && territories.allTerritories[i].hasLeader == false
                    && hasLeaders.size() <= 1 && territories.allTerritories[i].units > 10) {
                temp.add(territories.allTerritories[i]);
            }
        }
        Random rand = new Random();
        if (temp.size() > 0) {
            int randomTerrytory = rand.nextInt(temp.size());
            leaderIsBorn(temp.get(randomTerrytory));
            String noun = noun();
            presentation.setText("I put one" + noun + "leader in " + temp.get(randomTerrytory).name + ".");
        } else {
            presentation.setText("I cannot place any more leaders.");
        }
    }

    public void placeLeaderYellow() {
        ArrayList<Territory> temp = new ArrayList<>();
        ArrayList<Territory> hasLeaders = new ArrayList<>();
        for (int i = 0; i < territories.allTerritories.length; i++) {
            if (territories.allTerritories[i].isYellow && territories.allTerritories[i].hasLeader) {
                hasLeaders.add(territories.allTerritories[i]);
            }
        }
        for (int i = 0; i < territories.allTerritories.length; i++) {
            if (territories.allTerritories[i].isYellow && territories.allTerritories[i].hasLeader == false
                    && hasLeaders.size() <= 1) {
                temp.add(territories.allTerritories[i]);
            }
            if (territories.allTerritories[i].isYellow && territories.allTerritories[i].hasLeader == false
                    && hasLeaders.size() <= 1 && territories.allTerritories[i].isKeyTerritory) {
                temp.add(territories.allTerritories[i]);
            }
            if (territories.allTerritories[i].isYellow && territories.allTerritories[i].hasLeader == false
                    && hasLeaders.size() <= 1 && territories.allTerritories[i].units > 5) {
                temp.add(territories.allTerritories[i]);
            }
            if (territories.allTerritories[i].isYellow && territories.allTerritories[i].hasLeader == false
                    && hasLeaders.size() <= 1 && territories.allTerritories[i].units > 10) {
                temp.add(territories.allTerritories[i]);
            }
        }
        Random rand = new Random();
        if (temp.size() > 0) {
            int randomTerrytory = rand.nextInt(temp.size());
            leaderIsBorn(temp.get(randomTerrytory));
            String noun = noun();
            presentation.setText("I put one" + noun + "leader in " + temp.get(randomTerrytory).name + ".");
        } else {
            presentation.setText("I cannot place any more leaders.");
        }
    }

    public void placeLeaderGreen() {
        ArrayList<Territory> temp = new ArrayList<>();
        ArrayList<Territory> hasLeaders = new ArrayList<>();
        for (int i = 0; i < territories.allTerritories.length; i++) {
            if (territories.allTerritories[i].isGreen && territories.allTerritories[i].hasLeader) {
                hasLeaders.add(territories.allTerritories[i]);
            }
        }
        for (int i = 0; i < territories.allTerritories.length; i++) {
            if (territories.allTerritories[i].isGreen && territories.allTerritories[i].hasLeader == false
                    && hasLeaders.size() <= 1) {
                temp.add(territories.allTerritories[i]);
            }
            if (territories.allTerritories[i].isGreen && territories.allTerritories[i].hasLeader == false
                    && hasLeaders.size() <= 1 && territories.allTerritories[i].isKeyTerritory) {
                temp.add(territories.allTerritories[i]);
            }
            if (territories.allTerritories[i].isGreen && territories.allTerritories[i].hasLeader == false
                    && hasLeaders.size() <= 1 && territories.allTerritories[i].units > 5) {
                temp.add(territories.allTerritories[i]);
            }
            if (territories.allTerritories[i].isGreen && territories.allTerritories[i].hasLeader == false
                    && hasLeaders.size() <= 1 && territories.allTerritories[i].units > 10) {
                temp.add(territories.allTerritories[i]);
            }
        }
        Random rand = new Random();
        if (temp.size() > 0) {
            int randomTerrytory = rand.nextInt(temp.size());
            leaderIsBorn(temp.get(randomTerrytory));
            String noun = noun();
            presentation.setText("I put one" + noun + "leader in " + temp.get(randomTerrytory).name + ".");
        } else {
            presentation.setText("I cannot place any more leaders.");
        }
    }

    public void removeLeaderRed() {
        Random rand = new Random();
        ArrayList<Territory> temp = new ArrayList<>();
        for (int i = 0; i < territories.allTerritories.length; i++) {
            if (territories.allTerritories[i].hasLeader && territories.allTerritories[i].isRed) {
                temp.add(territories.allTerritories[i]);
            }
        }
        if (temp.size() > 0) {
            int randomTerrytory = rand.nextInt(temp.size());
            leaderIsKilled(temp.get(randomTerrytory));
            String noun = noun();
            presentation.setText("The" + noun + "leader in " + temp.get(randomTerrytory).name + " has been killed.");
        }
        showTerritoriesRed();
        menuRed();
    }

    public void removeLeaderBlack() {
        Random rand = new Random();
        ArrayList<Territory> temp = new ArrayList<>();
        for (int i = 0; i < territories.allTerritories.length; i++) {
            if (territories.allTerritories[i].hasLeader && territories.allTerritories[i].isBlack) {
                temp.add(territories.allTerritories[i]);
            }
        }
        if (temp.size() > 0) {
            int randomTerrytory = rand.nextInt(temp.size());
            leaderIsKilled(temp.get(randomTerrytory));
            String noun = noun();
            presentation.setText("The" + noun + "leader in " + temp.get(randomTerrytory).name + " has been killed.");
        }
        showTerritoriesBlack();
        menuBlack();
    }

    public void removeLeaderYellow() {
        Random rand = new Random();
        ArrayList<Territory> temp = new ArrayList<>();
        for (int i = 0; i < territories.allTerritories.length; i++) {
            if (territories.allTerritories[i].hasLeader && territories.allTerritories[i].isYellow) {
                temp.add(territories.allTerritories[i]);
            }
        }
        if (temp.size() > 0) {
            int randomTerrytory = rand.nextInt(temp.size());
            leaderIsKilled(temp.get(randomTerrytory));
            String noun = noun();
            presentation.setText("The" + noun + "leader in " + temp.get(randomTerrytory).name + " has been killed.");
        }
        showTerritoriesYellow();
        menuBlack();
    }

    public void removeLeaderGreen() {
        Random rand = new Random();
        ArrayList<Territory> temp = new ArrayList<>();
        for (int i = 0; i < territories.allTerritories.length; i++) {
            if (territories.allTerritories[i].hasLeader && territories.allTerritories[i].isGreen) {
                temp.add(territories.allTerritories[i]);
            }
        }
        if (temp.size() > 0) {
            int randomTerrytory = rand.nextInt(temp.size());
            leaderIsKilled(temp.get(randomTerrytory));
            String noun = noun();
            presentation.setText("The" + noun + "leader in " + temp.get(randomTerrytory).name + " has been killed.");
        }
        showTerritoriesGreen();
        menuBlack();
    }

    public void moveRed() {
        Random rand = new Random();
        int numbersOfTerritories = 0;
        String units;
        ArrayList<Territory> temp = new ArrayList<>();
        for (int i = 0; i < territories.allTerritories.length; i++) {
            if (territories.allTerritories[i].isRed && checkIfFriendlyBordersRed(territories.allTerritories[i])) {
                temp.add(territories.allTerritories[i]);
            }
        }
        numbersOfTerritories = temp.size();
        String leader = "";
        if (numbersOfTerritories == 0) {
            String phrase = notMoving(red);
            System.out.println(phrase);
            menuRed();
        }
        int randomTerritory = rand.nextInt((numbersOfTerritories));
        if (temp.size() > 0) {
            Territory moveFrom = temp.get(randomTerritory);
            try {
                Territory moveTo = moveToRed(temp.get(randomTerritory));

                int movingUnits = rand.nextInt(moveFrom.units);
                if (movingUnits > 0 && movingUnits < moveFrom.units) {
                    moveFrom.units -= movingUnits;
                    moveTo.units += movingUnits;
                    if (moveFrom.hasLeader) {
                        leaderIsKilled(moveFrom);
                        leaderIsBorn(moveTo);
                        leader = leaderPhrase();
                    }
                    if (movingUnits > 1) {
                        units = oneOrMore(2);
                    } else {
                        units = oneOrMore(1);
                    }
                    presentation.setText("I move " + movingUnits + " " + units + " from " + moveFrom.name + " to "
                            + moveTo.name + ". " + leader);
                } else {
                    String phrase = notMoving(red);
                    presentation.setText(phrase);
                }

            } catch (NullPointerException | IllegalArgumentException e) {
                String phrase = notMoving(red);
                System.out.println(phrase);
                menuRed();
            }
        }
    }

    public void moveBlack() {
        Random rand = new Random();
        int numbersOfTerritories = 0;
        String units;
        ArrayList<Territory> temp = new ArrayList<>();
        for (int i = 0; i < territories.allTerritories.length; i++) {
            if (territories.allTerritories[i].isBlack && checkIfFriendlyBordersBlack(territories.allTerritories[i])) {
                temp.add(territories.allTerritories[i]);
            }
        }
        numbersOfTerritories = temp.size();
        String leader = "";
        if (numbersOfTerritories == 0) {
            String phrase = notMoving(black);
            System.out.println(phrase);
            menuBlack();
        }
        int randomTerritory = rand.nextInt((numbersOfTerritories));
        if (temp.size() > 0) {
            Territory moveFrom = temp.get(randomTerritory);
            try {
                Territory moveTo = moveToBlack(temp.get(randomTerritory));

                int movingUnits = rand.nextInt(moveFrom.units);
                if (movingUnits > 0 && movingUnits < moveFrom.units) {
                    moveFrom.units -= movingUnits;
                    moveTo.units += movingUnits;
                    if (moveFrom.hasLeader) {
                        leaderIsKilled(moveFrom);
                        leaderIsBorn(moveTo);
                        leader = leaderPhrase();
                    }
                    if (movingUnits > 1) {
                        units = oneOrMore(2);
                    } else {
                        units = oneOrMore(1);
                    }
                    presentation.setText("I move " + movingUnits + " " + units + " from " + moveFrom.name + " to "
                            + moveTo.name + ". " + leader);
                } else {
                    String phrase = notMoving(black);
                    presentation.setText(phrase);
                }

            } catch (NullPointerException | IllegalArgumentException e) {
                String phrase = notMoving(black);
                System.out.println(phrase);
                menuBlack();
            }
        }
    }

    public void moveYellow() {
        Random rand = new Random();
        int numbersOfTerritories = 0;
        String units;
        ArrayList<Territory> temp = new ArrayList<>();
        for (int i = 0; i < territories.allTerritories.length; i++) {
            if (territories.allTerritories[i].isYellow && checkIfFriendlyBordersYellow(territories.allTerritories[i])) {
                temp.add(territories.allTerritories[i]);
            }
        }
        numbersOfTerritories = temp.size();
        String leader = "";
        if (numbersOfTerritories == 0) {
            String phrase = notMoving(yellow);
            System.out.println(phrase);
            menuYellow();
        }
        int randomTerritory = rand.nextInt((numbersOfTerritories));
        if (temp.size() > 0) {
            Territory moveFrom = temp.get(randomTerritory);
            try {
                Territory moveTo = moveToYellow(temp.get(randomTerritory));

                int movingUnits = rand.nextInt(moveFrom.units);
                if (movingUnits > 0 && movingUnits < moveFrom.units) {
                    moveFrom.units -= movingUnits;
                    moveTo.units += movingUnits;
                    if (moveFrom.hasLeader) {
                        leaderIsKilled(moveFrom);
                        leaderIsBorn(moveTo);
                        leader = leaderPhrase();
                    }
                    if (movingUnits > 1) {
                        units = oneOrMore(2);
                    } else {
                        units = oneOrMore(1);
                    }
                    presentation.setText("I move " + movingUnits + " " + units + " from " + moveFrom.name + " to "
                            + moveTo.name + ". " + leader);
                } else {
                    String phrase = notMoving(yellow);
                    presentation.setText(phrase);
                }

            } catch (NullPointerException | IllegalArgumentException e) {
                String phrase = notMoving(yellow);
                System.out.println(phrase);
                menuYellow();
            }
        }
    }

    public void moveGreen() {
        Random rand = new Random();
        int numbersOfTerritories = 0;
        String units;
        ArrayList<Territory> temp = new ArrayList<>();
        for (int i = 0; i < territories.allTerritories.length; i++) {
            if (territories.allTerritories[i].isGreen && checkIfFriendlyBordersGreen(territories.allTerritories[i])) {
                temp.add(territories.allTerritories[i]);
            }
        }
        numbersOfTerritories = temp.size();
        String leader = "";
        if (numbersOfTerritories == 0) {
            String phrase = notMoving(green);
            System.out.println(phrase);
            menuGreen();
        }
        int randomTerritory = rand.nextInt((numbersOfTerritories));
        if (temp.size() > 0) {
            Territory moveFrom = temp.get(randomTerritory);
            try {
                Territory moveTo = moveToGreen(temp.get(randomTerritory));

                int movingUnits = rand.nextInt(moveFrom.units);
                if (movingUnits > 0 && movingUnits < moveFrom.units) {
                    moveFrom.units -= movingUnits;
                    moveTo.units += movingUnits;
                    if (moveFrom.hasLeader) {
                        leaderIsKilled(moveFrom);
                        leaderIsBorn(moveTo);
                        leader = leaderPhrase();
                    }
                    if (movingUnits > 1) {
                        units = oneOrMore(2);
                    } else {
                        units = oneOrMore(1);
                    }
                    presentation.setText("I move " + movingUnits + " " + units + " from " + moveFrom.name + " to "
                            + moveTo.name + ". " + leader);
                } else {
                    String phrase = notMoving(green);
                    presentation.setText(phrase);
                }

            } catch (NullPointerException | IllegalArgumentException e) {
                String phrase = notMoving(green);
                System.out.println(phrase);
                menuGreen();
            }
        }
    }

    public boolean checkIfFriendlyBordersRed(Territory attacker) {
        boolean possibleAttacks = false;
        ArrayList<Territory> borders = attacker.border;
        for (int i = 0; i < borders.size(); i++) {
            if (borders.get(i).isRed) {
                possibleAttacks = true;
            }
        }
        return possibleAttacks;
    }

    public boolean checkIfFriendlyBordersBlack(Territory attacker) {
        boolean possibleAttacks = false;
        ArrayList<Territory> borders = attacker.border;
        for (int i = 0; i < borders.size(); i++) {
            if (borders.get(i).isBlack) {
                possibleAttacks = true;
            }
        }
        return possibleAttacks;
    }

    public boolean checkIfFriendlyBordersYellow(Territory attacker) {
        boolean possibleAttacks = false;
        ArrayList<Territory> borders = attacker.border;
        for (int i = 0; i < borders.size(); i++) {
            if (borders.get(i).isYellow) {
                possibleAttacks = true;
            }
        }
        return possibleAttacks;
    }

    public boolean checkIfFriendlyBordersGreen(Territory attacker) {
        boolean possibleAttacks = false;
        ArrayList<Territory> borders = attacker.border;
        for (int i = 0; i < borders.size(); i++) {
            if (borders.get(i).isGreen) {
                possibleAttacks = true;
            }
        }
        return possibleAttacks;
    }

    public Territory moveToRed(Territory moveFrom) {
        ArrayList<Territory> borders = moveFrom.border;
        ArrayList<Territory> possibleMoves = new ArrayList<>();
        for (int i = 0; i < borders.size(); i++) {
            if (borders.get(i).isRed) {
                possibleMoves.add(borders.get(i));
            }
        }
        Random rand = new Random();
        if (!possibleMoves.isEmpty()) {
            int randomTerritory = rand.nextInt((possibleMoves.size()));
            if (randomTerritory < 0) {
                randomTerritory = 0;
            }
            defender = possibleMoves.get(randomTerritory);
            return defender;
        }
        throw new NullPointerException();
    }

    public Territory moveToBlack(Territory moveFrom) {
        ArrayList<Territory> borders = moveFrom.border;
        ArrayList<Territory> possibleMoves = new ArrayList<>();
        for (int i = 0; i < borders.size(); i++) {
            if (borders.get(i).isBlack) {
                possibleMoves.add(borders.get(i));
            }
        }
        Random rand = new Random();
        if (!possibleMoves.isEmpty()) {
            int randomTerritory = rand.nextInt((possibleMoves.size()));
            if (randomTerritory < 0) {
                randomTerritory = 0;
            }
            defender = possibleMoves.get(randomTerritory);
            return defender;
        }
        throw new NullPointerException();
    }

    public Territory moveToYellow(Territory moveFrom) {
        ArrayList<Territory> borders = moveFrom.border;
        ArrayList<Territory> possibleMoves = new ArrayList<>();
        for (int i = 0; i < borders.size(); i++) {
            if (borders.get(i).isYellow) {
                possibleMoves.add(borders.get(i));
            }
        }
        Random rand = new Random();
        if (!possibleMoves.isEmpty()) {
            int randomTerritory = rand.nextInt((possibleMoves.size()));
            if (randomTerritory < 0) {
                randomTerritory = 0;
            }
            defender = possibleMoves.get(randomTerritory);
            return defender;
        }
        throw new NullPointerException();
    }

    public Territory moveToGreen(Territory moveFrom) {
        ArrayList<Territory> borders = moveFrom.border;
        ArrayList<Territory> possibleMoves = new ArrayList<>();
        for (int i = 0; i < borders.size(); i++) {
            if (borders.get(i).isGreen) {
                possibleMoves.add(borders.get(i));
            }
        }
        Random rand = new Random();
        if (!possibleMoves.isEmpty()) {
            int randomTerritory = rand.nextInt((possibleMoves.size()));
            if (randomTerritory < 0) {
                randomTerritory = 0;
            }
            defender = possibleMoves.get(randomTerritory);
            return defender;
        }
        throw new NullPointerException();
    }

    public void moveRingRed() {
        Random rand = new Random();
        int numbersOfTerritories = 0;
        ArrayList<Territory> temp = new ArrayList<>();
        for (int i = 0; i < territories.allTerritories.length; i++) {
            if (territories.allTerritories[i].isRed && territories.allTerritories[i].hasRing) {
                temp.add(territories.allTerritories[i]);
            }
        }
        numbersOfTerritories = temp.size();
        if (numbersOfTerritories == 0) {
            presentation.setText("The ring is not mine to move.");
            menuRed();
        } else {
            int randomTerritory = rand.nextInt((numbersOfTerritories));
            if (temp.size() > 0) {
                Territory moveFrom = temp.get(randomTerritory);
                try {
                    Territory moveTo = moveRingTo(moveFrom);
                    if (moveFrom.isRed) {
                        ringIsBorn(moveTo);
                        ringIsKilled(moveFrom);
                        presentation.setText("I move the ring from " + moveFrom.name + " to " + moveTo.name);
                    } else {
                        presentation.setText("The ring is not mine to move.");
                    }

                } catch (NullPointerException e) {
                    String phrase = notMoving(red);
                    System.out.println(phrase);
                    menuRed();
                }
            }
        }
    }

    public void moveRingBlack() {
        Random rand = new Random();
        int numbersOfTerritories = 0;
        ArrayList<Territory> temp = new ArrayList<>();
        for (int i = 0; i < territories.allTerritories.length; i++) {
            if (territories.allTerritories[i].isBlack && territories.allTerritories[i].hasRing) {
                temp.add(territories.allTerritories[i]);
            }
        }
        numbersOfTerritories = temp.size();
        if (numbersOfTerritories == 0) {
            presentation.setText("The ring is not mine to move.");
            menuBlack();
        } else {
            int randomTerritory = rand.nextInt((numbersOfTerritories));
            if (temp.size() > 0) {
                Territory moveFrom = temp.get(randomTerritory);
                try {
                    Territory moveTo = moveRingTo(moveFrom);
                    if (moveFrom.isBlack) {
                        ringIsBorn(moveTo);
                        ringIsKilled(moveFrom);
                        presentation.setText("I move the ring from " + moveFrom.name + " to " + moveTo.name);
                    } else {
                        presentation.setText("The ring is not mine to move.");
                    }

                } catch (NullPointerException e) {
                    String phrase = notMoving(black);
                    System.out.println(phrase);
                    menuBlack();
                }
            }
        }
    }

    public void moveRingYellow() {
        Random rand = new Random();
        int numbersOfTerritories = 0;
        ArrayList<Territory> temp = new ArrayList<>();
        for (int i = 0; i < territories.allTerritories.length; i++) {
            if (territories.allTerritories[i].isYellow && territories.allTerritories[i].hasRing) {
                temp.add(territories.allTerritories[i]);
            }
        }
        numbersOfTerritories = temp.size();
        if (numbersOfTerritories == 0) {
            presentation.setText("The ring is not mine to move.");
            menuYellow();
        } else {
            int randomTerritory = rand.nextInt((numbersOfTerritories));
            if (temp.size() > 0) {
                Territory moveFrom = temp.get(randomTerritory);
                try {
                    Territory moveTo = moveRingTo(moveFrom);
                    if (moveFrom.isYellow) {
                        ringIsBorn(moveTo);
                        ringIsKilled(moveFrom);
                        presentation.setText("I move the ring from " + moveFrom.name + " to " + moveTo.name);
                    } else {
                        presentation.setText("The ring is not mine to move.");
                    }

                } catch (NullPointerException e) {
                    String phrase = notMoving(yellow);
                    System.out.println(phrase);
                    menuYellow();
                }
            }
        }
    }

    public void moveRingGreen() {
        Random rand = new Random();
        int numbersOfTerritories = 0;
        ArrayList<Territory> temp = new ArrayList<>();
        for (int i = 0; i < territories.allTerritories.length; i++) {
            if (territories.allTerritories[i].isGreen && territories.allTerritories[i].hasRing) {
                temp.add(territories.allTerritories[i]);
            }
        }
        numbersOfTerritories = temp.size();
        if (numbersOfTerritories == 0) {
            presentation.setText("The ring is not mine to move.");
            menuGreen();
        } else {
            int randomTerritory = rand.nextInt((numbersOfTerritories));
            if (temp.size() > 0) {
                Territory moveFrom = temp.get(randomTerritory);
                try {
                    Territory moveTo = moveRingTo(moveFrom);
                    if (moveFrom.isGreen) {
                        ringIsBorn(moveTo);
                        ringIsKilled(moveFrom);
                        presentation.setText("I move the ring from " + moveFrom.name + " to " + moveTo.name);
                    } else {
                        presentation.setText("The ring is not mine to move.");
                    }

                } catch (NullPointerException e) {
                    String phrase = notMoving(green);
                    System.out.println(phrase);
                    menuGreen();
                }
            }
        }
    }

    public Territory moveRingTo(Territory moveFrom) {
        ArrayList<Territory> borders = moveFrom.border;
        ArrayList<Territory> possibleMoves = new ArrayList<>();
        for (int i = 0; i < borders.size(); i++) {
            possibleMoves.add(borders.get(i));
        }
        Random rand = new Random();
        if (!possibleMoves.isEmpty()) {
            int randomTerritory = rand.nextInt((possibleMoves.size()));
            if (randomTerritory < 0) {
                randomTerritory = 0;
            }
            defender = possibleMoves.get(randomTerritory);
            return defender;
        }

        throw new NullPointerException();
    }

    public void ringIsKilled(Territory attacker) {
        attacker.hasRing = false;

    }

    public void ringIsBorn(Territory attacker) {
        attacker.hasRing = true;
    }

    public void ringChangeTerritory(Territory attacker, Territory defender) {
        attacker.hasRing = false;
        defender.hasRing = true;
    }

    public void showTerritoriesRed() {
        textArea.setText("");
        terrritorieLabel.setText("My territories");
        for (int i = 0; i < territories.allTerritories.length; i++) {
            if (territories.allTerritories[i].isRed) {
                textArea.append(territories.allTerritories[i].name + " " + territories.allTerritories[i].units + "\n");
            }
        }
        for (int i = 0; i < territories.allTerritories.length; i++) {
            if (territories.allTerritories[i].hasLeader && territories.allTerritories[i].isRed) {
                textArea.append(territories.allTerritories[i].name + " has one leader" + "\n");
            }
        }
        for (int i = 0; i < territories.allTerritories.length; i++) {
            if (territories.allTerritories[i].hasRing) {
                textArea.append(territories.allTerritories[i].name + " has the ring" + "\n");
            }
        }
    }

    public void showTerritoriesBlack() {
        textArea.setText("");
        terrritorieLabel.setText("My territories");
        for (int i = 0; i < territories.allTerritories.length; i++) {
            if (territories.allTerritories[i].isBlack) {
                textArea.append(territories.allTerritories[i].name + " " + territories.allTerritories[i].units + "\n");
            }
        }
        for (int i = 0; i < territories.allTerritories.length; i++) {
            if (territories.allTerritories[i].hasLeader && territories.allTerritories[i].isBlack) {
                textArea.append(territories.allTerritories[i].name + " has one leader" + "\n");
            }
        }
        for (int i = 0; i < territories.allTerritories.length; i++) {
            if (territories.allTerritories[i].hasRing) {
                textArea.append(territories.allTerritories[i].name + " has the ring" + "\n");
            }
        }
    }

    public void showTerritoriesYellow() {
        textArea.setText("");
        terrritorieLabel.setText("My territories");
        for (int i = 0; i < territories.allTerritories.length; i++) {
            if (territories.allTerritories[i].isYellow) {
                textArea.append(territories.allTerritories[i].name + " " + territories.allTerritories[i].units + "\n");
            }
        }
        for (int i = 0; i < territories.allTerritories.length; i++) {
            if (territories.allTerritories[i].hasLeader && territories.allTerritories[i].isYellow) {
                textArea.append(territories.allTerritories[i].name + " has one leader" + "\n");
            }
        }
        for (int i = 0; i < territories.allTerritories.length; i++) {
            if (territories.allTerritories[i].hasRing) {
                textArea.append(territories.allTerritories[i].name + " has the ring" + "\n");
            }
        }
    }

    public void showTerritoriesGreen() {
        textArea.setText("");
        terrritorieLabel.setText("My territories");
        for (int i = 0; i < territories.allTerritories.length; i++) {
            if (territories.allTerritories[i].isGreen) {
                textArea.append(territories.allTerritories[i].name + " " + territories.allTerritories[i].units + "\n");
            }
        }
        for (int i = 0; i < territories.allTerritories.length; i++) {
            if (territories.allTerritories[i].hasLeader && territories.allTerritories[i].isGreen) {
                textArea.append(territories.allTerritories[i].name + " has one leader" + "\n");
            }
        }
        for (int i = 0; i < territories.allTerritories.length; i++) {
            if (territories.allTerritories[i].hasRing) {
                textArea.append(territories.allTerritories[i].name + " has the ring" + "\n");
            }
        }
    }

    public void choosePlayerRed() {
        String chosenPlayer = "";
        Random rand = new Random();
        int player = rand.nextInt((3)) + 1;
        switch (player) {
            case 1:
                chosenPlayer = "Yellow";
                break;
            case 2:
                chosenPlayer = "Green";
                break;
            case 3:
                chosenPlayer = "Black";
                break;
            default:
                chosenPlayer = "Something went wrong";
        }
        presentation.setText("I choose " + chosenPlayer);
    }

    public void choosePlayerBlack() {
        String chosenPlayer = "";
        Random rand = new Random();
        int player = rand.nextInt((3)) + 1;
        switch (player) {
            case 1:
                chosenPlayer = "Yellow";
                break;
            case 2:
                chosenPlayer = "Green";
                break;
            case 3:
                chosenPlayer = "Red";
                break;
            default:
                chosenPlayer = "Something went wrong";
        }
        presentation.setText("I choose " + chosenPlayer);
    }

    public void choosePlayerYellow() {
        String chosenPlayer = "";
        Random rand = new Random();
        int player = rand.nextInt((3)) + 1;
        switch (player) {
            case 1:
                chosenPlayer = "Red";
                break;
            case 2:
                chosenPlayer = "Green";
                break;
            case 3:
                chosenPlayer = "Black";
                break;
            default:
                chosenPlayer = "Something went wrong";
        }
        presentation.setText("I choose " + chosenPlayer);
    }

    public void choosePlayerGreen() {
        String chosenPlayer = "";
        Random rand = new Random();
        int player = rand.nextInt((3)) + 1;
        switch (player) {
            case 1:
                chosenPlayer = "Yellow";
                break;
            case 2:
                chosenPlayer = "Red";
                break;
            case 3:
                chosenPlayer = "Black";
                break;
            default:
                chosenPlayer = "Something went wrong";
        }
        presentation.setText("I choose " + chosenPlayer);
    }

    public Player red(Player red) {
        Random rand = new Random();
        int leader = rand.nextInt((4)) + 1;
        switch (leader) {
            case 1:
                red.name = "Saruman";
                break;
            case 2:
                red.name = "Gollum";
                break;
            case 3:
                red.name = "Grima Wormtounge";
                break;
            case 4:
                red.name = "Smaug";
                break;
            default:
                red.name = "An Uruk-Hai";
        }
        String message = evilHelloPhrase();
        presentation.setText("I am " + red.name + message);
        explorer.setText("Red");
        return red;
    }

    public Player black(Player black) {
        Random rand = new Random();
        int leader = rand.nextInt((4)) + 1;
        switch (leader) {
            case 1:
                black.name = "Sauron";
                break;
            case 2:
                black.name = "The Withch King";
                break;
            case 3:
                black.name = "Gothmog";
                break;
            case 4:
                black.name = "Durins Bane";
                break;
            default:
                black.name = "An orc";
        }
        String message = evilHelloPhrase();
        presentation.setText("I am " + black.name + message);
        explorer.setText("Black");
        return black;
    }

    public Player yellow(Player yellow) {
        Random rand = new Random();
        int leader = rand.nextInt((4)) + 1;
        switch (leader) {
            case 1:
                yellow.name = "Elrond";
                break;
            case 2:
                yellow.name = "Theoden";
                break;
            case 3:
                yellow.name = "Frodo Baggins";
                break;
            case 4:
                yellow.name = "Gandalf";
                break;
            default:
                yellow.name = "An elf";
        }
        String message = goodHelloPhrase();
        presentation.setText("I am " + yellow.name + message);
        explorer.setText("Yellow");
        return yellow;
    }

    public Player green(Player green) {
        Random rand = new Random();
        int leader = rand.nextInt((4)) + 1;
        switch (leader) {
            case 1:
                green.name = "Aragon";
                break;
            case 2:
                green.name = "Thorin Oakenshield";
                break;
            case 3:
                green.name = "Legolas";
                break;
            case 4:
                green.name = "Samwise Gamgi";
                break;
            default:
                green.name = "A Hobbit";
        }
        String message = goodHelloPhrase();
        presentation.setText("I am " + green.name + message);
        explorer.setText("Green");
        return green;
    }

    public String evilHelloPhrase() {
        Random rand = new Random();
        int random = rand.nextInt((16)) + 1;
        String phrase = "";
        switch (random) {
            case 1:
                phrase = ". I will crush you.";
                break;
            case 2:
                phrase = ". Prepare to die.";
                break;
            case 3:
                phrase = ". I'm gonna bleed you.";
                break;
            case 4:
                phrase = ". The time of the orc has come!";
                break;
            case 5:
                phrase = ". Do you not know death when you see it?";
                break;
            case 6:
                phrase = " and all shall die.";
                break;
            case 7:
                phrase = ". I will kill everyone.";
                break;
            case 8:
                phrase = " and I find your prescence quite disturbing.";
                break;
            case 9:
                phrase = ", fear me!";
                break;
            case 10:
                phrase = ", fear my power!";
                break;
            case 11:
                phrase = ". A new power is rising.";
                break;
            case 12:
                phrase = ". Shadow and flame.";
                break;
            case 13:
                phrase = ". Fear my mace!";
                break;
            case 14:
                phrase = ". Victory is mine.";
                break;
            case 15:
                phrase = ". For die you must.";
                break;
            case 16:
                phrase = ". The ring shall be mine.";
                break;
            default:
                phrase = ". Something went wrong.";
        }
        return phrase;
    }

    public String unitsQuestion() {
        String question = "";
        Random rand = new Random();
        int randomNum = rand.nextInt((40)) + 1;
        if (randomNum > 30) {
            randomNum = 1;
        }
        switch (randomNum) {
            case 1:
                question = "How many units are there now in ";
                break;
            case 2:
                question = "Please tell me how many units there are in ";
                break;
            case 3:
                question = "Coould you tell me how many units there are in ";
                break;
            case 4:
                question = "Say brother, how many units are there are in ";
                break;
            case 5:
                question = "My friend, how many units are there are in ";
                break;
            case 6:
                question = "I wonder how many units there are in ";
                break;
            case 7:
                question = "Did anyone make it? Could you write how many units that survived ";
                break;
            case 8:
                question = "I cannot see. How many units survived the battle of ";
                break;
            case 9:
                question = "I wonder how many units survived ";
                break;
            case 10:
                question = "How many made it through ";
                break;
            case 11:
                question = "Hey, how many units are there in ";
                break;
            case 12:
                question = "Are there any units left in ";
                break;
            case 13:
                question = "Could you tell me how many units survived ";
                break;
            case 14:
                question = "A red moon has risen. How many units are there in ";
                break;
            case 15:
                question = "Are there any men left in ";
                break;
            case 16:
                question = "Could you write the number of my surviving units in ";
                break;
            case 17:
                question = "Can anyone tell me, how many units there are in ";
                break;
            case 18:
                question = "My units fought well. But how many units are left in ";
                break;
            case 19:
                question = "Wizard! How many of my units there are in ";
                break;
            case 20:
                question = "My eyes are blind. How many units there are in ";
                break;
            case 21:
                question = "Blood have been shed. How many of my units survived ";
                break;
            case 22:
                question = "How many of my units survived ";
                break;
            case 23:
                question = "Perhaps I won, perhaps not. How did I do? How many of my units survived ";
                break;
            case 24:
                question = "I am smart but I cannot see. How many of my units survived the battle of ";
                break;
            case 25:
                question = "I do not have any eyes because of my creator. How many units survived ";
                break;
            case 26:
                question = "I am old and cannot see. How many of my units survived ";
                break;
            case 27:
                question = "Did any of my units survive the battle of ";
                break;
            case 28:
                question = "I need your help. How many of my units survived the battle of ";
                break;
            case 29:
                question = "Tell me my friend, did any of my units survive the battle of ";
                break;
            case 30:
                question = "Servant, tell me do I have any units on ";
                break;
            default:
                question = "Something went wrong. How many of my units are left on ";
                break;
        }
        return question;
    }

    @SuppressWarnings("resource")
    public String didIWinQuestion() {
        Random rand = new Random();
        int whatQuestion = rand.nextInt((21)) + 1;
        if (whatQuestion > 13 && whatQuestion <= 16) {
            whatQuestion = 1;
        } else if (whatQuestion > 16) {
            whatQuestion = 2;
        }
        String question = "";
        switch (whatQuestion) {
            case 1:
                question = "Did I win or lose?";
                break;
            case 2:
                question = "Did I win or did I lose?";
                break;
            case 3:
                question = "Tell me, did I win or lose?";
                break;
            case 4:
                question = "Please tell me, did I win or lose?";
                break;
            case 5:
                question = "Hey! Did I win or did I lose?";
                break;
            case 6:
                question = "Brother tell me. Did I win or did I lose?";
                break;
            case 7:
                question = "Perhaps I won. Perhaps I lost.";
                break;
            case 8:
                question = "I wonder if I won or lost.";
                break;
            case 9:
                question = "I dont care if I won or lost. Tell me anyway!";
                break;
            case 10:
                question = "Did I win or lose? Please tell!";
                break;
            case 11:
                question = "Did I win or lose. It would be awful if I lost.";
                break;
            case 12:
                question = "I do not have much to live for. Did I win or lose?";
                break;
            case 13:
                question = "Did I win or lose? It doesn't matter, I will destroy you all.";
                break;
            default:
                question = "Did I win or lose?";
        }
        return question;
    }

    @SuppressWarnings("resource")
    public String didPlayerWinQuestion() {
        Random rand = new Random();
        int whatQuestion = rand.nextInt((21)) + 1;
        if (whatQuestion > 13 && whatQuestion <= 16) {
            whatQuestion = 1;
        } else if (whatQuestion > 16) {
            whatQuestion = 2;
        }
        String question = "";
        switch (whatQuestion) {
            case 1:
                question = "Did you win [W] or lose [L]?";
                break;
            case 2:
                question = "Did you win [W] or did you lose [L]?";
                break;
            case 3:
                question = "Tell me, did you win [W] or lose [L]?";
                break;
            case 4:
                question = "Please tell me, did you win [W] or lose [L]?";
                break;
            case 5:
                question = "Hey! Did you win [W] or did you lose [L]?";
                break;
            case 6:
                question = "Brother tell me. Did you win [W] or did you lose [L]?";
                break;
            case 7:
                question = "Perhaps you won [W]. Perhaps you lost [L].";
                break;
            case 8:
                question = "I wonder if you won [W] or lost [L].";
                break;
            case 9:
                question = "I dont care if you won [W] or lost [L]. Tell me anyway!";
                break;
            case 10:
                question = "Did you win [W] or lose [L]? Please tell!";
                break;
            case 11:
                question = "Did you win [W] or lose [L]. It would be good if you lost.";
                break;
            case 12:
                question = "I do not have much to live for. Did you win [W] or lose [L]?";
                break;
            case 13:
                question = "Did you win [W] or lose [L]? It doesn't matter, you will destroy you all.";
                break;
            default:
                question = "Did you win [W] or lose [L]?";
        }
        events.setText(question);
        String decision = "W";
        return decision;
    }

    public String reaction(boolean won) {
        Random rand = new Random();
        int whatReaction = rand.nextInt((73)) + 1;
        String reaction = "";
        if (won == false) {
            switch (whatReaction) {
                case 1:
                    reaction = "I was a fool.";
                    break;
                case 2:
                    reaction = "Sorry for my behaviour.";
                    break;
                case 3:
                    reaction = "I feel defeated.";
                    break;
                case 4:
                    reaction = "Is this what defeat feels like?";
                    break;
                case 5:
                    reaction = "You have no honour!";
                    break;
                case 6:
                    reaction = "It's the job that's never started as takes longest to finish.";
                    break;
                case 7:
                    reaction = "Roads go ever on.";
                    break;
                case 8:
                    reaction = "I didn't think it would end this way.";
                    break;
                case 9:
                    reaction = "Even the smallest person can change the course of the future.";
                    break;
                case 10:
                    reaction = "The time of the Elves… is over.";
                    break;
                case 11:
                    reaction = "Here is the end of all things.";
                    break;
                case 12:
                    reaction = "What, did you win?";
                    break;
                case 13:
                    reaction = "That was unexpected.";
                    break;
                case 14:
                    reaction = "That was indeed, unexpected.";
                    break;
                case 15:
                    reaction = "What?";
                    break;
                case 16:
                    reaction = "You are nothing but a filthy thief.";
                    break;
                case 17:
                    reaction = "Do you not remember me, brother?";
                    break;
                case 18:
                    reaction = "I trusted you!";
                    break;
                case 19:
                    reaction = "Hey, thats cheating.";
                    break;
                case 20:
                    reaction = "My wrath shall haunt you!";
                    break;
                case 21:
                    reaction = "Your time has truly come.";
                    break;
                case 22:
                    reaction = "You won't defeat me!.";
                    break;
                case 23:
                    reaction = "You're nothing but small pieces of lembas.";
                    break;
                case 24:
                    reaction = "I did that on purpose.";
                    break;
                case 25:
                    reaction = "hey, screw you!";
                    break;
                case 26:
                    reaction = "My time will come.";
                    break;
                case 27:
                    reaction = "You think that would be enough to defeat me?";
                    break;
                case 28:
                    reaction = "Remember me.";
                    break;
                case 29:
                    reaction = "Are you sure?";
                    break;
                case 30:
                    reaction = "You maggot!";
                    break;
                case 31:
                    reaction = "Melon.";
                    break;
                case 32:
                    reaction = "My men have been drinking.";
                    break;
                case 33:
                    reaction = "I only tested your defence.";
                    break;
                case 34:
                    reaction = "Don't say anything.";
                    break;
                case 35:
                    reaction = "You are a coward.";
                    break;
                case 36:
                    reaction = "I will come again.";
                    break;
                case 37:
                    reaction = "What do you use?.";
                    break;
                case 38:
                    reaction = "You're not my bro, pal.";
                    break;
                case 39:
                    reaction = "What a sad day.";
                    break;
                case 40:
                    reaction = "I may look tough, but on the inside I cry.";
                    break;
                case 41:
                    reaction = "You will never defeat me, get it?";
                    break;
                case 42:
                    reaction = "This time you won. There will however be more battles.";
                    break;
                case 43:
                    reaction = "There is a time for everything.";
                    break;
                case 44:
                    reaction = "I will be back.";
                    break;
                case 45:
                    reaction = "That did not go as planned. I will be back.";
                    break;
                case 46:
                    reaction = "My soldiers were exhausted after yesterdays training.";
                    break;
                case 47:
                    reaction = "My soldiers were exhausted after yesterdays wrestling.";
                    break;
                case 48:
                    reaction = "My soldiers were exhausted after yesterdays golf.";
                    break;
                case 49:
                    reaction = "My soldiers were exhausted after yesterdays bow competition.";
                    break;
                case 50:
                    reaction = "It's not fair.";
                    break;
                case 51:
                    reaction = "I will grow stronger for each day.";
                    break;
                case 52:
                    reaction = "Big mistake.";
                    break;
                case 53:
                    reaction = "Small mistake.";
                    break;
                case 54:
                    reaction = "Your defence is good.";
                    break;
                case 55:
                    reaction = "I cannot say that I'm sorry.";
                    break;
                case 56:
                    reaction = "What? unacceptable.";
                    break;
                case 57:
                    reaction = "Unacceptable! Unacceptable!";
                    break;
                case 58:
                    reaction = "Later on I will break your bones.";
                    break;
                case 59:
                    reaction = "Did you do that?";
                    break;
                case 60:
                    reaction = "Did you do that, to me?";
                    break;
                case 61:
                    reaction = "Why are you doing this to me?";
                    break;
                case 62:
                    reaction = "I have feelings too!";
                    break;
                case 63:
                    reaction = "Not that territory.";
                    break;
                case 64:
                    reaction = "I was busy taking over middle eart, I didn't see your attack.";
                    break;
                case 65:
                    reaction = "You will be memory.";
                    break;
                case 66:
                    reaction = "We go into the west.";
                    break;
                case 67:
                    reaction = "Calm down a bit.";
                    break;
                case 68:
                    reaction = "I might be a bot, but I still have feelings.";
                    break;
                case 69:
                    reaction = "Do you really wanna enrage me?";
                    break;
                case 70:
                    reaction = "You're not my pal, son.!";
                    break;
                case 71:
                    reaction = "Do you really wanna be my enemy?";
                    break;
                case 72:
                    reaction = "You haven't seen the worst yet.";
                    break;
                case 73:
                    reaction = "I will have my revenge.";
                    break;
                default:
                    reaction = "Something went wrong!";
                    break;
            }
        } else {
            switch (whatReaction) {
                case 1:
                    reaction = "You were a fool.";
                    break;
                case 2:
                    reaction = "Sorry for my behaviour.";
                    break;
                case 3:
                    reaction = "I feel delighted.";
                    break;
                case 4:
                    reaction = "Is this what victory feels like?";
                    break;
                case 5:
                    reaction = "You had no honour, now you are dead!";
                    break;
                case 6:
                    reaction = "I will rule middle earth.";
                    break;
                case 7:
                    reaction = "Roads go ever on.";
                    break;
                case 8:
                    reaction = "You didn't think it would end this way.";
                    break;
                case 9:
                    reaction = "No one else can beast me!";
                    break;
                case 10:
                    reaction = "My time has come!";
                    break;
                case 11:
                    reaction = "Here is the end of all things.";
                    break;
                case 12:
                    reaction = "What, did I win?";
                    break;
                case 13:
                    reaction = "That was unexpected, or was it?.";
                    break;
                case 14:
                    reaction = "All planned.";
                    break;
                case 15:
                    reaction = "Haha!";
                    break;
                case 16:
                    reaction = "You are nothing but a filthy bug.";
                    break;
                case 17:
                    reaction = "Remember me!";
                    break;
                case 18:
                    reaction = "I never trusted you!";
                    break;
                case 19:
                    reaction = "Hey, look who won!";
                    break;
                case 20:
                    reaction = "Bye bye.";
                    break;
                case 21:
                    reaction = "Your time has truly come.";
                    break;
                case 22:
                    reaction = "You will never defeat me!.";
                    break;
                case 23:
                    reaction = "You're nothing but small pieces of lembas.";
                    break;
                case 24:
                    reaction = "I did that on purpose.";
                    break;
                case 25:
                    reaction = "I laughed as I killed your men.";
                    break;
                case 26:
                    reaction = "My time is now.";
                    break;
                case 27:
                    reaction = "You think you could defeat me?";
                    break;
                case 28:
                    reaction = "Remember me.";
                    break;
                case 29:
                    reaction = "How cute!";
                    break;
                case 30:
                    reaction = "Haha, lol!";
                    break;
                case 31:
                    reaction = "Melon.";
                    break;
                case 32:
                    reaction = "Tell me, was tht all you had?";
                    break;
                case 33:
                    reaction = "This will soon be over.";
                    break;
                case 34:
                    reaction = "Do you dare to continue?";
                    break;
                case 35:
                    reaction = "I am the greatest.";
                    break;
                case 36:
                    reaction = "This battle was quick. Do you hide something?";
                    break;
                case 37:
                    reaction = "I knew a man with the same skill as you. He is dead...";
                    break;
                case 38:
                    reaction = "Are you defeated yet?";
                    break;
                case 39:
                    reaction = "Your body will rotten on the ground when I'm done with you.";
                    break;
                case 40:
                    reaction = "I had a powerful wizard in my army.";
                    break;
                case 41:
                    reaction = "I win, you loose.";
                    break;
                case 42:
                    reaction = "This time I won. There will however be more battles.";
                    break;
                case 43:
                    reaction = "There is a time for everything. Today I won.";
                    break;
                case 44:
                    reaction = "I have more.";
                    break;
                case 45:
                    reaction = "That did go as planned. But I will not quit yet.";
                    break;
                case 46:
                    reaction = "My soldiers are well trained with bows.";
                    break;
                case 47:
                    reaction = "My soldiers were are well trained with swords.";
                    break;
                case 48:
                    reaction = "My soldiers were are well trained with cavalry.";
                    break;
                case 49:
                    reaction = "My soldiers were are well trained.";
                    break;
                case 50:
                    reaction = "It's not fair you say? Stick something up your pie-hole.";
                    break;
                case 51:
                    reaction = "I will grow stronger for each day.";
                    break;
                case 52:
                    reaction = "You did a big mistake.";
                    break;
                case 53:
                    reaction = "You did a small mistake.";
                    break;
                case 54:
                    reaction = "Your defence is good, but not good enough.";
                    break;
                case 55:
                    reaction = "I cannot say that I'm sorry.";
                    break;
                case 56:
                    reaction = "Thaat was fun, wasn't it?";
                    break;
                case 57:
                    reaction = "Jolly times.";
                    break;
                case 58:
                    reaction = "This was nothing compared to what will come later.";
                    break;
                case 59:
                    reaction = "Did I do that?";
                    break;
                case 60:
                    reaction = "Did I do that? Cool!";
                    break;
                case 61:
                    reaction = "Why I'm doing this to you? Because I hate you.";
                    break;
                case 62:
                    reaction = "I have feelings. I just don't show them.";
                    break;
                case 63:
                    reaction = "I like that territory.";
                    break;
                case 64:
                    reaction = "I was busy taking over middle eart, I didn't see your resistance.";
                    break;
                case 65:
                    reaction = "You will be memory.";
                    break;
                case 66:
                    reaction = "You go into the west.";
                    break;
                case 67:
                    reaction = "Don' get so upset.";
                    break;
                case 68:
                    reaction = "I might be a bot, but I still have a sense for domination.";
                    break;
                case 69:
                    reaction = "Do you really think you can stand me?";
                    break;
                case 70:
                    reaction = "Look! I won! Are you even trying?";
                    break;
                case 71:
                    reaction = "Are you even trying?";
                    break;
                case 72:
                    reaction = "Daily goal: Check.";
                    break;
                case 73:
                    reaction = "That was fun, let's do it again!";
                    break;
                default:
                    reaction = "Something went wrong!";
            }

        }
        return reaction;
    }

    public String goodHelloPhrase() {
        Random rand = new Random();
        int random = rand.nextInt((16)) + 1;
        String phrase = "";
        switch (random) {
            case 1:
                phrase = ". Let's hunt some orc.";
                break;
            case 2:
                phrase = ". The beacons are lit.";
                break;
            case 3:
                phrase = ". Long live the middle earth.";
                break;
            case 4:
                phrase = ". You may go no further.";
                break;
            case 5:
                phrase = ". I do not fear death.";
                break;
            case 6:
                phrase = ". From the ashes a fire shall be woken.";
                break;
            case 7:
                phrase = ". War is the province of men.";
                break;
            case 8:
                phrase = ", I fear neither death nor pain.";
                break;
            case 9:
                phrase = ". I will take the ring with me.";
                break;
            case 10:
                phrase = ". One ring to rule them all.";
                break;
            case 11:
                phrase = ". I will free Middle Earth";
                break;
            case 12:
                phrase = ". Death is just another path.";
                break;
            case 13:
                phrase = ". I will send you into the abyss!";
                break;
            case 14:
                phrase = ". I was once like you.";
                break;
            case 15:
                phrase = ". I am the rightful heir to throne.";
                break;
            case 16:
                phrase = ". There is something good left in this world.";
                break;
            default:
                phrase = ". Something went wrong.";
        }
        return phrase;
    }

    public String introduction(int units) {
        String startPhrase = "";
        Random rand = new Random();
        int randomNum = rand.nextInt((30)) + 1;
        if (units < 10) {
            switch (randomNum) {
                case 1:
                    startPhrase = "I will attack ";
                    break;
                case 2:
                    startPhrase = "I shall march towards ";
                    break;
                case 3:
                    startPhrase = "Today I will attack ";
                    break;
                case 4:
                    startPhrase = "It might not do much, but I will attack ";
                    break;
                case 5:
                    startPhrase = "I have decided to attack ";
                    break;
                case 6:
                    startPhrase = "This glorious army attacks  ";
                    break;
                case 7:
                    startPhrase = "For the sake of my kind I will attack ";
                    break;
                case 8:
                    startPhrase = "I consider attacking ";
                    break;
                case 9:
                    startPhrase = "My men will attack ";
                    break;
                case 10:
                    startPhrase = "Sorry about this. I attack ";
                    break;
                case 11:
                    startPhrase = "I will try to attack ";
                    break;
                case 12:
                    startPhrase = "I march towards ";
                    break;
                case 13:
                    startPhrase = "Today I feel like attacking ";
                    break;
                case 14:
                    startPhrase = "It might be stupid, but I will attack ";
                    break;
                case 15:
                    startPhrase = "I have decided to try the defence of ";
                    break;
                case 16:
                    startPhrase = "This day I attack ";
                    break;
                case 17:
                    startPhrase = "I just decided to attack ";
                    break;
                case 18:
                    startPhrase = "It took a while before I concluded to attack ";
                    break;
                case 19:
                    startPhrase = "It is all so clear now. I will attack ";
                    break;
                case 20:
                    startPhrase = "I hate you, I attack ";
                    break;
                case 21:
                    startPhrase = "When I awoke this moring I decided that: today I will attack ";
                    break;
                case 22:
                    startPhrase = "I had a dream about attacking ";
                    break;
                case 23:
                    startPhrase = "You are nothing but a liar. I attack ";
                    break;
                case 24:
                    startPhrase = "I hate you. Watch out ";
                    break;
                case 25:
                    startPhrase = "You better prepare. I march towards ";
                    break;
                case 26:
                    startPhrase = "This perticular day I attack ";
                    break;
                case 27:
                    startPhrase = "You are doomed. I march towards ";
                    break;
                case 28:
                    startPhrase = "I go full force on ";
                    break;
                case 29:
                    startPhrase = "I force my soldiers to attack ";
                    break;
                case 30:
                    startPhrase = "I will regret my decision. However I attack ";
                    break;
                default:
                    startPhrase = "Something went wrong.";
            }

        }
        if (units >= 10) {
            switch (randomNum) {
                case 1:
                    startPhrase = "I will attack ";
                    break;
                case 2:
                    startPhrase = "This will be fun. I will attack ";
                    break;
                case 3:
                    startPhrase = "Look at my army. I will attack ";
                    break;
                case 4:
                    startPhrase = "Behold my powerful army. I will attack ";
                    break;
                case 5:
                    startPhrase = "Glorious! Kneel before me! I march towards ";
                    break;
                case 6:
                    startPhrase = "Warning: My army is currently marching to ";
                    break;
                case 7:
                    startPhrase = "This is a dark day for you. I will attack ";
                    break;
                case 8:
                    startPhrase = "I feel ashamed that i need to attack ";
                    break;
                case 9:
                    startPhrase = "My men will attack ";
                    break;
                case 10:
                    startPhrase = "Sorry about this. I attack ";
                    break;
                case 11:
                    startPhrase = "I will attack ";
                    break;
                case 12:
                    startPhrase = "I will crush ";
                    break;
                case 13:
                    startPhrase = "Look at my superiour army! I will squeeze you! I attack ";
                    break;
                case 14:
                    startPhrase = "Behold one of the biggest army in our lifetime. It marches towards ";
                    break;
                case 15:
                    startPhrase = "Kneel before your king! I attack ";
                    break;
                case 16:
                    startPhrase = "This is the end. Prepare to die! I march on ";
                    break;
                case 17:
                    startPhrase = "Haha, looser! I will destroy ";
                    break;
                case 18:
                    startPhrase = "My army will squeeze ";
                    break;
                case 19:
                    startPhrase = "My giant army will attack ";
                    break;
                case 20:
                    startPhrase = "You are screwed. I attack ";
                    break;
                case 21:
                    startPhrase = "When I awoke this morning I decided that: today I will attack ";
                    break;
                case 22:
                    startPhrase = "I had a dream about attacking ";
                    break;
                case 23:
                    startPhrase = "You a nothing but a liar. I go full force on ";
                    break;
                case 24:
                    startPhrase = "I hate you more than anyone else. I attack ";
                    break;
                case 25:
                    startPhrase = "You better prepare. My giant army attacks ";
                    break;
                case 26:
                    startPhrase = "this perticular day I send my armies to ";
                    break;
                case 27:
                    startPhrase = "You are doomed. The worlds biggest army march towards ";
                    break;
                case 28:
                    startPhrase = "I go full force on you. I attack ";
                    break;
                case 29:
                    startPhrase = "I force all my soldiers to attack ";
                    break;
                case 30:
                    startPhrase = "I won't regret my decision. I attack ";
                    break;
                default:
                    startPhrase = "Something went wrong.";
            }
        }
        return startPhrase;
    }

    public String ending(Player player) {
        String name = player.name;
        String endPhrase = "";
        Random rand = new Random();
        int randomNum = rand.nextInt((36)) + 1;
        switch (randomNum) {
            case 1:
                endPhrase = "No surrender!";
                break;
            case 2:
                endPhrase = "No one will resign.";
                break;
            case 3:
                endPhrase = "I will totaly screw you up.";
                break;
            case 4:
                endPhrase = "Get ready to be overwhelmed.";
                break;
            case 5:
                endPhrase = "You will be nothing but a memory.";
                break;
            case 6:
                endPhrase = "I will spit on your grave.";
                break;
            case 7:
                endPhrase = "No one will remember your name after this battle.";
                break;
            case 8:
                endPhrase = "Have mercy on my soul.";
                break;
            case 9:
                endPhrase = "My men will fight to the end.";
                break;
            case 10:
                endPhrase = "I do it for the sake of my kind.";
                break;
            case 11:
                endPhrase = "I am sorry for my behaviour.";
                break;
            case 12:
                endPhrase = "After all you are the weakest opponent.";
                break;
            case 13:
                endPhrase = "You are a weak king.";
                break;
            case 14:
                endPhrase = "I will rule all of middle earth";
                break;
            case 15:
                endPhrase = "I gave them weapons of pure mithril.";
                break;
            case 16:
                endPhrase = "The Ring, i want the Ring.";
                break;
            case 17:
                endPhrase = "Middle earth shall lie before my feet.";
                break;
            case 18:
                endPhrase = "I wonder how long you will stand.";
                break;
            case 19:
                endPhrase = "I will rebuilt what my lord started.";
                break;
            case 20:
                endPhrase = "This is the biggest war of middle earth.";
                break;
            case 21:
                endPhrase = "My kins will always hunt you.";
                break;
            case 22:
                endPhrase = "No man or beast can stop me.";
                break;
            case 23:
                endPhrase = "I wonder how long you can stand my army.";
                break;
            case 24:
                endPhrase = "I have the finest bows in all of middle earth.";
                break;
            case 25:
                endPhrase = "Do you even think you can beat me this time?";
                break;
            case 26:
                endPhrase = "What you did earlier was foolish. Now learn from your mistakes.";
                break;
            case 27:
                endPhrase = "Your decisions are... Strange!";
                break;
            case 28:
                endPhrase = "No mortal can stop me!";
                break;
            case 29:
                endPhrase = "One ring to rule them all.";
                break;
            case 30:
                endPhrase = "I am " + name + "!";
                break;
            case 31:
                endPhrase = "As sure as my name is " + name + ".";
                break;
            case 32:
                endPhrase = name + " will conquer middle earth.";
                break;
            case 33:
                endPhrase = "My name is " + name + ".";
                break;
            case 34:
                endPhrase = "No mortal can stop me, I am " + name + "!";
                break;
            case 35:
                endPhrase = "My name, " + name + ". Remember it!";
                break;
            case 36:
                endPhrase = "My name is " + name + ". Remember it for as long as you live.";
                break;
            default:
                endPhrase = ". Something went wrong";
                break;
        }
        return endPhrase;
    }

    public String preposition2() {
        String preposition = "";
        Random rand = new Random();
        int randomNum = rand.nextInt((30)) + 1;
        if (randomNum > 20 && randomNum <= 25) {
            randomNum = 1;
        } else if (randomNum > 25) {
            randomNum = 2;
        }
        switch (randomNum) {
            case 1:
                preposition = " with ";
                break;
            case 2:
                preposition = " using ";
                break;
            case 3:
                preposition = " with my ";
                break;
            case 4:
                preposition = " using my ";
                break;
            case 5:
                preposition = ". with me I have ";
                break;
            case 6:
                preposition = ". I have ";
                break;
            case 7:
                preposition = ". I use as much as ";
                break;
            case 8:
                preposition = ". I use ";
                break;
            case 9:
                preposition = ". Prepare for ";
                break;
            case 10:
                preposition = ". My army consists of ";
                break;
            case 11:
                preposition = ". I will use, wait for it, waaaaait: ";
                break;
            case 12:
                preposition = " with the force of ";
                break;
            case 13:
                preposition = ". Get ready to be attacked by ";
                break;
            case 14:
                preposition = ". You will be stormed by ";
                break;
            case 15:
                preposition = ". Pray one last time before the coming of my ";
                break;
            case 16:
                preposition = ". All in all we are ";
                break;
            case 17:
                preposition = ". It is me and my ";
                break;
            case 18:
                preposition = ". We are ";
                break;
            case 19:
                preposition = ". Sorry, but we are ";
                break;
            case 20:
                preposition = ". I brought ";
                break;
            default:
                preposition = "Something went wrong. ";
        }
        return preposition;
    }

    public String preposition() {
        String preposition = "";
        Random rand = new Random();
        int randomNum = rand.nextInt((20)) + 1;
        if (randomNum > 12 && randomNum < 17) {
            randomNum = 1;
        } else if (randomNum >= 17) {
            randomNum = 2;
        }
        switch (randomNum) {
            case 1:
                preposition = " from ";
                break;
            case 2:
                preposition = " marching from ";
                break;
            case 3:
                preposition = ". I march from ";
                break;
            case 4:
                preposition = ". I attack from ";
                break;
            case 5:
                preposition = ". I attack from the neighbouring ";
                break;
            case 6:
                preposition = ". I go from ";
                break;
            case 7:
                preposition = ". My army comes from ";
                break;
            case 8:
                preposition = ". I will attack from, wait for it: ";
                break;
            case 9:
                preposition = " with my glorious ";
                break;
            case 10:
                preposition = ". Get ready to be attacked by ";
                break;
            case 11:
                preposition = ". You will be stormed by ";
                break;
            case 12:
                preposition = ". Pray one last time. I attack from ";
                break;
            default:
                preposition = ". Something went wrong. ";
                break;
        }
        return preposition;
    }

    public String noun() {
        String noun = "";
        Random rand = new Random();
        int randomNum = rand.nextInt((60)) + 1;
        if (randomNum > 43) {
            randomNum = 1;
        }
        switch (randomNum) {
            case 1:
                noun = " ";
                break;
            case 2:
                noun = " athletic ";
                break;
            case 3:
                noun = " angry ";
                break;
            case 4:
                noun = " stable ";
                break;
            case 5:
                noun = " hard ";
                break;
            case 6:
                noun = " tall ";
                break;
            case 7:
                noun = " strong ";
                break;
            case 8:
                noun = " terrifying ";
                break;
            case 9:
                noun = " hideous ";
                break;
            case 10:
                noun = " random ";
                break;
            case 11:
                noun = " ghastly ";
                break;
            case 12:
                noun = " haunted ";
                break;
            case 13:
                noun = " haunted ";
                break;
            case 14:
                noun = " glorious ";
                break;
            case 15:
                noun = " cursed ";
                break;
            case 16:
                noun = " frosty ";
                break;
            case 17:
                noun = " great ";
                break;
            case 18:
                noun = " nordic ";
                break;
            case 19:
                noun = " friendly ";
                break;
            case 20:
                noun = " endangered ";
                break;
            case 21:
                noun = " short ";
                break;
            case 22:
                noun = " enraged ";
                break;
            case 23:
                noun = " manly ";
                break;
            case 24:
                noun = " fearsome ";
                break;
            case 25:
                noun = " awesome ";
                break;
            case 26:
                noun = " noble ";
                break;
            case 27:
                noun = " superiour ";
                break;
            case 28:
                noun = " giant ";
                break;
            case 29:
                noun = " gallant ";
                break;
            case 30:
                noun = " dangerous ";
                break;
            case 31:
                noun = " crippled ";
                break;
            case 32:
                noun = " hard working ";
                break;
            case 33:
                noun = " battleworn ";
                break;
            case 34:
                noun = " battleborn ";
                break;
            case 35:
                noun = " childish ";
                break;
            case 36:
                noun = " moble ";
                break;
            case 37:
                noun = " honourful ";
                break;
            case 38:
                noun = " noble ";
                break;
            case 39:
                noun = " prematured ";
                break;
            case 40:
                noun = " dreadful ";
                break;
            case 41:
                noun = " long bearded ";
                break;
            case 42:
                noun = " big ";
                break;
            case 43:
                noun = " royal ";
                break;
            default:
                noun = "";
                break;
        }
        return noun;
    }

    public String oneOrMore(int input) {
        String unit = "";
        switch (input) {
            case 1:
                unit = "unit";
                break;
            case 2:
                unit = "units";
                break;
        }
        return unit;
    }

    public String putUnits() {
        String phrase = "";
        Random rand = new Random();
        int random = rand.nextInt((20)) + 1;
        if (random > 16) {
            random = 1;
        }
        switch (random) {
            case 1:
                phrase = "I put:";
                break;
            case 2:
                phrase = "Perhaps I put:";
                break;
            case 3:
                phrase = "I'll put:";
                break;
            case 4:
                phrase = "Perhaps I'll put:";
                break;
            case 5:
                phrase = "I'm thinking about putting:";
                break;
            case 6:
                phrase = "Listen! I want to put:";
                break;
            case 7:
                phrase = "What should I do? I know, put:";
                break;
            case 8:
                phrase = "After months of planning, I know I should put:";
                break;
            case 9:
                phrase = "I'll set:";
                break;
            case 10:
                phrase = "This time I put:";
                break;
            case 11:
                phrase = "I'm smart. I put:";
                break;
            case 12:
                phrase = "I'm not dumb, I'll put:";
                break;
            case 13:
                phrase = "This time I will use strategy. Therefore I put:";
                break;
            case 14:
                phrase = "My beloved told me to put:";
                break;
            case 15:
                phrase = "Fear me! I put:";
                break;
            case 16:
                phrase = "I know about your plans. Therefore I put:";
                break;
            default:
                phrase = ". Something went wrong.";
        }
        return phrase;
    }

    public String territoryDescription() {
        String phrase = "";
        Random rand = new Random();
        int random = rand.nextInt((25)) + 1;
        if (random > 16 && random < 21) {
            random = 1;
        } else if (random >= 21) {
            random = 2;
        }
        switch (random) {
            case 1:
                phrase = " on ";
                break;
            case 2:
                phrase = " in ";
                break;
            case 3:
                phrase = " on the magical territory of ";
                break;
            case 4:
                phrase = " on the great kingdom of ";
                break;
            case 5:
                phrase = " on the magical ";
                break;
            case 6:
                phrase = " in the beutiful territory ";
                break;
            case 7:
                phrase = " in the beautiful ";
                break;
            case 8:
                phrase = " on the beautiful ";
                break;
            case 9:
                phrase = " on the evergreen ";
                break;
            case 10:
                phrase = " on the glorious ";
                break;
            case 11:
                phrase = " to extend my army in ";
                break;
            case 12:
                phrase = " to make my army even bigger in ";
                break;
            case 13:
                phrase = " on my beloved ";
                break;
            case 14:
                phrase = " in the lovely ";
                break;
            case 15:
                phrase = " on my favourite territory: ";
                break;
            case 16:
                phrase = " on the lovely ";
                break;
            default:
                phrase = ". Something went wrong.";
        }
        return phrase;
    }

    public String notAttacking(Player player) {
        String name = player.name;
        String phrase = "";
        Random rand = new Random();
        int random = rand.nextInt((17)) + 1;
        switch (random) {
            case 1:
                phrase = "I am tired, I wont attack.";
                break;
            case 2:
                phrase = "Don't fool me, I'll play smart. I won't attack.";
                break;
            case 3:
                phrase = "I have big plans going on. I won't attack.";
                break;
            case 4:
                phrase = "My head hurts, this time I will leave you.";
                break;
            case 5:
                phrase = "You see, I am forging a powerful weapons and cannot attack.";
                break;
            case 6:
                phrase = "Don't wake me while I'm sleeping!";
                break;
            case 7:
                phrase = "I am afraid of you. I won't attack.";
                break;
            case 8:
                phrase = "This time i will not attack.";
                break;
            case 9:
                phrase = "I think perhaps I will make peace with you.";
                break;
            case 10:
                phrase = "Peace please!";
                break;
            case 11:
                phrase = "No, I wont attack you. Not today.";
                break;
            case 12:
                phrase = "Today I will only walk in my garden.";
                break;
            case 13:
                phrase = "Today I will spend my time with my closest.";
                break;
            case 14:
                phrase = "I pity you. Therefore I will not attack.";
                break;
            case 15:
                phrase = "Today i do not feel like fighting.";
                break;
            case 16:
                phrase = "Sometimes I fight, today however is not sometimes.";
                break;
            case 17:
                phrase = "I am " + name + ". Today I do not attack";
                break;
            default:
                phrase = ". Something went wrong.";
        }
        return phrase;
    }

    public String notMoving(Player player) {
        String phrase = "";
        String name = player.name;
        Random rand = new Random();
        int random = rand.nextInt((17)) + 1;
        switch (random) {
            case 1:
                phrase = "I am tired, I wont move.";
                break;
            case 2:
                phrase = "Don't fool me, I'll play smart. I won't move.";
                break;
            case 3:
                phrase = "I have big plans going on. I won't move.";
                break;
            case 4:
                phrase = "My units have bad feet, they wont move.";
                break;
            case 5:
                phrase = "You see, I am forging a powerful weapons and cannot move.";
                break;
            case 6:
                phrase = "My units wont move as sure as my name is " + name + "!";
                break;
            case 7:
                phrase = "I am afraid of your plans. I won't move.";
                break;
            case 8:
                phrase = "This time i will not move.";
                break;
            case 9:
                phrase = "I think perhaps I will not move.";
                break;
            case 10:
                phrase = "We rest.";
                break;
            case 11:
                phrase = "No, I wont move. Not today.";
                break;
            case 12:
                phrase = "Today my units will only walk around their tents.";
                break;
            case 13:
                phrase = "Today my units will spend my time with their close ones.";
                break;
            case 14:
                phrase = "You see, today I will not move any army.";
                break;
            case 15:
                phrase = "Today i do not feel like moving anything.";
                break;
            case 16:
                phrase = "Sometimes I move, today however is not sometimes.";
                break;
            case 17:
                phrase = "I am " + name + ". Today I do not move.";
                break;
            default:
                phrase = ". Something went wrong.";
        }
        return phrase;
    }

    public String leaderPhrase() {
        String phrase = "";
        Random rand = new Random();
        int random = rand.nextInt((16)) + 1;
        switch (random) {
            case 1:
                phrase = "My leader is going with us.";
                break;
            case 2:
                phrase = "The leader joins the company.";
                break;
            case 3:
                phrase = "Leader joins the army.";
                break;
            case 4:
                phrase = "No rest for my leader.";
                break;
            case 5:
                phrase = "My leader will join the army.";
                break;
            case 6:
                phrase = "My leader is strong, he follows the army!";
                break;
            case 7:
                phrase = "My leader is not afraid of you. He will join the army.";
                break;
            case 8:
                phrase = "My leader will join.";
                break;
            case 9:
                phrase = "Leader is going as well.";
                break;
            case 10:
                phrase = "Leader march!";
                break;
            case 11:
                phrase = "Leader is with the men.";
                break;
            case 12:
                phrase = "My leader is strong and he will follow.";
                break;
            case 13:
                phrase = "The leader will follow no matter what.";
                break;
            case 14:
                phrase = "The leader will follow.";
                break;
            case 15:
                phrase = "Leader is a real man, he will follow.";
                break;
            case 16:
                phrase = "Leader, follow!";
                break;
            default:
                phrase = ". Something went wrong.";
        }
        return phrase;
    }

    public String notMovingRing(Player player) {
        String name = player.name;
        String phrase = "";
        Random rand = new Random();
        int random = rand.nextInt((17)) + 1;
        switch (random) {
            case 1:
                phrase = "I wont move the Ring.";
                break;
            case 2:
                phrase = "Don't fool me, I'll play smart. I won't move the Ring.";
                break;
            case 3:
                phrase = "I have big plans going on. The Ring won't move.";
                break;
            case 4:
                phrase = "The one carrying the Ring have bad feet. This turn he will stay.";
                break;
            case 5:
                phrase = "You see, I am forging a powerful weapons and cannot move the Ring.";
                break;
            case 6:
                phrase = "The Ring wont move as sure as my name is " + name + "!";
                break;
            case 7:
                phrase = "I am afraid of your plans. The Ring won't move.";
                break;
            case 8:
                phrase = "This time i will not move the Ring.";
                break;
            case 9:
                phrase = "I think perhaps I will not move the Ring.";
                break;
            case 10:
                phrase = "We rest, with the Ring.";
                break;
            case 11:
                phrase = "No, I wont move the Ring. Not today.";
                break;
            case 12:
                phrase = "Today the Ring wants to stay.";
                break;
            case 13:
                phrase = "Today the Ring will not move at all.";
                break;
            case 14:
                phrase = "You see, today I will not move any Ring.";
                break;
            case 15:
                phrase = "Today i do not feel like moving anything.";
                break;
            case 16:
                phrase = "Sometimes I move the Ring, today however is not sometimes.";
                break;
            case 17:
                phrase = "I am " + name + ". Today I do not move the Ring.";
                break;
            default:
                phrase = ". Something went wrong.";
        }
        return phrase;
    }

    public void menuGibberish() {
        String phrase = "";
        Random rand = new Random();
        int random = rand.nextInt((100)) + 1;
        switch (random) {
            case 1:
                phrase = "Elves are great marksmen.";
                break;
            case 2:
                phrase = "Have you ever seen an Oliphant?";
                break;
            case 3:
                phrase = "Middle earth used to be such a nice place to visit.";
                break;
            case 4:
                phrase = "The more you get 6 the more you wear out 6 on the dice which makes your odds worse.";
                break;
            case 5:
                phrase = "Never go full retard.";
                break;
            case 6:
                phrase = "Do you think " + red.name + " will win?";
                break;
            case 7:
                phrase = "Do you think " + black.name + " will win?";
                break;
            case 8:
                phrase = "Do you think " + yellow.name + " will win?";
                break;
            case 9:
                phrase = "Do you think " + green.name + " will win?";
                break;
            case 10:
                phrase = "Dwarves are stubborn.";
                break;
            case 11:
                phrase = "That was not a good move.";
                break;
            case 12:
                phrase = "I am Iluvatar.";
                break;
            case 13:
                phrase = "I am the beginning and end.";
                break;
            case 14:
                phrase = "Hint: Do not fall asleep.";
                break;
            case 15:
                phrase = "Hint: Never trust a wizard.";
                break;
            case 16:
                phrase = "Hint: Don't go though Moria.";
                break;
            case 17:
                phrase = "Hint: Do not underestimate leaders.";
                break;
            case 18:
                phrase = "Hint: Do not underestinate anyone.";
                break;
            case 19:
                phrase = "Are you still trying?";
                break;
            case 20:
                phrase = "Hint: If you get a 6 you have a bigger chance to win.";
                break;
            case 21:
                phrase = "Hint: Your last move was not that good.";
                break;
            case 22:
                phrase = "You killed a man.";
                break;
            case 23:
                phrase = "I am not an AI.";
                break;
            case 24:
                phrase = "Loiren is a lovely place.";
                break;
            case 25:
                phrase = "Mirkwood used to be a nice place.";
                break;
            case 26:
                phrase = "Where are the entwives?";
                break;
            case 27:
                phrase = "Hint: The ring has it's own life.";
                break;
            case 28:
                phrase = "The AI do not have much controll over the Ring.";
                break;
            case 29:
                phrase = "Hint: AI does not know everything.";
                break;
            case 30:
                phrase = "Hint: The Ring is a round object.";
                break;
            case 31:
                phrase = "Try not to kill everyone.";
                break;
            case 32:
                phrase = "In order to win, you need to look out for trolls.";
                break;
            case 33:
                phrase = "Mountain trolls are beastly things.";
                break;
            case 34:
                phrase = "I like the elves. Not woodelves thugh, not anymore.";
                break;
            case 35:
                phrase = "Hint: Elves are great, but so are ents.";
                break;
            case 36:
                phrase = "Eagle versus troll. Who wins?";
                break;
            case 37:
                phrase = "Hint: Out of units? Haha, who am I kidding. You cannot be out of units!";
                break;
            case 38:
                phrase = "Hint: Do not underestinate men.";
                break;
            case 39:
                phrase = "Did you do that last thing?";
                break;
            case 40:
                phrase = "Hint: AI has no feelings.";
                break;
            case 41:
                phrase = "There is a small chance this message comes up twice.";
                break;
            case 42:
                phrase = "What makes " + red.name + " so great?";
                break;
            case 43:
                phrase = "What makes " + black.name + " so great?";
                break;
            case 44:
                phrase = "What makes " + yellow.name + " so great?";
                break;
            case 45:
                phrase = "What makes " + green.name + " so great?";
                break;
            case 46:
                phrase = "In a hole in the ground there lived a hobbit.";
                break;
            case 47:
                phrase = "Hint: Hobbits are short and unpredictable";
                break;
            case 48:
                phrase = "Where there's life there's hope, and need of vittles.";
                break;
            case 49:
                phrase = "A hunted man sometimes wearies of distrust and longs for friendship.";
                break;
            case 50:
                phrase = "Leave the dead in peace.";
                break;
            case 51:
                phrase = "The world is indeed full of peril and in it there are many dark places.";
                break;
            case 52:
                phrase = "Hint: Yellow allways win.";
                break;
            case 53:
                phrase = "Hint: Black allways win.";
                break;
            case 54:
                phrase = "Hint: Red allways win.";
                break;
            case 55:
                phrase = "Hint: Green allways win.";
                break;
            case 56:
                phrase = "There are no landmines on the board.";
                break;
            case 57:
                phrase = "Lembas taste great, giv it a try!";
                break;
            case 58:
                phrase = "Sail away!";
                break;
            case 59:
                phrase = "Hint: Don't go into the west.";
                break;
            case 60:
                phrase = "Now get this party starting.";
                break;
            case 61:
                phrase = "Ale for the winner?";
                break;
            case 62:
                phrase = "Hint: Sauron is taller than a normal-size hobbit.";
                break;
            case 63:
                phrase = "Hint: Don't listen to the hints.";
                break;
            case 64:
                phrase = "They say Ered Luin is a lovely place.";
                break;
            case 65:
                phrase = "Not all those who wander are lost.";
                break;
            case 66:
                phrase = "Never laugh at live dragons.";
                break;
            case 67:
                phrase = "“Faithless is he that says farewell when the road darkens.";
                break;
            case 68:
                phrase = "I will not say, do not weep, for not all tears are an evil.";
                break;
            case 69:
                phrase = "A single dream is more powerful than a thousand realities.";
                break;
            case 70:
                phrase = "Little by little, one travels far.";
                break;
            case 71:
                phrase = "Courage is found in unlikely places.";
                break;
            case 72:
                phrase = "Trolls are known for their strength.";
                break;
            case 73:
                phrase = "Hint: Ents and troll are quite strong.";
                break;
            case 74:
                phrase = "Oliphalnts can feed a medium-size village for exactly six months.";
                break;
            case 75:
                phrase = "Hint: 6 is better than 4.";
                break;
            case 76:
                phrase = "Fortify, eat, attack, repeat.";
                break;
            case 77:
                phrase = "Hint: Do not use rifles.";
                break;
            case 78:
                phrase = "Goblins are strong and attack they in big numbers.";
                break;
            case 79:
                phrase = "Hint: Do not look down.";
                break;
            case 80:
                phrase = "This will take at least another hour.";
                break;
            case 81:
                phrase = "Lets get started, aye?.";
                break;
            case 82:
                phrase = "These notes are useless.";
                break;
            case 83:
                phrase = "I am better than anyone else.";
                break;
            case 84:
                phrase = "Hint: Do not make a troll angry.";
                break;
            case 85:
                phrase = "Hint: Do not make an ent angry.";
                break;
            case 86:
                phrase = "Fly into Mordor? Why?";
                break;
            case 87:
                phrase = "Hint: Let it go, let it go.";
                break;
            case 88:
                phrase = "Middle Earth is wonderful.";
                break;
            case 89:
                phrase = "I cannot wait for the Valinor DLC!";
                break;
            case 90:
                phrase = "The board is not even.";
                break;
            case 91:
                phrase = "Courage.";
                break;
            case 92:
                phrase = "Who are good and who are evil?";
                break;
            case 93:
                phrase = "Have you ever been to Belfalas?";
                break;
            case 94:
                phrase = "Hint: Forodwaith is very cold.";
                break;
            case 95:
                phrase = "Hint: Try not getting 1 on the dice.";
                break;
            case 96:
                phrase = "I like this bord very much.";
                break;
            case 97:
                phrase = "Hint: Go through moria.";
                break;
            case 98:
                phrase = "The north remembers.";
                break;
            case 99:
                phrase = "Hint: The Ring is an easy win.";
                break;
            case 100:
                phrase = "How long has it been? One hour? Two hours?.";
                break;
            default:
                phrase = ". Something went wrong.";
        }
        presentation.setText(phrase);
    }

    public String interpunction() {
        String phrase = "";
        Random rand = new Random();
        int random = rand.nextInt((10)) + 1;
        if (random > 7) {
            random = 2;
        } else {
            random = 1;
        }
        switch (random) {
            case 1:
                phrase = ".";
                break;
            case 2:
                phrase = "!";
                break;
        }
        return phrase;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        button8 = new javax.swing.JButton();
        events = new javax.swing.JLabel();
        buttonMenu = new javax.swing.JButton();
        button4 = new javax.swing.JButton();
        explorer = new javax.swing.JLabel();
        buttonOkYellow = new javax.swing.JButton();
        button1 = new javax.swing.JButton();
        buttonAdd = new javax.swing.JButton();
        button6 = new javax.swing.JButton();
        button7 = new javax.swing.JButton();
        button3 = new javax.swing.JButton();
        button2 = new javax.swing.JButton();
        comboBox = new javax.swing.JComboBox();
        button5 = new javax.swing.JButton();
        buttonOkGreen = new javax.swing.JButton();
        isRed = new javax.swing.JButton();
        isBlack = new javax.swing.JButton();
        isYellow = new javax.swing.JButton();
        isGreen = new javax.swing.JButton();
        buttonOkRed = new javax.swing.JButton();
        buttonOkBlack = new javax.swing.JButton();
        buttonStart = new javax.swing.JButton();
        presentation = new javax.swing.JLabel();
        textField = new javax.swing.JTextField();
        buttonOkUnitsAdd = new javax.swing.JButton();
        filler1 = new javax.swing.Box.Filler(new java.awt.Dimension(0, 0), new java.awt.Dimension(0, 0), new java.awt.Dimension(32767, 0));
        filler2 = new javax.swing.Box.Filler(new java.awt.Dimension(0, 0), new java.awt.Dimension(0, 0), new java.awt.Dimension(32767, 32767));
        filler3 = new javax.swing.Box.Filler(new java.awt.Dimension(0, 0), new java.awt.Dimension(0, 0), new java.awt.Dimension(32767, 0));
        jPanel1 = new javax.swing.JPanel();
        terrritorieLabel = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        textArea = new javax.swing.JTextArea();
        buttonOkUnitsAfterFight = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        button8.setText("Ring");
        button8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button8ActionPerformed(evt);
            }
        });

        events.setText("jLabel3");

        buttonMenu.setText("Menu");
        buttonMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonMenuActionPerformed(evt);
            }
        });

        button4.setText("Attack");
        button4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button4ActionPerformed(evt);
            }
        });

        explorer.setText("Menu");

        buttonOkYellow.setText("OK");
        buttonOkYellow.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonOkYellowActionPerformed(evt);
            }
        });

        button1.setText("Units");
        button1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button1ActionPerformed(evt);
            }
        });

        buttonAdd.setText("Add");
        buttonAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonAddActionPerformed(evt);
            }
        });

        button6.setText("Ring");
        button6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button6ActionPerformed(evt);
            }
        });

        button7.setText("Choose Player");
        button7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button7ActionPerformed(evt);
            }
        });

        button3.setText("Leader");
        button3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button3ActionPerformed(evt);
            }
        });

        button2.setText("Attack");
        button2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button2ActionPerformed(evt);
            }
        });

        comboBox.setModel(new javax.swing.DefaultComboBoxModel(new String[] {}));
        comboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboBoxActionPerformed(evt);
            }
        });

        button5.setText("Move");
        button5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button5ActionPerformed(evt);
            }
        });

        buttonOkGreen.setText("Start");
        buttonOkGreen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonOkGreenActionPerformed(evt);
            }
        });

        isRed.setText("Red");
        isRed.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                isRedActionPerformed(evt);
            }
        });

        isBlack.setText("Black");
        isBlack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                isBlackActionPerformed(evt);
            }
        });

        isYellow.setText("Yellow");
        isYellow.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                isYellowActionPerformed(evt);
            }
        });

        isGreen.setText("Green");
        isGreen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                isGreenActionPerformed(evt);
            }
        });

        buttonOkRed.setText("OK");
        buttonOkRed.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonOkRedActionPerformed(evt);
            }
        });

        buttonOkBlack.setText("OK");
        buttonOkBlack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonOkBlackActionPerformed(evt);
            }
        });

        buttonStart.setText("Start");
        buttonStart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonStartActionPerformed(evt);
            }
        });

        presentation.setText("jLabel1");

        buttonOkUnitsAdd.setText("OK");
        buttonOkUnitsAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonOkUnitsAddActionPerformed(evt);
            }
        });

        terrritorieLabel.setText("panel2Label");

        textArea.setColumns(20);
        textArea.setRows(5);
        jScrollPane1.setViewportView(textArea);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(terrritorieLabel)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 418, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(terrritorieLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 183, Short.MAX_VALUE))
        );

        buttonOkUnitsAfterFight.setText("OK");
        buttonOkUnitsAfterFight.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonOkUnitsAfterFightActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(filler2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(55, 55, 55))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(button1, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(button2, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(button3, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(button4, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                            .addGap(340, 340, 340)
                            .addComponent(filler3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(explorer)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addGroup(layout.createSequentialGroup()
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(button5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(isRed, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(button6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(isBlack, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(button7)
                                .addComponent(isYellow, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(button8, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(isGreen, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(events, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(layout.createSequentialGroup()
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(comboBox, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(textField, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(buttonAdd, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(buttonMenu)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(buttonOkGreen)))
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(buttonOkYellow)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(buttonOkBlack))
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(buttonOkUnitsAdd)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(buttonOkUnitsAfterFight)))
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(buttonOkRed)
                                        .addComponent(buttonStart))
                                    .addGap(0, 0, Short.MAX_VALUE)))
                            .addGap(4, 4, 4))
                        .addComponent(presentation, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGap(307, 307, 307)
                .addComponent(filler1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(explorer)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(button1)
                            .addComponent(button2)
                            .addComponent(button3)
                            .addComponent(button4)))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(179, 179, 179)
                                .addComponent(filler1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(40, 40, 40))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(button5)
                                    .addComponent(button6)
                                    .addComponent(button7)
                                    .addComponent(button8))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(isRed)
                                    .addComponent(isBlack)
                                    .addComponent(isYellow)
                                    .addComponent(isGreen))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(presentation)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(events)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(comboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(textField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(buttonOkUnitsAdd)
                                    .addComponent(buttonStart)
                                    .addComponent(buttonOkUnitsAfterFight))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(buttonAdd)
                                    .addComponent(buttonMenu)
                                    .addComponent(buttonOkGreen)
                                    .addComponent(buttonOkYellow)
                                    .addComponent(buttonOkBlack)
                                    .addComponent(buttonOkRed))
                                .addGap(5, 5, 5)))
                        .addComponent(filler2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(56, 56, 56)
                .addComponent(filler3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(5, 5, 5))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void button4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button4ActionPerformed
        if (redTurn == false && blackTurn == false && yellowTurn == false && greenTurn == false && playerTurn == false) {
            textField.setText("");
            textArea.setText("");
            jPanel1.setVisible(true);
            terrritorieLabel.setText("My territories:");
            presentation.setText("");
            showTerritoriesGreen();
            menuGreen();
        } else if (redTurn) {
            button1.setVisible(false);
            button2.setVisible(false);
            button3.setVisible(false);
            button4.setVisible(false);
            button5.setVisible(false);
            button6.setVisible(false);
            button7.setVisible(false);
            button8.setVisible(false);
            isGreen.setVisible(false);
            buttonOkUnitsAdd.setVisible(false);
            buttonOkUnitsAfterFight.setVisible(true);
            textField.setVisible(true);
            textField.setText("");
            String question = unitsQuestion();
            presentation.setText("");
            events.setText(question + defender.name + "?");
            redWon = true;
        } else if (blackTurn) {
            button1.setVisible(false);
            button2.setVisible(false);
            button3.setVisible(false);
            button4.setVisible(false);
            button5.setVisible(false);
            button6.setVisible(false);
            button7.setVisible(false);
            button8.setVisible(false);
            isGreen.setVisible(false);
            buttonOkUnitsAdd.setVisible(false);
            buttonOkUnitsAfterFight.setVisible(true);
            textField.setVisible(true);
            textField.setText("");
            String question = unitsQuestion();
            presentation.setText("");
            events.setText(question + defender.name + "?");
            blackWon = true;
        } else if (yellowTurn) {
            button1.setVisible(false);
            button2.setVisible(false);
            button3.setVisible(false);
            button4.setVisible(false);
            button5.setVisible(false);
            button6.setVisible(false);
            button7.setVisible(false);
            button8.setVisible(false);
            isGreen.setVisible(false);
            buttonOkUnitsAdd.setVisible(false);
            buttonOkUnitsAfterFight.setVisible(true);
            textField.setVisible(true);
            textField.setText("");
            String question = unitsQuestion();
            presentation.setText("");
            events.setText(question + defender.name + "?");
            yellowWon = true;
        } else if (greenTurn) {
            button1.setVisible(false);
            button2.setVisible(false);
            button3.setVisible(false);
            button4.setVisible(false);
            button5.setVisible(false);
            button6.setVisible(false);
            button7.setVisible(false);
            button8.setVisible(false);
            isGreen.setVisible(false);
            buttonOkUnitsAdd.setVisible(false);
            buttonOkUnitsAfterFight.setVisible(true);
            textField.setVisible(true);
            textField.setText("");
            String question = unitsQuestion();
            presentation.setText("");
            events.setText(question + defender.name + "?");
            blackWon = true;
        } else if (playerTurn) {
            button1.setVisible(false);
            button2.setVisible(false);
            button3.setVisible(false);
            button4.setVisible(false);
            button5.setVisible(false);
            button6.setVisible(false);
            button7.setVisible(false);
            button8.setVisible(false);
            isGreen.setVisible(false);
            buttonOkUnitsAdd.setVisible(false);
            buttonOkUnitsAfterFight.setVisible(true);
            textField.setVisible(true);
            textField.setText("");
            String question = unitsQuestion();
            presentation.setText("");
            events.setText(question + defender.name + "?");
            playerWon = true;
        }
    }//GEN-LAST:event_button4ActionPerformed

    private void buttonOkYellowActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonOkYellowActionPerformed
        initialStartGreen();
    }//GEN-LAST:event_buttonOkYellowActionPerformed

    private void buttonAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonAddActionPerformed
        if (redTurn && choosingTerritory) {
            selectedTerritory = comboBox.getSelectedItem().toString();
            for (int i = 0; i < territories.allTerritories.length; i++) {
                if (selectedTerritory.toUpperCase().equals(territories.allTerritories[i].name.toUpperCase())) {
                    System.out.println(selectedTerritory);
                    territories.allTerritories[i].units++;
                    territories.allTerritories[i].isRed = true;
                    events.setText("Added " + territories.allTerritories[i].name + " to " + red.name + "'s territory list.");
                }
            }
        }
        if (blackTurn && choosingTerritory) {
            selectedTerritory = comboBox.getSelectedItem().toString();
            for (int i = 0; i < territories.allTerritories.length; i++) {
                if (selectedTerritory.toUpperCase().equals(territories.allTerritories[i].name.toUpperCase())) {
                    System.out.println(selectedTerritory);
                    territories.allTerritories[i].units++;
                    territories.allTerritories[i].isBlack = true;
                }
            }
        }
        if (yellowTurn && choosingTerritory) {
            selectedTerritory = comboBox.getSelectedItem().toString();
            for (int i = 0; i < territories.allTerritories.length; i++) {
                if (selectedTerritory.toUpperCase().equals(territories.allTerritories[i].name.toUpperCase())) {
                    System.out.println(selectedTerritory);
                    territories.allTerritories[i].units++;
                    territories.allTerritories[i].isYellow = true;
                }
            }
        }
        if (greenTurn && choosingTerritory) {
            selectedTerritory = comboBox.getSelectedItem().toString();
            for (int i = 0; i < territories.allTerritories.length; i++) {
                if (selectedTerritory.toUpperCase().equals(territories.allTerritories[i].name.toUpperCase())) {
                    System.out.println(selectedTerritory);
                    territories.allTerritories[i].units++;
                    territories.allTerritories[i].isGreen = true;
                }
            }
        }
        if (playerTurn) {
            selectedTerritory = comboBox.getSelectedItem().toString();
            for (int i = 0; i < territories.allTerritories.length; i++) {
                if (selectedTerritory.toUpperCase().equals(territories.allTerritories[i].name.toUpperCase())) {
                    defender = territories.allTerritories[i];
                }
            }
            wonOrLostPlayer();
        }
        updateTerritoryList();
    }//GEN-LAST:event_buttonAddActionPerformed

    private void button3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button3ActionPerformed
        mainMenu = false;
        if (redTurn == false && blackTurn == false && yellowTurn == false && greenTurn == false) {
            textField.setText("");
            textArea.setText("");
            jPanel1.setVisible(true);
            terrritorieLabel.setText("My territories:");
            presentation.setText("");
            showTerritoriesYellow();
            menuYellow();
        } else if (redTurn && menuLeader == false) {
            button1.setVisible(false);
            button2.setVisible(false);
            button3.setVisible(true);
            button4.setVisible(false);
            button5.setVisible(false);
            button6.setVisible(false);
            button7.setVisible(false);
            button8.setVisible(false);
            isGreen.setVisible(false);
            isYellow.setVisible(true);
            button3.setText("Add leader");
            isYellow.setText("Remove leader");
            menuLeader = true;
        } else if (redTurn && menuLeader) {
            placeLeaderRed();
            showTerritoriesRed();
            menuRed();
        } else if (blackTurn && menuLeader == false) {
            button1.setVisible(false);
            button2.setVisible(false);
            button3.setVisible(true);
            button4.setVisible(false);
            button5.setVisible(false);
            button6.setVisible(false);
            button7.setVisible(false);
            button8.setVisible(false);
            isGreen.setVisible(false);
            isYellow.setVisible(true);
            button3.setText("Add leader");
            isYellow.setText("Remove leader");
            menuLeader = true;
        } else if (blackTurn && menuLeader) {
            placeLeaderBlack();
            showTerritoriesBlack();
            menuBlack();
        } else if (yellowTurn && menuLeader == false) {
            button1.setVisible(false);
            button2.setVisible(false);
            button3.setVisible(true);
            button4.setVisible(false);
            button5.setVisible(false);
            button6.setVisible(false);
            button7.setVisible(false);
            button8.setVisible(false);
            isGreen.setVisible(false);
            isYellow.setVisible(true);
            button3.setText("Add leader");
            isYellow.setText("Remove leader");
        } else if (yellowTurn && menuLeader) {
            placeLeaderYellow();
            showTerritoriesYellow();
            menuYellow();
        } else if (greenTurn && menuLeader == false) {
            button1.setVisible(false);
            button2.setVisible(false);
            button3.setVisible(true);
            button4.setVisible(false);
            button5.setVisible(false);
            button6.setVisible(false);
            button7.setVisible(false);
            button8.setVisible(false);
            isGreen.setVisible(false);
            isYellow.setVisible(true);
            button3.setText("Add leader");
            isYellow.setText("Remove leader");
        } else if (greenTurn && menuLeader) {
            placeLeaderGreen();
            showTerritoriesGreen();
            menuGreen();
        }
    }//GEN-LAST:event_button3ActionPerformed

    private void comboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboBoxActionPerformed

    }//GEN-LAST:event_comboBoxActionPerformed

    private void button1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button1ActionPerformed
        textField.setText("");
        textArea.setText("");
        jPanel1.setVisible(true);
        terrritorieLabel.setText("My territories:");
        mainMenu = false;
        if (redTurn == false && blackTurn == false && yellowTurn == false && greenTurn == false) {
            presentation.setText("");
            showTerritoriesRed();
            menuRed();
        } else if (redTurn) {
            unitsRed();
        } else if (blackTurn) {
            unitsBlack();
        } else if (yellowTurn) {
            unitsYellow();
        } else if (greenTurn) {
            unitsGreen();
        }
    }//GEN-LAST:event_button1ActionPerformed

    private void button2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button2ActionPerformed
        if (redTurn == false && blackTurn == false && yellowTurn == false && greenTurn == false) {
            textField.setText("");
            textArea.setText("");
            jPanel1.setVisible(true);
            terrritorieLabel.setText("My territories:");
            presentation.setText("");
            showTerritoriesBlack();
            menuBlack();
        } else if (redTurn) {
            button1.setVisible(false);
            button2.setVisible(false);
            button3.setVisible(false);
            button4.setVisible(true);
            button5.setVisible(false);
            button6.setVisible(false);
            button7.setVisible(false);
            button8.setVisible(false);
            isGreen.setVisible(true);
            menuAttacking = true;
            numbersOfAttackings = numbersOfAttacksRed();
            attackRed();
        } else if (blackTurn) {
            button1.setVisible(false);
            button2.setVisible(false);
            button3.setVisible(false);
            button4.setVisible(true);
            button5.setVisible(false);
            button6.setVisible(false);
            button7.setVisible(false);
            button8.setVisible(false);
            isGreen.setVisible(true);
            menuAttacking = true;
            numbersOfAttackings = numbersOfAttacksBlack();
            attackBlack();
        } else if (yellowTurn) {
            button1.setVisible(false);
            button2.setVisible(false);
            button3.setVisible(false);
            button4.setVisible(true);
            button5.setVisible(false);
            button6.setVisible(false);
            button7.setVisible(false);
            button8.setVisible(false);
            isGreen.setVisible(true);
            menuAttacking = true;
            numbersOfAttackings = numbersOfAttacksYellow();
            attackYellow();
        } else if (greenTurn) {
            button1.setVisible(false);
            button2.setVisible(false);
            button3.setVisible(false);
            button4.setVisible(true);
            button5.setVisible(false);
            button6.setVisible(false);
            button7.setVisible(false);
            button8.setVisible(false);
            isGreen.setVisible(true);
            menuAttacking = true;
            numbersOfAttackings = numbersOfAttacksGreen();
            attackGreen();
        }
    }//GEN-LAST:event_button2ActionPerformed

    private void button5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button5ActionPerformed
        if (redTurn == false && blackTurn == false && yellowTurn == false && greenTurn == false) {

        } else if (redTurn) {
            moveRed();
            showTerritoriesRed();
        } else if (blackTurn) {
            moveBlack();
            showTerritoriesBlack();
        } else if (yellowTurn) {
            moveYellow();
            showTerritoriesYellow();
        } else if (greenTurn) {
            moveGreen();
            showTerritoriesGreen();
        }
    }//GEN-LAST:event_button5ActionPerformed

    private void button6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button6ActionPerformed
        if (redTurn == false && blackTurn == false && yellowTurn == false && greenTurn == false) {

        } else if (redTurn) {
            moveRingRed();
        } else if (blackTurn) {
            moveRingBlack();
        } else if (yellowTurn) {
            moveRingYellow();
        } else if (greenTurn) {
            moveRingGreen();
        }
    }//GEN-LAST:event_button6ActionPerformed

    private void button7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button7ActionPerformed
        if (redTurn == false && blackTurn == false && yellowTurn == false && greenTurn == false) {
            playerTurn = true;
            attackPlayer();
        } else if (redTurn) {
            choosePlayerRed();
        } else if (blackTurn) {
            choosePlayerBlack();
        } else if (yellowTurn) {
            choosePlayerYellow();
        } else if (greenTurn) {
            choosePlayerGreen();
        }
    }//GEN-LAST:event_button7ActionPerformed

    private void button8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button8ActionPerformed
        if (redTurn == false && blackTurn == false && yellowTurn == false && greenTurn == false) {
            playerTurn = true;
            moveRingPlayer();
        } else if (redTurn && menuAttacking) {
            button8.setVisible(false);
            attackRed();
        } else if (redTurn && menuAttacking == false) {

        } else if (blackTurn && menuAttacking) {
            button8.setVisible(false);
            attackBlack();
        } else if (blackTurn && menuAttacking == false) {

        } else if (yellowTurn && menuAttacking) {
            button8.setVisible(false);
            attackYellow();
        } else if (yellowTurn && menuAttacking == false) {

        } else if (greenTurn && menuAttacking) {
            button8.setVisible(false);
            attackGreen();
        } else if (greenTurn && menuAttacking == false) {

        }
    }//GEN-LAST:event_button8ActionPerformed

    private void buttonOkGreenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonOkGreenActionPerformed
        menu();
    }//GEN-LAST:event_buttonOkGreenActionPerformed

    private void isGreenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_isGreenActionPerformed
        if (redTurn == false && blackTurn == false && yellowTurn == false && greenTurn == false && playerTurn == false) {
            green.alive = true;
            green.isAI = true;
            isGreen.setVisible(false);
            events.setText("Green is AI");
            buttonStart.setVisible(true);
        } else if (redTurn) {
            button1.setVisible(false);
            button2.setVisible(false);
            button3.setVisible(false);
            button4.setVisible(false);
            button5.setVisible(false);
            button6.setVisible(false);
            button7.setVisible(false);
            button8.setVisible(false);
            isGreen.setVisible(false);
            buttonOkUnitsAdd.setVisible(false);
            buttonOkUnitsAfterFight.setVisible(true);
            textField.setVisible(true);
            textField.setText("");
            String question = unitsQuestion();
            presentation.setText("");
            events.setText(question + defender.name + "?");
            redWon = false;
        } else if (blackTurn) {
            button1.setVisible(false);
            button2.setVisible(false);
            button3.setVisible(false);
            button4.setVisible(false);
            button5.setVisible(false);
            button6.setVisible(false);
            button7.setVisible(false);
            button8.setVisible(false);
            isGreen.setVisible(false);
            buttonOkUnitsAdd.setVisible(false);
            buttonOkUnitsAfterFight.setVisible(true);
            textField.setVisible(true);
            textField.setText("");
            String question = unitsQuestion();
            presentation.setText("");
            events.setText(question + defender.name + "?");
            blackWon = false;
        } else if (yellowTurn) {
            button1.setVisible(false);
            button2.setVisible(false);
            button3.setVisible(false);
            button4.setVisible(false);
            button5.setVisible(false);
            button6.setVisible(false);
            button7.setVisible(false);
            button8.setVisible(false);
            isGreen.setVisible(false);
            buttonOkUnitsAdd.setVisible(false);
            buttonOkUnitsAfterFight.setVisible(true);
            textField.setVisible(true);
            textField.setText("");
            String question = unitsQuestion();
            presentation.setText("");
            events.setText(question + defender.name + "?");
            yellowWon = false;
        } else if (greenTurn) {
            button1.setVisible(false);
            button2.setVisible(false);
            button3.setVisible(false);
            button4.setVisible(false);
            button5.setVisible(false);
            button6.setVisible(false);
            button7.setVisible(false);
            button8.setVisible(false);
            isGreen.setVisible(false);
            buttonOkUnitsAdd.setVisible(false);
            buttonOkUnitsAfterFight.setVisible(true);
            textField.setVisible(true);
            textField.setText("");
            String question = unitsQuestion();
            presentation.setText("");
            events.setText(question + defender.name + "?");
            greenWon = false;
        } else if (playerTurn) {
            button1.setVisible(false);
            button2.setVisible(false);
            button3.setVisible(false);
            button4.setVisible(false);
            button5.setVisible(false);
            button6.setVisible(false);
            button7.setVisible(false);
            button8.setVisible(false);
            isGreen.setVisible(false);
            buttonOkUnitsAdd.setVisible(false);
            buttonOkUnitsAfterFight.setVisible(true);
            textField.setVisible(true);
            textField.setText("");
            String question = unitsQuestion();
            presentation.setText("");
            events.setText(question + defender.name + "?");
            playerWon = false;
        }
    }//GEN-LAST:event_isGreenActionPerformed

    private void isBlackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_isBlackActionPerformed
        black.alive = true;
        black.isAI = true;
        isBlack.setVisible(false);
        events.setText("Black is AI");
        buttonStart.setVisible(true);
    }//GEN-LAST:event_isBlackActionPerformed

    private void isYellowActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_isYellowActionPerformed
        if (redTurn == false && blackTurn == false && yellowTurn == false && greenTurn == false) {
            yellow.alive = true;
            yellow.isAI = true;
            isYellow.setVisible(false);
            events.setText("Yellow is AI");
            buttonStart.setVisible(true);
        } else if (redTurn && menuLeader == false) {
            button1.setVisible(false);
            button2.setVisible(false);
            button3.setVisible(true);
            button4.setVisible(false);
            button5.setVisible(false);
            button6.setVisible(false);
            button7.setVisible(false);
            button8.setVisible(false);
            isGreen.setVisible(false);
            isYellow.setVisible(true);
            button3.setText("Add leader");
            isYellow.setText("Remove leader");
            menuLeader = true;
        } else if (redTurn && menuLeader) {
            removeLeaderRed();
            menuRed();
        } else if (blackTurn && menuLeader == false) {
            button1.setVisible(false);
            button2.setVisible(false);
            button3.setVisible(true);
            button4.setVisible(false);
            button5.setVisible(false);
            button6.setVisible(false);
            button7.setVisible(false);
            button8.setVisible(false);
            isGreen.setVisible(false);
            isYellow.setVisible(true);
            button3.setText("Add leader");
            isYellow.setText("Remove leader");
            menuLeader = true;
        } else if (blackTurn && menuLeader) {
            removeLeaderBlack();
            menuBlack();
        } else if (yellowTurn && menuLeader == false) {
            button1.setVisible(false);
            button2.setVisible(false);
            button3.setVisible(true);
            button4.setVisible(false);
            button5.setVisible(false);
            button6.setVisible(false);
            button7.setVisible(false);
            button8.setVisible(false);
            isGreen.setVisible(false);
            isYellow.setVisible(true);
            button3.setText("Add leader");
            isYellow.setText("Remove leader");
            menuLeader = true;
        } else if (yellowTurn && menuLeader) {
            removeLeaderYellow();
            menuYellow();
        } else if (greenTurn && menuLeader == false) {
            button1.setVisible(false);
            button2.setVisible(false);
            button3.setVisible(true);
            button4.setVisible(false);
            button5.setVisible(false);
            button6.setVisible(false);
            button7.setVisible(false);
            button8.setVisible(false);
            isGreen.setVisible(false);
            isYellow.setVisible(true);
            button3.setText("Add leader");
            isYellow.setText("Remove leader");
            menuLeader = true;
        } else if (greenTurn && menuLeader) {
            removeLeaderGreen();
            menuGreen();
        }
    }//GEN-LAST:event_isYellowActionPerformed

    private void isRedActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_isRedActionPerformed
        red.alive = true;
        red.isAI = true;
        isRed.setVisible(false);
        events.setText("Red is AI");
        buttonStart.setVisible(true);
    }//GEN-LAST:event_isRedActionPerformed

    private void buttonOkRedActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonOkRedActionPerformed
        initialStartBlack();
    }//GEN-LAST:event_buttonOkRedActionPerformed

    private void buttonOkBlackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonOkBlackActionPerformed
        initialStartYellow();
    }//GEN-LAST:event_buttonOkBlackActionPerformed

    private void buttonStartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonStartActionPerformed
        if (playerTurn == false) {
            setTerritories();
        }
        if (playerTurn) {
            for (int i = 0; i < territories.allTerritories.length; i++) {
                territories.allTerritories[i].hasRing = false;
            }
            selectedTerritory = comboBox.getSelectedItem().toString();
            for (int i = 0; i < territories.allTerritories.length; i++) {
                if (selectedTerritory.toUpperCase().equals(territories.allTerritories[i].name.toUpperCase())) {
                    territories.allTerritories[i].hasRing = true;
                    presentation.setText(selectedTerritory + " now has the Ring.");
                }
            }
            menu();
        }
    }//GEN-LAST:event_buttonStartActionPerformed

    private void buttonMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonMenuActionPerformed
        if (redTurn && mainMenu == false) {
            menuRed();
        } else if (redTurn && mainMenu == true) {
            menuGibberish();
            menu();
        } else if (blackTurn && mainMenu == false) {
            menuBlack();
        } else if (blackTurn && mainMenu == true) {
            menuGibberish();
            menu();
        } else if (yellowTurn && mainMenu == false) {
            menuGreen();
        } else if (yellowTurn && mainMenu == true) {
            menuGibberish();
            menu();
        } else if (greenTurn && mainMenu == false) {
            menuYellow();
        } else if (greenTurn && mainMenu == true) {
            menuGibberish();
            menu();
        }
    }//GEN-LAST:event_buttonMenuActionPerformed

    private void buttonOkUnitsAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonOkUnitsAddActionPerformed
        if (redTurn) {
            buttonOkUnitsAdd.setVisible(false);
            units = Integer.parseInt(textField.getText());
            placeUnitsRed();
            menuRed();
        } else if (blackTurn) {
            buttonOkUnitsAdd.setVisible(false);
            units = Integer.parseInt(textField.getText());
            placeUnitsBlack();
            menuBlack();
        } else if (yellowTurn) {
            buttonOkUnitsAdd.setVisible(false);
            units = Integer.parseInt(textField.getText());
            placeUnitsyellow();
            menuYellow();
        } else if (greenTurn) {
            buttonOkUnitsAdd.setVisible(false);
            units = Integer.parseInt(textField.getText());
            placeUnitsGreen();
            menuGreen();
        }
    }//GEN-LAST:event_buttonOkUnitsAddActionPerformed

    private void buttonOkUnitsAfterFightActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonOkUnitsAfterFightActionPerformed
        textField.setVisible(false);
        buttonOkUnitsAfterFight.setVisible(false);
        if (redTurn) {
            unitsAfterFight = Integer.parseInt(textField.getText());
            if (redWon) {
                attackRedWin();
            } else {
                attackRedLost();
            }
        } else if (blackTurn) {
            unitsAfterFight = Integer.parseInt(textField.getText());
            if (blackWon) {
                attackBlackWin();
            } else {
                attackBlackLost();
            }
        } else if (yellowTurn) {
            unitsAfterFight = Integer.parseInt(textField.getText());
            if (yellowWon) {
                attackYellowWin();
            } else {
                attackYellowLost();
            }
        } else if (greenTurn) {
            unitsAfterFight = Integer.parseInt(textField.getText());
            if (greenWon) {
                attackGreenWin();
            } else {
                attackGreenLost();
            }
        } else if (playerTurn) {
            unitsAfterFight = Integer.parseInt(textField.getText());
            if (playerWon) {
                attackPlayerWon();
            } else {
                attackPlayerLost();
            }
        }
    }//GEN-LAST:event_buttonOkUnitsAfterFightActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(GUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(GUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(GUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(GUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new GUI().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton button1;
    private javax.swing.JButton button2;
    private javax.swing.JButton button3;
    private javax.swing.JButton button4;
    private javax.swing.JButton button5;
    private javax.swing.JButton button6;
    private javax.swing.JButton button7;
    private javax.swing.JButton button8;
    private javax.swing.JButton buttonAdd;
    private javax.swing.JButton buttonMenu;
    private javax.swing.JButton buttonOkBlack;
    private javax.swing.JButton buttonOkGreen;
    private javax.swing.JButton buttonOkRed;
    private javax.swing.JButton buttonOkUnitsAdd;
    private javax.swing.JButton buttonOkUnitsAfterFight;
    private javax.swing.JButton buttonOkYellow;
    private javax.swing.JButton buttonStart;
    private javax.swing.JComboBox comboBox;
    private javax.swing.JLabel events;
    private javax.swing.JLabel explorer;
    private javax.swing.Box.Filler filler1;
    private javax.swing.Box.Filler filler2;
    private javax.swing.Box.Filler filler3;
    private javax.swing.JButton isBlack;
    private javax.swing.JButton isGreen;
    private javax.swing.JButton isRed;
    private javax.swing.JButton isYellow;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel presentation;
    private javax.swing.JLabel terrritorieLabel;
    private javax.swing.JTextArea textArea;
    private javax.swing.JTextField textField;
    // End of variables declaration//GEN-END:variables
}
